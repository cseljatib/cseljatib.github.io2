#' creates a new dataframe that includes columns with species shade-tolerance.
#'
#' No details are given
#' 
#' @title creates a dataframe including species shade-tolerance
#' @param data data frame having tree data, including species code name (i.e., esp)
#' @param name.esp column name having the species code name (i.e., esp)

#' @return This function returns a data frame including information on shade tolerance of species.
#' @author Christian Salas-Eljatib
#' @examples
#' 
#'
#' #data(sppTraits) #tree species with their functional traits from the datasets
#' 
#' #Sample dataframe
#' #narb<- c(1:10)
#' #esp <- c("nob","nal","ec","ls",
#' #          "pn","sc","la","em","lh","lf");
#' #needTol<-data.frame(narb,esp)
#' 
#' #Using the function
#' #tol1 <- assignsTol(data = needTol, name.esp = "esp")
#' #head(tol1)
#' 
#' 
#' @rdname assignsTol
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
assignsTol <- function (data = data, name.esp = name.esp) 
{
  df <- data
  #SFT<-biometria::traits
  SFT<-data(traits)
  df$esp <- df[,name.esp]
  assignsTol <- merge(x = df, y =SFT , 
                      by = "esp", 
                      all.x = TRUE)
  out.code <- assignsTol
  return(out.code)
}