#' Meyer 
#'
#' Mathematical expression for the Meyer function for relating variable Y versus X
#' @title Mathematical expression for the Meyer function for relating variable Y versus X
#' @param params Vector with value of parameters (The values must be added in an orderly way, see example)
#' @param X Vector containing the values for the predictor variable
#' @param intercept Value of intercept of function. Default value is 0.
#'
#' @return The value of the function for every value of the vector X and the parameters.
#' @author Christian Salas.
#' @references Meyer HA (1940) A mathematical expression for height curves. Journal of Forestry 38(5) 415 420.
#' @examples
#'
#' b0<-28.4
#' b1<-0.0584
#' params<-c(b0,b1)
#' X <- c(70)
#' y<-meyer(params,X,intercept=1.3)
#' plot(y~X,type='p')
#' 
#' @rdname meyer  
#' @export
meyer <- function(params, X, intercept=NA){
  if (is.na(intercept)==TRUE){intercept=0}
  b0<-params[1]
  b1<-params[2]
  x<-X[1]
  y <- intercept + b0*(1-exp(-b1*x)) 
}
