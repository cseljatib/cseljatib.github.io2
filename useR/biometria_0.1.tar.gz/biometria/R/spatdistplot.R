#' The main feature of this function is to produce a single figure having: a 
#' spatial distribution plot of points (point pattern) or a marked point pattern.
#'
#'
#' @title Produces a spatial distibution plot. If provided, a marked spatial point plot is drawn instead of point-patterns only.
#' @param data a dataframe with at least two columns representing the X-axis coordinate ("xc"),
#'   the Y-axis coordinate ("yc"). Optionally, any mark can be used.
#' @param xc the position at the X-axis coordinate.
#' @param yc the position at the Y-axis coordinate.
#' @param dimx the length of the plot for the X-axis. Therefore, not value of 'xc' can be larger than dimx.
#' @param dimy the length  of the plot for the Y-axis. Therefore, not value of 'yc' can be larger than dimy.
#' @param mark a character giving the column name of the response variable or variable of interest.
#' @param group.var an optional character having the name of a column having a factor variable (e.g., species). The
#'  detault value is set to NULL. Notice that a group.var can also me a mark for spatial analysis.
#' @param tresh.low.mark a number indicating a treshold value for the mark, using the logical operator "lower than". The
#'  detault value is set to NULL.
#' @param tresh.greo.mark a number indicating a treshold value for the mark, using the logical operator "greater or equal than".
#'  The detault value is set to NULL.
#' @param col.tresh is a vector of length two, having the colors to be used for the groups being identified by the
#' rule provided in either tresh.low.mark or tresh.greo.mark. It only should be defined if the options
#'  tresh.low.mark or tresh.greo.mark are not NULL.
#' @param main.tex The main title of the plot
#' @param ylab Label for the Y-axis
#' @param legend logical value for printing the legend. Default is set to TRUE.
#' @param col.mark a character having the color to be used for drawing the plot. Default is set to "gray".
#' @param col.border a character having the color to be used for drawing the border of the window plot. Default is set to "black".
#' @param cex a number to be used for affecting the size of the objects to be drawn. Default is set to 1.
#' @param plot.as.trees if TRUE, the plotting imitates trees for each observation. Default is set to FALSE. Only shoud be defined
#'   to be TRUE if the option "mark" is not defined or NULL.
#' @param biom.plotting if TRUE, the plotting imitates the biometrics sort of plotting in papers. Default is set to FALSE. 
#'  Review the reference Soto et al. (2010)  for further details. 
#' @param corre.fac is a number to be used to modify the drawing of circels if the option "biom.plotting" is set to TRUE.
#'  Notice that default value for this option is set to 0.05
#'
#' @return This function returns a spatial distribution plot
#' @author Christian Salas-Eljatib
#' @references
#' - Soto DP, Salas C, Donoso PJ, Uteau D. 2010. Heterogeneidad estructural y espacial de un bosque mixto dominado por
#' Nothofagus dombeyi despues de un disturbio parcial. Revista Chilena de Historia Natural 83(3): 335–347.
#' @references
#' - Salas C, LeMay V, Nunez P, Pacheco P, Espinosa A. 2006. Spatial patterns
#'  in an old-growth Nothofagus obliqua forest in south-central Chile.
#'  Forest Ecology and Management 231:38-46
#' @note Please, uses with caution, and run first the examples to understand it better.
#' @examples
#' 
#' #df<-data(spatLlancahue)
#' #spatdistplot(df, xc="x.coord", yc="y.coord",dimx=130, dimy=70, main.tex ="Spatial - unmark")
#' #spatdistplot(df, xc="x.coord", yc="y.coord",dimx=130, dimy=70, cex=.7)
#' #spatdistplot(df, xc="x.coord", yc="y.coord",mark="dbh", dimx=130, dimy=70)
#' #spatdistplot(df, xc="x.coord", yc="y.coord",mark="dbh", dimx=130, dimy=70,
#' #    col.mark = "red", col.border="green")
#' #spatdistplot(df, xc="x.coord", yc="y.coord",  mark="dbh", dimx=130, dimy=70,
#' #   biom.plotting = TRUE)
#' @rdname spatdistplot
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
spatdistplot <- function(data=data, xc=xc, yc=yc, mark=NULL, group.var=NULL,  main.tex=NULL,ylab, 
                         tresh.low.mark=NULL,tresh.greo.mark=NULL,col.tresh=FALSE, legend=TRUE,
                         biom.plotting=FALSE, corre.fac=0.05,
                         cex=1, plot.as.trees=FALSE, 
                         dimx=dimx, dimy=dimy, col.mark="gray", col.border="black")
{
  db<-data
  db$x.coord<-db[,xc]
  db$y.coord<-db[,yc]
  
  hay.mark <- 0;   hay.grupo <- 0
  if(!is.null(mark)){hay.mark <- 1} else {nada=99}
  if(hay.mark==1){db$z<-db[,mark]} else {nada=99}
  if(!is.null(group.var)){hay.grupo <- 1} else {nada=99}
  if(hay.grupo==1){db$g<-as.factor(db[,group.var]) } else {nada=99} 
  if(hay.grupo==1){db$g<-droplevels(db$g)}
  
  coords.h <- as.matrix(db[, c("x.coord", "y.coord")])
  
  dim.plot=c(dimx,dimy)
  owin<-spatstat::owin(c(0,dimx), c(0,dimy))
  
  if(hay.grupo==0 & hay.mark==0){db.ppp<-spatstat::ppp(db$y.coord, db$x.coord, window=owin)} else {NADA=999}  
  if(hay.grupo==0 & hay.mark==1){db.ppp<-spatstat::ppp(db$y.coord, db$x.coord, marks=db$z,window=owin)} else {NADA=999}
  if(hay.grupo==1 & hay.mark==0){db.ppp<-spatstat::ppp(db$y.coord, db$x.coord, marks=db$g,window=owin)} else {NADA=999}
  
  plot.normal=1; plot.low.tresh=0;plot.greo.tresh=0;
  if(!is.null(tresh.low.mark)){plot.low.tresh=1} else {nada=99}
  if(!is.null(tresh.greo.mark)){plot.greo.tresh=1} else {nada=99}
  
  if(plot.greo.tresh==1 | plot.greo.tresh==1){plot.normal=0} else {nada=99}
  
  if(class(col.tresh)=="character"){col.levels.aqui <- col.tresh}else{
    col.levels.aqui <-  c("red", "gray")
  } 
  
  if(plot.normal==1 & hay.grupo==0   & biom.plotting==FALSE){graphics::plot(db.ppp,cols=col.mark,border=col.border,main=main.tex, legend=legend)} else {nada=999}
  if(plot.low.tresh==1 & hay.grupo==0   & biom.plotting==FALSE){graphics::plot(db.ppp,border=col.border,main=main.tex, legend=legend,cols=function(x) ifelse(x < tresh.low.mark, col.levels.aqui[1], col.levels.aqui[2] ))} else {nada=999}
  if(plot.greo.tresh==1 & hay.grupo==0   & biom.plotting==FALSE){
    graphics::plot(db.ppp,border=col.border,main=main.tex,legend=legend,cols=function(x) ifelse(x >= tresh.greo.mark, col.levels.aqui[1], col.levels.aqui[2] ))
  } else {nada=999}  
  
  ## only points - unmarked 
  if(hay.grupo==0  & hay.mark==0  & plot.as.trees==FALSE   & biom.plotting==FALSE){graphics::plot(db.ppp, main=main.tex,use.marks=FALSE, cex=cex)}   
  if(hay.grupo==1  & hay.mark==0 & plot.as.trees==TRUE    & biom.plotting==FALSE){graphics::plot(db.ppp, main=main.tex,shape="arrows", direction=90, cols=1:length(levels(db.ppp$marks)),cex=cex)} 
  if(hay.grupo==1  & hay.mark==0  & plot.as.trees==FALSE   & biom.plotting==FALSE){graphics::plot(db.ppp, main=main.tex,use.marks=FALSE, cex=cex)} 
  
  if(hay.mark==1  & biom.plotting==TRUE){
    where.dataVec <- findColumn.byname(db,"z")
    x.col <- findColumn.byname(db,"x.coord")
    y.col <- findColumn.byname(db,"y.coord")
    db.geo<-geoR::as.geodata(db,coords.col=c(x.col,y.col),
                             data.col=where.dataVec)  
  }
  
  if(hay.mark==1  & biom.plotting==TRUE){ 
    if(!is.null(corre.fac)){corre.fac <- corre.fac} else {corre.fac <- .05}
    db.geo$data <- db.geo$data*corre.fac
    graphics::plot(db.geo$coords[,1],db.geo$coords[,2],type="p",pch=".",las=1,xlab="Easting",ylab="Northing")
    graphics::symbols(db.geo$coords[,1], db.geo$coords[,2], 
            circles = db.geo$data,inches=F,add = T, fg=col.mark) 
  }
}
