E.theta <- function(theta.hat,theta){
    dif <- (theta.hat-theta)
    dif.rel <- (dif/theta)
    dif.per <- (dif.rel) * 100
	c(dif.per,dif.rel)
}
