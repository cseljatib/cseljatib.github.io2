#' Gives the statistics for statistical inference for a given contrast
#' 
#'   
#' 
#' @title Gives the statistics for statistical inference
#' @param mod object containing the fitted model
#' @param coef.cont vector with the coefficients to establish the contrasts
#' @param g.means mean per group
#' @param g.ns sample size per group
#' @param alpha is the confidence level in percentage for building the confidence intervals
#' @param full 0 if want short output, 1 for longer (i.e. more details)
#'
#' @return This function computes the Estimated contrast, standard error of the contrast,
#'         and confidence interval of the contrast, subject a given alpha level 
#'  
#' @author Christian Salas-Eljatib
#' @examples
#' #not yet implemented
#' 
#' @rdname a.contrast
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
a.contrast <- function(mod,coef.cont,g.means,g.ns,alpha,full){

  #my style
  c.est <- t(coef.cont)%*%g.means
  # computing the s(C).
  mse=(summary(mod)$sigma)^2
  df.res=stats::df.residual(mod) 
  se.c.est <- sqrt( mse* t(coef.cont^2)%*%(1/g.ns) )

#  alpha=0.05
  tscore=stats::qt(1-alpha/2,df.res)

# confidence interval for the estimated contrast  
  c.est.lower <- c.est-tscore*se.c.est;
  c.est.upper <- c.est+tscore*se.c.est;
 
# t-statistics for the estimated contrast
  t.comp=c.est/se.c.est
#  p.value=pvalueT(t.comp,df.res) #p.value for the t-statistics (my.Functiont)
   p.value=round(((1-stats::pt(abs(t.comp),df.res))*2),4)
  
 if(full==0){
     output=c(c.est,se.c.est,p.value)
     names(output)=c('Est.Contrast','SE.Cont','p-value')
   } else {
  output=c(c.est,se.c.est,c.est.lower,c.est.upper,p.value)
names(output)=c('Est.Contrast','SE.Cont','Lower.bound.Cont','Upper.bound.Cont','p-value')
}

  output
}