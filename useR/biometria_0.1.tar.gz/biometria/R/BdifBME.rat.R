BdifBME.rat <- function(y,x,Sys.e,n){
      N=length(y);
      f <- 1/N;
       fsc<- ((1/n)-(1/N));
       mu.y<- mean(y); 
       mu.x <- mean(x); 
      var.y <- stats::var(y);
      var.x <- stats::var(x); 
      sd.x<-stats::sd(x)
      tau.y <-sum(y); 
      tau.x <-sum(x)
      cv.y <- (stats::sd(y))/mu.y ;
      cv.x <- (stats::sd(x))/mu.x
      cv.x.me <- (stats::sd(x)+Sys.e)/mu.x
      cov.yx <- stats::cov(y,x)
      r <- (y/x); mu.r <- mean(r); R.est<- (mu.y/mu.x)
      rho <- stats::cor(y,x)   # correlation coefficient  

#----------
#Difference B-B* for rat1 -------
      part.1 <- cv.x^2 - (cv.x.me^2)
      part.2 <- rho*cv.y*(cv.x.me-cv.x)
      red.fac <- (1+(Sys.e/mu.x))^2
          
    difBRat.est1<-fsc*(part.1+part.2)*tau.y

# difference B-B* for rat2 ----------      
bias.tau.y.rat2 <-  sum ( r *(mu.x - x) )
biasE.tau.y.rat2 <-  sum ( r *(x*(((mu.x+Sys.e)/(x+Sys.e)) - 1) ))                    
   difBRat.est2 <-bias.tau.y.rat2 - biasE.tau.y.rat2
      
    output <-  c(difBRat.est1,difBRat.est2,bias.tau.y.rat2,biasE.tau.y.rat2)    
#    names(output) <- c("")
    output
}
