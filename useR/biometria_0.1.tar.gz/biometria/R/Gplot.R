Gplot <-function(Gest.out,Genve.out,unit.dist){                                            #
G.est<-Gest.out$rs;G.low<-Genve.out$lo;G.high<-Genve.out$hi                                 #
# Starting the plot                                                                         #
#x.range=c(min(Gest.out$r),max(Gest.out$r));y.range=c(min(G.low,G.est),max(G.high,G.est));  #
x.range=c(min(Gest.out$r),max(Gest.out$r));y.range=c(0,1);                                  #
graphics::plot(Gest.out$r,G.est,type='l',xlim=x.range,ylim=y.range,main="",                           #
xlab=paste("Distance t, in ",unit.dist),ylab=expression(italic(hat(G)(t))));
graphics::par(new=T);     #
graphics::plot(Gest.out$r,G.low,type='l',xlim=x.range,ylim=y.range,main="",xlab="",ylab="",lty=2)     #
graphics::par(new=T);                                                                                 #
graphics::plot(Gest.out$r,G.high,type='l',xlim=x.range,ylim=y.range,main="",xlab="",ylab="",lty=2)}