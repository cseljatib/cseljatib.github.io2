RE.theta <- function(var.theta,real.theta){
         sd.theta <- sqrt(var.theta)
         RE <- (sd.theta/real.theta)
         RE.per <- RE * 100
#         c( RE, RE.per)
       out <- c( RE, RE.per)
       names(out) <- c("RE", "RE%")
       out
}
