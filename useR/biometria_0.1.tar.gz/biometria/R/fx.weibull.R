fx.weibull <- function(var.list,shape,scale){
  Fx.x <- 1 -   exp(-(var.list/scale)^(shape))
  Fx.x
}