stat.tau.rat.srs <- function(y,x,n){
      r <- (y/x);
      N=length(y); 
      f <- 1/N;
      red.factor <- ( (1/n) - f )
      mean.y <- mean(y);
      mean.x <- mean(x);
      mean.r <- mean(r);
      tau.y <-sum(y);
      tau.x <-sum(x) ;
      var.x <- stats::var(x);
      var.y <- stats::var(y); 
      var.r <- stats::var(r)
      cv.y <- (stats::sd(y))/mean.y ;
      cv.x <- (stats::sd(x))/mean.x
      cov.yx <- stats::cov(y,x);
      cov.rx <- stats::cov(r,x);
       R.est<- (mean.y/mean.x)
      rho <- stats::cor(y,x)   # correlation coefficient                
      bias.tau.y.rat1 <- red.factor * (cv.x^2 - rho*cv.x*cv.y)*tau.y
      bias.tau.y.rat1.p <- (bias.tau.y.rat1/tau.y)*100
      
      bias.tau.y.rat2 <- - sum ( r *(x - mean.x) )     
      bias.tau.y.rat2.p <- (bias.tau.y.rat2/tau.y)*100
      bias.tau.y.rat3 <- 0;  bias.tau.y.rat3.p <- 0

      var.rm.rat1 <- (1/(N-1)) * sum( (y - R.est*x)^2 )
      var.rm.rat2 <- (1/(N-1)) * sum( (r - mean.r)^2 )
      var.tau.y.rat1 <- N^2 * red.factor * var.rm.rat1
      var.tau.y.rat1.p <- (sqrt(var.tau.y.rat1)/tau.y)*100
      var.tau.y.rat2 <- red.factor * tau.x^2 * var.rm.rat2
      var.tau.y.rat2.p <- (sqrt(var.tau.y.rat2)/tau.y)*100
#      part.1 <- cv.y^2+ cv.x^2; part.2 <- (2*cov.yx)/(mean.y*mean.x) #for goodmand&hartley eq.6
      part.1 <- mean.r^2 * var.x; part.2 <- (2*mean.r*cov.yx);
      part.3 <- ((var.r*var.x)+(cov.rx)^2)/(n-1)
#      var.tau.y.rat3 <- red.factor * tau.y^2 * (part.1 - part.2) #goodmand&hartley eq.6
      
   var.tau.y.rat3 <- (N^2)* red.factor * (var.y +part.1 - part.2 + part.3) #goodmand&hartley eq.18
      
      var.tau.y.rat3.p <- (sqrt(var.tau.y.rat3)/tau.y)*100
      
      mse.tau.y.rat1 <- bias.tau.y.rat1^2 + var.tau.y.rat1
      mse.tau.y.rat1.p <- (sqrt(mse.tau.y.rat1)/tau.y)*100
      mse.tau.y.rat2 <- bias.tau.y.rat2^2 + var.tau.y.rat2
      mse.tau.y.rat2.p <- (sqrt(mse.tau.y.rat2)/tau.y)*100
      mse.tau.y.rat3 <- bias.tau.y.rat3^2 + var.tau.y.rat3
      mse.tau.y.rat3.p <- (sqrt(mse.tau.y.rat3)/tau.y)*100

    output <-  c(bias.tau.y.rat1, bias.tau.y.rat2, bias.tau.y.rat3,
                 var.tau.y.rat1, var.tau.y.rat2, var.tau.y.rat3,
                 mse.tau.y.rat1, mse.tau.y.rat2, mse.tau.y.rat3,
                 bias.tau.y.rat1.p, bias.tau.y.rat2.p, bias.tau.y.rat3.p,
                 var.tau.y.rat1.p, var.tau.y.rat2.p, var.tau.y.rat3.p,
                 mse.tau.y.rat1.p, mse.tau.y.rat2.p, mse.tau.y.rat3.p)
#    names(output) <- c("Bias.Tau1.y","Bias.Tau2.y","Bias.Tau3.y",
#                 "Var.Tau.y.rat1","Var.tau.y.rat2","Var.tau.y.rat3",
#                 "MSE.rat1","MSE.rat2","MSE.rat3")
    output
}