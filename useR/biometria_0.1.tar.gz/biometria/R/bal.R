#' Computes the basal area in larger (by basal area) trees for any given tree within a sample plot
#'
#' 
#' @title Computes basal area in larger trees
#' @param data data frame having plot level data
#' @param dbh column name having the diameter at breast height in centimeters
#' @param plot.area column name containing the plot size in square meters
#' 
#' @return This function returns a data frame with two columns, the first is BAL
#'  and the second the percentile of BAL
#' @author Arne Pommerening, slightly modified by Christian Salas-Eljatib
#' @examples
#'
#' 
#' #Creating an example dataframe
#' plot.no <- 1
#' area <- 1000 #in m2
#' n <- 13; species <- c(rep("Roble",n)); diam <- round(rnorm(n,25,20),1);
#' df<-data.frame(plot.no,area,species,diam)
#' n <- 19; species <- c(rep("Rauli",n)); diam <- round(rnorm(n,20,10),1);
#' df2<-data.frame(plot.no,area,species,diam)
#' df <- rbind(df,df2)
#' n <- 18; species <- c(rep("Coihue",n)); diam <- round(rnorm(n,30,10),1);
#' df2<-data.frame(plot.no,area,species,diam)
#' df <- rbind(df,df2)
#' n <- 15; species <- c(rep("Olivillo",n)); diam <- round(rexp(n,1/30),1); 
#' df2<-data.frame(plot.no,area,species,diam)
#' df <- rbind(df,df2)
#' df <- subset(df,diam>5)
#' 
#' #Using the function
#' df$bal <- bal(data=df, dbh="diam", plot.area = "area")$bal 
#' df$p.bal <- bal(data=df, dbh="diam", plot.area = "area")$p.bal
#' head(df)
#' 
#' @rdname bal
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
bal <- function(data=data, dbh=dbh, plot.area=plot.area) {
  df <- data
  df$a<-df[,plot.area]
  df$frec <- 10000/df$a
  df$dbh<-df[,dbh]
  df$g <- df$dbh^2*pi/40000
  df$tree.gha <- df$g*df$frec
  sumba <- sum(df$tree.gha) #stand or plot basal area
  basmallereq <- 0
  p.bal <- 0 #percentil of BAL
  bal <- 0   #BAL
  for (i in 1 : length(df$tree.gha)) {
    bax <- df$tree.gha[i]
    basmallereq <- sum(df$tree.gha[df$tree.gha <= bax])
    bal[i] <- sumba - basmallereq 
    p.bal[i] <- basmallereq / sumba
  }
  out<- data.frame(bal,p.bal)
  return(out)
}
