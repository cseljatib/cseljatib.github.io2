stat.pps <- function(y,x,tau.x,n){
  r.mean    <- mean(y/x)
  p.i    <- (x/tau.x)
      sum.pi <- sum(p.i)
      tau.y <- tau.x * r.mean 
      sum.2 <- sum ( ( (y/p.i) - tau.y )^2 )
      var.tau.pps <- ( 1 / (n*(n-1)) ) * sum.2
      c(tau.y,var.tau.pps)
}