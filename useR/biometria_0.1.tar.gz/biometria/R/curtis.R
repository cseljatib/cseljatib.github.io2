#' Curtis' function 
#'
#' Robert Curtis' function
#' @title Mathematical expression for the Curtis's model to relate Y versus X
#' @param params Vector with value of parameters (The values must be added in an orderly way, see example)
#' @param X Vector containing the values for the predictor variable
#' @param intercept Value of intercept of function. Default value is 0.
#'
#' @return The value of the function for every value of the vector X depending on the parameters.
#' @author Christian Salas-Eljatib.
#' @note Please read the reference for further details.
#' @references - Curtis RO (1967) Height diameter and height diameter age equations for second growth Douglas. Forest Science 13(4) 365 375.
#' 
#'
#' @examples
#'
#' b0<- 37.68
#' b1<- 18.6
#' params<-c(b0,b1) 
#' X <- c(70)
#' y<-curtis(params,X,intercept=1.3)
#' plot(y~X,type='p')
#' 
#' @rdname curtis  
#' @export
curtis <- function (params,X,intercept=NA) {
  if (is.na(intercept)==TRUE) {intercept=0}
  b0<-params[1]
  b1<-params[2]
  x<-X[1]
  y<-intercept + b0*((x/(1+x))^b1)  
}
