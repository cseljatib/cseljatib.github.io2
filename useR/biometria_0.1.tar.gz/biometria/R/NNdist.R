#' Computes nearest neighbor distances for objects in a spatial dataframe. Be aware
#'  that this takes a while to run for large datasets.
#'   
#' 
#' @title Computes nearest neighbor distances for objects in a spatial dataframe.
#' @param pppData a ppp data object (the data with the Cartesian coordinates)
#' @param PlotArea a numeric scalar with the plot area.
#' @return nearest neighbor distances for objects in a spatial dataframe
#'  
#'  
#' @author Christian Salas-Eljatib
#' @note Be aware that this takes a while to run for large datasets. Furthermore the pppData must be obtained from
#'  a previous step where the "spatstat" package is needed.
#' @examples
#' 
#' #not yet implemented
#' @rdname nndist
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
nndist<-function(pppData,PlotArea){                                                         
   temp<-NNdist(pppData); n<-length(temp); lambda<-n/PlotArea;                              
   (2*sqrt(lambda)/n*sum(temp)-1)/sqrt((4-pi)/(n*pi))}
