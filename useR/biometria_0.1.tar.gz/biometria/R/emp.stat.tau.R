emp.stat.tau <- function(y,tau.y){
   num.simulations=nrow(y); mean.y <- mean(y)
  res.tau <- (y-tau.y); res.mean <- (y-mean.y)
      emp.bias.tau.y <- mean(res.tau)
      emp.var.tau.y <- stats::var(y) #the MC variance of y
      emp.mse.tau.y <- (emp.bias.tau.y)^2 + emp.var.tau.y
      emp.bias.tau.y.per <- (emp.bias.tau.y/tau.y)*100
      emp.var.tau.y.per <- (sqrt(emp.var.tau.y)/tau.y)*100
      emp.mse.tau.y.per <- (sqrt(emp.mse.tau.y)/tau.y)*100

    output <-  c(emp.bias.tau.y,emp.var.tau.y,emp.mse.tau.y,
                 emp.bias.tau.y.per,emp.var.tau.y.per,emp.mse.tau.y.per)
# Do not activate the following two lines!!  
#    names(output) <- c("Emp.Bias.Tau.y","Emp.Var.Tau.y","Emp.MSE.Tau.y",
#                       "Emp.Bias.Tau.y%","Emp.Var.Tau.y%","Emp.MSE.Tau.y%")
    output
}
