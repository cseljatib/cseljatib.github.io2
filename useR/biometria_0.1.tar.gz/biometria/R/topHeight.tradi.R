#' Conventional top height estimate
#' 
#'   
#' 
#' @title Calculate the height of the dominant trees in a stand 
#' @param heights vector or list of tree heights, sorted by increasing dbh
#' @param ares column name having the plot area in ares (1 hectare = 100 ares)
#' 
#' @return   Calculate top height using the conventional top height estimate
#'           Reference: Garcia,O. and Batho,A. Western Journal of Applied forestry 20(1), 64-68. 2005.
#'  
#'  
#' @author Christian Salas-Eljatib
#' @note This function need the 'Uestimator' function 
#' @examples
#' #not yet implemented
#' 
#' @rdname topHeight.tradi
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
topHeight.tradi <- function(heights, ares) {
  (n <- 100 * ares)   # largest 100 per hectare
  toph.trad <- mean(sort(heights, decreasing = T)[1:round(n)])
  return (toph.trad)
}