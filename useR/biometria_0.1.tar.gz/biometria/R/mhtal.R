#' Calculates the mean height of the trees taller than the subject tree within a sample plot
#'
#' No details are given
#' 
#' @title Calculates the mean height of the trees taller than the subject tree
#' @param data data frame having plot level data
#' @param h column name having the height of trees, in meters
#' @param plot.area column name containing the plot size, in square meters
#' 
#' @return This function returns a data frame with two columns, the first with the mean height of taller trees
#'  and the second with the median height of taller trees
#' @author Arne, but modified a little-bit by Christian Salas-Eljatib
#' @examples
#'
#' 
#' #Creating an example dataframe
#' plot.no <- 1
#' area <- 1000 #in m2
#' n <- 13; species <- c(rep("Roble",n)); diam <- round(rnorm(n,25,20),1); height <- round(rnorm(n,40,4),1); 
#' df<-data.frame(plot.no,area,species,diam,height)
#' n <- 19; species <- c(rep("Rauli",n)); diam <- round(rnorm(n,20,10),1); height <- round(rnorm(n,30,4),1); 
#' df2<-data.frame(plot.no,area,species,diam,height)
#' df <- rbind(df,df2)
#' n <- 18; species <- c(rep("Coihue",n)); diam <- round(rnorm(n,30,10),1); height <- round(rnorm(n,37,4),1); 
#' df2<-data.frame(plot.no,area,species,diam,height)
#' df <- rbind(df,df2)
#' n <- 15; species <- c(rep("Olivillo",n)); diam <- round(rexp(n,1/30),1); height <- round(rnorm(n,38,7),1); 
#' df2<-data.frame(plot.no,area,species,diam,height)
#' df <- rbind(df,df2)
#' df <- subset(df,diam>5)
#' df <- subset(df,height>1.3 & height<55)
#' 
#' #Using the function
#' df$mean.htaller <-   mhtal(data=df, h="height", plot.area = "area")$mean.htaller # Returns the column containing the mean height of taller trees
#' df$median.htaller <-   mhtal(data=df, h="height", plot.area = "area")$median.htaller # Returns the column containing the median height of taller trees 
#' 
#' @rdname mhtal
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
#' mhtal <- function(data=data, h=h, plot.area=plot.area) {
#'  df <- data
#'  df$a<-df[,plot.area]
#'  df$frec <- 10000/df$a
#'  df$h<-df[,h]
#'  sumba <- max(df$h)
#'  median.htaller <-  mean.htaller <- 0
#'  for (i in 1 : length(df$h)) {
#'    bax <- df$h[i]
#'    mhtal <- mean(df$h[df$h > bax])
#'    medianhtal <- median(df$h[df$h > bax])
#'    mean.htaller[i] <- mhtal
#'    median.htaller[i] <- medianhtal    
#'  }
#'  out <- data.frame(mean.htaller,median.htaller)
#'  return(out)
#' }