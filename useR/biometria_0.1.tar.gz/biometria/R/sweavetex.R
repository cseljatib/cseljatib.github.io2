sweavetex <- function(filename,extension='Rnw',command='pdflatex',silent=FALSE,preview=FALSE)
{
        if (command=='latex') command='simpdftex latex --maxpfb'
        extension<-paste('.',extension,sep='')
        path=options('latexcmd')[[1]]
        path=substr(path,start=1,stop=nchar(path)-5)
# generate the .tex file with Sweave
        utils::Sweave(paste(filename,extension,sep=''))
#
# run BibTeX...
        cat('\nRunning  BibTeX...\n')        
        system(paste(path,'bibtex',' ',filename,sep=''),intern=silent)
#
# run pdfLaTeX...
        cat('\nRunning pdfLaTeX (my Sweavetex.r file!!...\n')        
        system(paste(path,command,' ',filename,sep=''),intern=silent)
#        if (command=='latex')
#        {
#                system(paste(path,'dvipdfm',' ',filename,sep=''))
#        }
        if (preview)
        {
                system(paste(options('pdfviewer')[[1]],' ',filename,'.pdf',sep=''))
#                system(paste(options('xpdf')[[1]],' ',filename,'.pdf',sep=''))
        }
}
