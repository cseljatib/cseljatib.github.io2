Kdiff<-function(pp1,pp2){
allx<-c(pp1$x,pp2$x)
ally<-c(pp1$y,pp2$y)
dif<-matrix(0,400,99)

for (i in 1:99){
  temp<-sample(c(1:length(allx)),length(pp1$x))
  x1<-allx[temp]
  x2<-allx[-temp]
  y1<-ally[temp]
  y2<-ally[-temp]
  dif[,i]<-spatstat::Kest(spatstat::ppp(x1,y1,xrange=range(x1),yrange=range(y1)))$iso[1:400] - spatstat::Kest(spatstat::ppp(x2,y2,xrange=range(x2),yrange=range(y2)))$iso[1:400]
   print(i)
}

hibound<-apply(dif,1,max)
lobound<-apply(dif,1,min)
Kdif<-spatstat::Kest(pp1)$iso[1:400]-spatstat::Kest(pp2)$iso[1:400]
Kr<-spatstat::Kest(pp1)$r[1:400]
ylims=range(c(hibound,lobound,Kdif),na.rm=TRUE)
graphics::plot(Kr,Kdif,type="n",ylim=ylims,ylab="Diff in K functions",xlab="r")
graphics::lines(Kr,Kdif,lwd=2)
graphics::lines(Kr,lobound,lwd=2,lty=2,col='red')
graphics::lines(Kr,hibound,lwd=2,lty=2,col='red')
}
