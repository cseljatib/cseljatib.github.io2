#' It creates an increment data from a time series dataframe. From a data containing
#'  measurements of variables on time, this function will create a period-wise 
#'  dataframe for all the variables, depending upon the ID observation and the
#'  variable representing the temporal scale. 
#'
#' Be careful with the output, uses with caution.
#' 
#' @title Create increment data from time series observations 
#' @param data data frame having the time series data
#' @param time column name having the time vector
#' @param unit.id column name containing the info of the observational unit
#' @param multi.time logical value for creating the data frame tehe default FALSE if you only want increment succesive pairs, otherwise TRUE returns all possible time combinations
#' @param n.measu logical value for adding a column with the total number of measurement on time for a given observational unit
#' @param identifica.simple returns 1 when the incremente is a succesive pair and 0 if it doesn't
#' @param static.columns columns that do not change
#' 
#' @return This function returns a data frame with an increment structure.
#'  The main columns are as follows: "tot.n.measure" represents the total number of observations on time for a given ID unit;
#'  the suffix ".0" is added to all the variables at the beginning (at time "t.0") of the period of analysis; 
#'  the suffix ".1" is added to all the variables at the end (at time "t.1") of the period of analysis. 
#'  If the option "identifica.simple" is set to be TRUE, the column "incr.sim" will appear in the output indicating
#'  with a number 1 those observations having the simple or traditional consecutive steps, and 0 otherwise. 
#' @author Christian Salas-Eljatib and Joaquin Riquelme-Alarcon
#' @note In order to use this function, the package 'gtools' must be previously installed.
#' @examples
#'
#' #Creating an example dataframe
#' id <- rep(1,4) #observation ID
#' year <- c(2000,2001,2002,2003) # time variable
#' age <- c(1, 2, 3, 4)
#' height <- c(10, 14, 15.8, 16.3)
#' spp <- rep("Nothofagus obliqua",4) # a static variable
#' 
#' df<-data.frame(id,year,age,height,spp)
#' 
#' #Alternative 1. increment-succesive data
#' creaIncrData(data = df, time = "year", unit.id = "id", static.columns = "spp")
#'
#' #Alternative 2. all possible combinations of increment data
#' creaIncrData(data = df, time = "year", unit.id = "id", static.columns = "spp", multi.time = TRUE)
#' creaIncrData(data = df, time = "year", unit.id = "id", multi.time = TRUE, 
#'              n.measu = TRUE, identifica.simple = TRUE, static.columns = "spp")
#' @rdname creaIncrData
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
creaIncrData<-function(data=data, time=time, unit.id=unit.id, multi.time=F, n.measu=NA, identifica.simple=NA,
                       static.columns=NA){
  db0<-data
  if(prod(is.na(n.measu))){n.measu=T}  
  if(prod(is.na(identifica.simple))){identifica.simple=F}    
  if(prod(!is.na(static.columns))){
    db0.static <- db0[,c(unit.id, static.columns)]
    db0.static <- unique(db0.static)
    if(nrow(db0.static)>length(unique(db0[,c(unit.id)]))){
      warning("Notice a missleading computation of the static columns")
    }
    db0 <-db0[,setdiff(names(db0),static.columns)]}else{nada=22}
  
  if(multi.time==F){identifica.simple=F}
  
  measurements <- tapply(db0[,time], db0[,unit.id], length)
  measure <- data.frame(cbind(measurements))
  measure[,unit.id] <- row.names(measure)
  db0 <- merge(db0, measure, by=unit.id)
  
  db <- subset(db0, measurements>1)
  
  n.wo.r <- nrow(db0)-nrow(db) # number of observations without remeasuremts
  
  cat(n.wo.r, "Units do not have remeasurements \n")
  # data a ser poblada con todas las filas
  db.f<-data.frame()
  
  # ciclo por cada individuo de la base de datos
  for (i in unique(db[,unit.id])){
    
    # subset de data del individuo i
    db.s<-db[db[,unit.id]==i,]
    
    # if(nrow(db.s) < 2){ 
    # cat("Observation ", i, " does not have remeasurements \n")}
    # else {nada=999}
    
    # if(nrow(db.s)>1){
    cat("Processing unit-ID ", i, "\n")
    # ordena base de datos en orden de tiempo creciente
    db.s<-db.s[order(db.s[,time]),]
    
    # genera matriz de todas las posibles combinaciones de pares de tiempos
    if(multi.time==T){combi<-gtools::combinations(n=nrow(db.s), r=2, v=db.s[,time])}
    else{#nada=999}
      #if(multi.time==F){
      combi<-cbind(db.s[1:(nrow(db.s)-1),time],db.s[2:(nrow(db.s)),time])}
    #else{nada=999}
    
    # base de datos a ser poblada para el individuo i
    db.i<-data.frame()
    
    # ciclo por cada fila de la matriz combi
    for (j in 1:nrow(combi)){
      # fila con t0 de la fila j
      db.0<-db.s[db.s[,time]==combi[j,1],]
      # fila con t1 de la fila j
      db.1<-db.s[db.s[,time]==combi[j,2],]   # db.1<-subset(db, t==combi[j,2])
      
      # con merge se unen db.0 y db.1, se establecen los sufijos de cada variable
      db.j<-merge(db.0, db.1, by=unit.id, suffixes=c(".0",".1"))
      
      # se une la fila creada a la base de datos de cada individuo
      db.i<-rbind(db.i,db.j)                              
    }
    # se une la base de datos de i a la data final
    # se une la base de datos de i a la data final
    if(n.measu==T){      
      db.i$tot.n.measure<-nrow(db.s)
    } else {no.worries=1}
    if(identifica.simple==T){
      conc <- c(1)
      n <- nrow(db.s)
      a <- n-1
      while(a>1){
        m <- conc[length(conc)]+a
        conc <- c(conc,m)
        a <- a-1
      }
      db.i$incr.sim <- 0
      db.i$incr.sim[conc] <- 1
    }
    db.i <- db.i[,-c(match(c("measurements.0","measurements.1"),names(db.i)))]
    db.f<-rbind(db.f,db.i)
  }

  # change the colnames of the time 
  colnames(db.f)[colnames(db.f) == paste(time,".0",sep="")]<-"t.0"
  colnames(db.f)[colnames(db.f) == paste(time,".1",sep="")]<-"t.1"
  
  # reorder the data
  if(n.measu==T){       
    db.f<-db.f[,c(unit.id,"tot.n.measure","t.0","t.1",
                  sort(colnames(db.f)[!is.element(colnames(db.f),c(unit.id,"tot.n.measure","t.0","t.1"))]))]} else {
                    db.f<-db.f[,c(unit.id,"t.0","t.1",
                                  sort(colnames(db.f)[!is.element(colnames(db.f),c(unit.id,"t.0","t.1"))]))]  }
  
  
  if(prod(!is.na(static.columns))){ db.f <- merge(db0.static, db.f, by=unit.id)}
  db.f
}