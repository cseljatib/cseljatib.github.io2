#' The main feature of this function is to produce a single figure having: a 
#' size distribution plot by a grouping factor and a general (i.e., no considering the
#'  grouping factor) size distribution plot as an insert. This sort of plot
#'  is specially useful in forest ecology, and mimics Figure 1 in Salas et (2006).
#'   Size  here is a random variable (in ecology this could be the biomass of a tree, or the weight
#'  of a bear), as well as graphic representations of those tables that we 
#'  refer to them as size distribituion plots. For instance, 
#'  in forest ecology the size distribution tables are usually refered as 
#'  "stand tables", and the size distribution plots as "diameter distribution"
#'  when the random variable tree diameter is used. 
#'
#'
#' @title Size distribution plot by levels of a group and all in a single figure.
#' @param data a dataframe with at least the columns representing a variable of interest ("var.int"),
#'   the are of a given sample plot ("plot.area"), and a grouping variable ("group.var").
#' @param var.int is the name of the column having the size variable or variable of interest.
#' @param plot.area is the plot area, in m2, of the sample plot. 
#' @param w.amp is a number for the size-variable class amplitud to be used in the plots. The default value is set to 10. 
#'  It is expressed in the same units that "var.int".
#' @param group.var a string with the name of the column having the grouping variable (e.g., species or treatment).
#' @param max.class.var.int is an optional vector containing the values of density to be
#'   drawn in the insert total level sizeDist plot
#' @param max.cy an optional scalar containing the maximum class for the variable of interest "var.int"
#' @param max.y.by.group an optional number specifying the maximum value to be used for the 
#' density of the main histogram of the figure (the one by the grouping variable "group.var").
#' @param max.y.all an optional number specifying the maximum value to be used for the density of the histogram when a grouping variable is not defined.
#' @param col.bar.all the colour for the bars (when grouping variable is not defined) drawn in the insert total level sizeDist plot.
#' @param max.class.var.int the value for the maximum class to be used for the "var.int", and It must
#'  be a multiple number of "w.amp".
#' @param posi.leg.group an optional string specifying the position of the legend. The default is "topright"
#' @param posi.all.groups.plot an optional string specifying the position of the small plot not segregating for levels 
#'  of the factor variable. The default is "topright"
#' @param eng a logical value for the language of the axis. By default is set to TRUE, otherwise spanish is used.
#' @param filenametablegroup a string specifying the name of the file where the stand table by group will be stored. The default
#'  is "standTableGroup". Two files will be saved, with both .out and .csv extensions.
#' @param filenametable a string specifying the name of the file where the stand table will be stored. The default
#'  is "standTable". Two files will be saved, with both .out and .csv extensions.
#' @param levels.i.want a string providing the name of the levels of the factor variable "group.var" to be used for the plotting. 
#' @param col.lev.i.want is a vector of length equal to the number of levels of the "group.var", specifying the colours to be used for each level.
#' @param xlab.mainplot a string with the label used for the X-axis of the main plot.
#' @param ylab.mainplot a string with the label used for the Y-axis of the main plot.
#' @param time.var a string with the name of the column having the time variable (e.g., year of measurement).
#' @param at.N.all Explain parameter 
#' @param metric a logical value if the Metric system is used. The default value is TRUE, otherwise the Imperial units are used.
#' @param unit.density  an optional string providing the name to be used for the Y-axis when plotting.
#' @param unit.var.int an optional string providing the name to be used for the X-axis when plotting.
#' 
#' @return This function returns a plot, as well as two ouputs (file with extention ".out")
#' with the size distribution tables by the levels of the grouping variable, and the other
#' without considering any segregation.
#' @author Christian Salas-Eljatib
#' @note Be aware that this function has several options that can be specified by an user. Be sure that all values 
#' of the variable of interest are available in the dataframe before of using the function.
#' @references - Husch B, TW Beers, JA Kershaw. 2003. Forest Mensuration. 4th edition. Wiley, New York, USA. 443 p.
#' @references - Salas C, LeMay V, Nunez P, Pacheco P, Espinosa A. 2006. Spatial patterns
#'  in an old-growth Nothofagus obliqua forest in south-central Chile.
#'  Forest Ecology and Management 231:38-46
#' @examples
#' data(pspLlancahue) 
#' head(pspLlancahue)
#' pspLlancahue$area <- 70*130
#' sizeDist.byGroupAllPlot(pspLlancahue, var.int="dbh", plot.area = "area", group.var = "spp.name")
#' sizeDist.byGroupAllPlot(pspLlancahue, var.int="dbh", plot.area = "area", group.var = "spp.name",
#'          max.class.var.int = 100) 
#' sizeDist.byGroupAllPlot(pspLlancahue, var.int="dbh", plot.area = "area", group.var = "spp.name",
#'          max.y.by.group = 500, max.y.all = 500, posi.leg.group = "topleft") 
#'          
#' @rdname sizeDist.byGroupAllPlot
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
sizeDist.byGroupAllPlot <- function(data=data, var.int=var.int, plot.area=plot.area,
                                    w.amp=10, group.var=NULL,max.class.var.int=NA,max.cy,
                                    max.y.by.group=NA,max.y.all=NA,col.bar.all="white",posi.leg.group="right",
                                    posi.all.groups.plot=NA,
                                    eng=TRUE,filenametablegroup="standTableGroup",
                                    filenametable="standTable",
                                    levels.i.want=FALSE, col.lev.i.want=FALSE, 
                                    xlab.mainplot=NA, ylab.mainplot=NA,
                                    time.var=NA, at.N.all=NA, 
                                    metric=TRUE, unit.density=NA, unit.var.int=NA) 
{
  if(prod(is.na(time.var))){temporal=FALSE} else {temporal=TRUE} 
  # if(prod(is.na(metric))){metric=TRUE} 
  # if(prod(is.na(unit.density))&metric==T){unit.density="(ind/ha)"} 
  # if(prod(is.na(unit.density))&metric==F){unit.density="(ind/acre)"} 	
  unit.density="(ind/ha)"
  if(metric==TRUE & prod(is.na(unit.density))){unit.density="(ind/ha)"}   
  if(metric!=TRUE & prod(is.na(unit.density))){unit.density="(ind/acre)"} 
  
  db <- data
  db$a<-db[,plot.area]
  db$frec <- 10000/db$a
  
  w <- w.amp
  db$dbh<-db[,var.int]
  
  if(length(group.var)>0){db$g<-as.factor(db[,group.var]) } else {stop("My friend, you must to provide a grouping variable")}
  if(length(group.var)>0){db$g<-droplevels(db$g)}
  db$spp.name <- db$g
  
  levels.aqui <- unique(db$spp.name)
  if(class(levels.i.want)=="character"){levels.aqui <- levels.i.want}else{
    levels.aqui <- levels.aqui
  } 

  col.levels.aqui <-grDevices::terrain.colors(length(levels.aqui), alpha = 1)
  
  if(class(col.lev.i.want)=="character" & prod(is.na(levels.i.want)) & length(col.lev.i.want)!=length(levels.i.want)){
    stop("The length of objects levels.i.want and col.lev.i.want must be equal ")} 
  
  if(class(col.lev.i.want)=="character"){col.levels.aqui <- col.lev.i.want}else{
    col.levels.aqui <- col.levels.aqui
  } 
  
  #db <- subset(db, dbh>=5)
  
  #calcular las clases diametricas de cada arbol
  db$dbh.class <- (as.integer((db$dbh+((w/2)-0.1))/w))*w
  #en caso q ....
  db[db[,"dbh.class"]==0,"dbh.class"]=w
  
  #=============
  #1. Objetos varios a usar en graficos y para creacion de stand tables
  #=============
  lo.q.hay <- unique(db$dbh.class)
  lo.q.hay
  
  if(prod(is.na(max.class.var.int))){max.dbh.class<-  max(db$dbh.class) } else {max.dbh.class<-  max.class.var.int} 
  
  #max.cd #
  max.dbh.class
  
  if(temporal==T){db$anhomed <- db[,time.var]} else {db$anhomed<-2000}
  
  num.anho.med <- length(unique(db$anhomed))
  
  lim.inf.en.x <- min(db$dbh) #w/2
  clases.h <- seq(lim.inf.en.x,(max.dbh.class+lim.inf.en.x), by=w)
  clases.h
  
  xlim.h <- range(clases.h) 
  xlim.h
  
  label.x <- (clases.h-lim.inf.en.x)
  label.x
  paso.x <- clases.h[2:length(clases.h)]-lim.inf.en.x
  paso.x
  label.x <- c("",paso.x)
  label.x
  
  lo.q.necesitamos <- unique(paso.x)
  lo.q.necesitamos
  
  x <- sort(lo.q.hay)
  y <- sort(lo.q.necesitamos)
  x
  y
  
  #=============
  #2. Se crea dataframe a nivel de hectarea
  #=============
  n.dap <- rep(db$dbh, db$frec)
  length(n.dap) 
  
  n.cd <- rep(db$dbh.class, db$frec)
  length(n.cd) 
  
  n.anho <- rep(db$anhomed, db$frec)
  length(n.anho) 
  
  list.spp.aqui <- sort(unique(db$spp.name))
  #print(list.spp.aqui)
  
  spp.faltan.aca <- setdiff(levels.aqui, list.spp.aqui)
  #print(spp.faltan.aca)
  
  n.esp <- as.data.frame(rep(db$spp.name, db$frec))
  length(n.esp)
  table(n.esp)
  names(n.esp) <- "n.esp"
  
  n.ha <-as.data.frame(cbind(n.dap, n.cd, n.anho, n.esp))
  utils::head(n.ha)
  
  #la densidad total es
  nha.total <- sum(table(n.ha$n.cd))
  
  #=============
  #3. Paso para identificacion de clases diametricas y creacion de stand tables
  # se identifica si hay individuos en todas las clases diametricas, si no es asi,
  # se crean las clases que no existen con valor cero
  #=============
  
  if(sum(x) != sum(y)){
    #para identificar las CD que faltan y generar ficticiamente en nuestros datos
    db3 <- data.frame(y)
    db3
    
    db3$cd.falt <- 1
    
    for(i in 1:length(x)){
      db3[db3[,"y"]==x[i],"cd.falt"]=0}
    db3
    
    db4 <- subset(db3, cd.falt==1)
    db4
    
    unique(db4$y) #aca estan las clases diametricas a agregar
    para.agregar <- unique(db4$y)
    para.agregar
    
    #----------------------------------------------------------------------
    #esto es para que posteriormente standtables posea
    #todas las clases diametricas, incluso aquellas para las cuales no hay datos, pero se
    #necesitan por asuntos graficos 
    n.esp2 <- unique(n.ha$n.esp)
    n.esp2
    n.cd2 <- length(unique(db4$y))
    n.cd2
    
    new.esp<-rep(n.esp2, n.cd2)
    new.esp <- data.frame(new.esp)
    new.esp
    
    spp <- length(n.esp2)
    spp
    
    cd2 <- unique(db4$y)
    cd2
    
    clase <- c()
    for(i in 1:length(cd2)){
      xx<-rep(cd2[i], spp)
      clase<-c(clase, xx)    
    }
    
    clase
    length(clase)
    length(new.esp$new.esp)
    
    n.dap2 <- rep(0, length(clase))
    n.dap2
    n.anho2 <- n.dap2
    n.anho2
    
    new.n.ha <- data.frame(cbind(n.dap2, clase, n.anho2, new.esp))
    utils::head(new.n.ha)
    colnames(new.n.ha) <- c('n.dap','n.cd','n.anho','n.esp')
    utils::head(new.n.ha)
    
    new.n.ha$n.esp<-"Eliminar"
    new.n.ha$n.esp<-as.character(new.n.ha$n.esp)
    new.n.ha$n.esp<-as.factor(new.n.ha$n.esp)
    class(new.n.ha$n.esp)
    class(n.ha$n.esp)
    
    #-----------------------------------------------------------------------
    #aca se junta data falsa con real 
    dim(n.ha)
    n.ha.st <- rbind(n.ha, new.n.ha)
    utils::head(n.ha.st)
    dim(n.ha.st)
    unique(n.ha.st$n.cd)
    unique(n.ha.st$n.esp)
    
    #-----------------------------------------------------------------------
    #aca se crea columna con valores verdares o falsos 
    #que servira para generar tabla de rodal total  
    
    n.ha.st$total<-"f"
    
    for (i in 1:nrow(n.ha.st)){
      if(n.ha.st$n.esp[i] == "Eliminar"){n.ha.st$total[i] <- "false"} else{n.ha.st$total[i] <- "true" }
    }
    
    unique(n.ha.st$n.anho)
    utils::head(n.ha.st)
    utils::tail(n.ha.st)
    
    #-----------------------------------------------------------------------
    #Tablas de rodal
    #tabla de rodal general (sin segregar por especie)
    table(n.ha.st$n.cd)
    
    stand.table.total0 <- table(n.ha.st$total, by = n.ha.st$n.cd)
    stand.table.total<-stand.table.total0[-1,]#Elimina Fila de datos falsos
    stand.table.total
    sum(stand.table.total)
    
    utils::head(n.ha.st)
    unique(n.ha.st$n.esp)
    num.spp.faltan<-length(spp.faltan.aca)
    if(num.spp.faltan>0){
      n.dap <- rep(w,num.spp.faltan); n.cd <- rep(w,num.spp.faltan);
      n.anho <- rep(unique(n.ha.st$n.anho)[1],num.spp.faltan)
      n.esp<-spp.faltan.aca
      total <- "true";
      fake.to.add <- data.frame(n.dap,n.cd,n.anho,n.esp,total)
      n.ha.st <- rbind(n.ha.st,fake.to.add)
    }
    
    #tabla de rodal segregado por especie
    #n.ha.st <- subset(n.ha.st, total=="true")
    stand.table0 <- table(n.ha.st$n.esp, by = n.ha.st$n.cd)
    stand.table0
    #stand.table <-    stand.table0[-nrow(stand.table0),]#Elimina Fila de datos falsos
    stand.table <- stand.table0[dimnames(stand.table0)[[1]]!="Eliminar",]
    stand.table
    
  } else{stand.table<-table(n.ha$n.esp, by = n.ha$n.cd)  
  
  stand.table.total<-table(n.ha$n.cd)} 
  
  #fin de creacion de standtables
  
  stand.table.total
  #stand.table.total <- stand.table.total[1:13]
  file.name <- paste(filenametable,".out",sep="")
  sink(file.name)
  stand.table.total
  sink()
  
  #stand.table <- stand.table[dimnames(stand.table)[[1]]!="Eliminar",]
  #print(stand.table)
  stand.table <- stand.table[order(row.names(stand.table)), ]
  
  stand.table #<- stand.table[1:13]
  file.name <- paste(filenametablegroup,".out",sep="")
  sink(file.name)
  stand.table
  sink()
  
  
  #=============
  #=============
  #4. Inicio de graficos
  #=============
  #=============
  if(eng==T & prod(is.na(ylab.mainplot))){ylab.mainplot<-paste("Density ",unit.density,sep="")} else {nada=0}
  if(eng==F & prod(is.na(ylab.mainplot))){ylab.mainplot<-paste("Densidad ",unit.density,sep="")} else {nada=0}
  
  if(eng==T & prod(is.na(xlab.mainplot)) &prod(!is.na(unit.var.int))){xlab.mainplot<-paste(var.int,".class (",unit.var.int,")",sep="")} else {nada=0}
  if(eng==F & prod(is.na(xlab.mainplot)) &prod(!is.na(unit.var.int))){xlab.mainplot<-paste("Clase.",var.int," (",unit.var.int,")",sep="")} else {nada=0}
  
  if(eng==T & prod(is.na(xlab.mainplot)) &prod(is.na(unit.var.int))){xlab.mainplot<-paste(var.int,".class",sep="")} else {nada=0}
  if(eng==F & prod(is.na(xlab.mainplot)) &prod(is.na(unit.var.int))){xlab.mainplot<-paste("Clase.",var.int,sep="")} else {nada=0}
  
  #2a
  #grafico de dist.diam. separado por clase diametrica y
  #por especie 
  
  num.spp.med <- nrow(stand.table)# length(unique(n.ha.st$n.esp))#db$spp.name))
  num.spp.med
  col.here <- col.levels.aqui
  #  c("black","white")
  # c("white","black")
  #  c("black","gray")  
  # terrain.colors(num.spp.med, alpha = 1)
  col.here
  #2a.1
  #lo mismo anterior pero agregando un graf. de densidad total como un recuadro, tal como fig. XX de salas et al 2006
  x.max.spp <- max(as.numeric(names(stand.table.total)))
  y.max.spp  <- max(stand.table)
  
  if(prod(!is.na(max.y.by.group))){y.max.spp=max.y.by.group} else {nada=999}   
  
  graphics::barplot(stand.table, 
          xlab=xlab.mainplot, ylab=ylab.mainplot,
          las=1,
          beside=T,legend = TRUE,
          args.legend = list(bty = "n", x = posi.leg.group, ncol = 1,
                             inset = 0.0),
          #     cex.axis = 1.4, cex.names = 1.4, cex.lab =1.4, 
          col=col.here,
          #   xlim = c(0,x.max.spp),
          ylim = c(0,y.max.spp)#,
          #    family="Times"# New Roman"
  )
  
  graphics::abline(h=0,lwd=2)
  
  if(prod(!is.na(posi.all.groups.plot)) & posi.all.groups.plot=="bottomleft"){opar <- graphics::par(fig = c(0.05, 0.37, 0.05, 0.4), new = TRUE)}else{nada=999}  
  if(prod(!is.na(posi.all.groups.plot)) & posi.all.groups.plot=="topleft"){opar <- graphics::par(fig = c(0.05, 0.39, 0.6, 0.99), new = TRUE)}else{nada=999}  
  if(prod(!is.na(posi.all.groups.plot)) & posi.all.groups.plot=="topright"){opar <- graphics::par(fig = c(0.65, 0.99, 0.6, 0.99), new = TRUE)}else{nada=999}
  if(prod(!is.na(posi.all.groups.plot)) & posi.all.groups.plot=="bottomright"){opar <- graphics::par(fig = c(0.65, 0.99, 0.05, 0.4), new = TRUE)}else{nada=999}
  
  if(prod(is.na(posi.all.groups.plot))){opar <- graphics::par(fig = c(0.65, 0.99, 0.6, 0.99), new = TRUE)} else {nada=999}
  
  x.max <- x.max.spp #<- max(as.numeric(names(stand.table.total)))
  y.max  <- max(stand.table.total)
  
  if(prod(!is.na(max.y.all))){y.max=max.y.all} else {nada=999}
  
  graphics::barplot(stand.table.total,main="",col=col.bar.all, las=1,
          #   bty="l",
          #        xlim = c(0,x.max),
          ylim = c(0,y.max*1.1),
          #cex.axis = .6,
          cex.names = .8,
          axes = F,
          #  family="Times"# New Roman"
          
          # axisnames=F
          # bty="l",
          # col="gray",  pch=19, cex=0.2,
          # xaxs="i", yaxs="i"
  )
  
  
  at.y <- c(round(y.max*0.95/2,-2),round(y.max*.95,-2))
  
  #print(at.y)  
  
  
  if(prod(!is.na(at.N.all))){at.h=at.N.all} else {at.h=at.y}     
  #if(length(at.N.all)>0){at.h=at.N.all} else {at.h=at.y}  
  
  #print(at.h)  
  #print(class(at.h)) 
  
  at.h.lab<- as.character(at.h)
  #print(at.h.lab) 
  graphics::axis(2, at=at.h, #at.h, #labels = at.h.lab, 
       las=1, cex.axis=.8)
  #axis(2, at=at.y,labels = c("150","300","450","600"), las=1,
  #     cex.axis=1, family="Times")
  
  #axis(2, at=c(150,300,450,600),labels = c("150","300","450","600"), las=1,
  #     cex.axis=1, family="Times")
  graphics::abline(h=0)
  graphics::box()
  
  graphics::par(opar)
  
  #@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  #fin de funcion de distribucion diametrica
  
  output=stand.table.total #summary(db$dbh.class)     
  output
}
#---------------------------
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
