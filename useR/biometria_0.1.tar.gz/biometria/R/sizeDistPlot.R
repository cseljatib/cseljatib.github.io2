#' This function creates size distribution tables, where size is a random
#'  variable (in ecology this could be the biomass of a tree, or the weight
#'  of a bear), as well as graphic representations of those tables that we 
#'  refer to them as size distribituion plots. For instance, 
#'  in forest ecology the size distribution tables are usually refered as 
#'  "stand tables", and the size distribution plots as "diameter distribution"
#'  when the random variable tree diameter is used. 
#'
#'
#' @title Creates size distribution tables and size distribution plots
#' @param data a dataframe with at least the columns representing a variable of interest ("var.int"),
#'   the are of a given sample plot ("plot.area"), and a grouping variable ("group.var").
#' @param var.int is the name of the column having the size variable or variable of interest.
#' @param plot.area is the plot area, in m2, of the sample plot. 
#' @param w.amp a number for the size-variable class amplitud to be used in the plots. By default is equal to 10. 
#'  It is expressed in the same units that "var.int".
#' @param group.var the name of the column having the grouping variable (e.g., species or treatment).
#' @param at.N.all an optional vector containing the values of density to be
#'   drawn in the insert total level sizeDist plot
#' @param max.class.var.int  an optional numeric scalar containing the maximum class for the variable of interest "var.int"
#' @param max.y.all an optional numeric scalar containing the maximum level of the Y-axis
#' @param filenametablegroup a string specifying the name of the file where the stand table by group will be stored. The default
#'  is "standTableGroup". Two files will be saved, with both .out and .csv extensions.
#' @param filenametable a string specifying the name of the file where the stand table will be stored. The default
                         #'  is "standTable". Two files will be saved, with both .out and .csv extensions.
#' @param max.y.by.group an optional number specifying the maximum value to be used for the density of the main histogram of the figure (the one by the grouping #' #' variable "group.var").
#' @param posi.leg.group an optional string specifying the position of the legend. The default is "topright"
#' @param group.var a string with the name of the column having the grouping variable (e.g., species or treatment).
#' @param eng a logical value for the language of the axis. By default is set to TRUE, otherwise spanish is used.
#' @param ylab a string with the label used for the Y-axis.
#' @param xlab a string with the label used for the X-axis.
#' @param col.bar.all is the colour for the bars (when grouping variable is not defined) drawn in the insert total level sizeDist plot.
#' @param levels.i.want a string providing the name of the levels of the factor variable "group.var" to be used for the plotting. 
#' @param col.lev.i.want is a vector of length equal to the number of levels of the "group.var", specifying the colours to be used for each level.
#' @param metric a logical value if the Metric system is used. The default value is TRUE, otherwise the Imperial units are used.
#' @param unit.density  an optional string providing the name to be used for the Y-axis when plotting.
#' @param unit.var.int an optional string providing the name to be used for the X-axis when plotting.
#'
#' @return This function returns a plot, as well as two ouputs (file with extention ".out")
#' with the size distribution tables by the levels of the grouping variable, and the other
#' without considering any segregation.
#' @author Christian Salas-Eljatib
#' @note Be aware that this function has several options that can be specified by an user. 
#'  Be sure that all values of the variable of interest are available in the dataframe before of
#'  using the function.
#' @references - Husch B, TW Beers, JA Kershaw. 2003. Forest Mensuration. 4th edition. Wiley, New York, USA. 443 p.
#' @references  - Salas C, LeMay V, Nunez P, Pacheco P, Espinosa A. 2006. Spatial patterns
#'  in an old-growth Nothofagus obliqua forest in south-central Chile.
#'  Forest Ecology and Management 231:38-46
#' @examples
#' data(pspLlancahue); 
#' head(pspLlancahue)
#' pspLlancahue$area <- 70*130
#' sizeDistPlot(pspLlancahue, var.int="dbh", plot.area = "area")
#' sizeDistPlot(pspLlancahue, var.int="dbh", plot.area = "area", w.amp=5)
#' sizeDistPlot(pspLlancahue, var.int="dbh", plot.area = "area", group.var = "spp.name")
#' sizeDistPlot(pspLlancahue, var.int="dbh", plot.area = "area", group.var = "spp.name",
#'    col.lev.i.want =c("black","white","blue","gray","darkgreen","yellow"),
#'    max.class.var.int = 120, max.y.by.group = 250) 
#' @rdname sizeDistPlot
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
sizeDistPlot<-function(data=data, var.int=var.int, plot.area=plot.area, w.amp=10,at.N.all,
                       max.class.var.int=NA,max.y.all=NA,filenametablegroup="standTableGroup",
                       filenametable="standTable",
                       max.y.by.group=NA,posi.leg.group="topright",
                       group.var=NULL, eng=TRUE, ylab=NA, xlab=NA,col.bar.all="gray",
                       levels.i.want=FALSE, col.lev.i.want=FALSE, 
                       metric=TRUE, unit.density=NA, unit.var.int=NA){
#  require(lattice)
  #if(prod(is.na(metric))){metric=TRUE} 
  unit.density="(ind/ha)"
  if(metric==TRUE & prod(is.na(unit.density))){unit.density="(ind/ha)"}   
  if(metric!=TRUE & prod(is.na(unit.density))){unit.density="(ind/acre)"} 
  #	if(prod(is.na(unit.density))){unit.density=""} 	
  #if(prod(is.na(unit.density))&metric==TRUE){unit.density="(ind/ha)"} 
  #if(prod(is.na(unit.density))&metric==FALSE){unit.density="(ind/acre)"} 	
  #	if(prod(is.na(unit.var.int))){unit.var.int=""} 
  #	if(prod(is.na(unit.var.int))&metric==F){unit.var.int="(inches)"} 	
  
  #	if(prod(is.na(lty))){lty=2}  
  #	if(prod(is.na(lwd))){lwd=2}  
  db<-data  
  
  db$y<-db[,var.int]
  
  #ok.var.int <- is.numeric(db$y) 
  
  if(length(group.var)>0){db$g<-as.factor(db[,group.var]) } else {nada=0}
  if(length(group.var)>0){db$g<-droplevels(db$g)}
  
  # if(group.var==NULL){db$g<-db[,group.var] } else {nada=0}
  
  #ok.var.int <- is.numeric(db$y) 
  
  db$a<-db[,plot.area]
  db$frec <- 10000/db$a
  
  w<-w.amp
  
  #asignar las clases diametricas de cada arbol
  db$y.class <- (as.integer((db$y+((w/2)-0.1))/w))*w
  #en caso q ....
  db[db[,"y.class"]==0,"y.class"]=w
  
  lo.q.hay <- unique(db$y.class)
  lo.q.hay
  
  if(prod(is.na(max.class.var.int))){max.y.class<-  max(db$y.class) } else {max.y.class<-  max.class.var.int} 
  
  lim.inf.en.x <- 0 #min(db$y) #w/2
  clases.h <- #seq(lim.inf.en.x,(max.dbh.class+lim.inf.en.x), by=w)
    seq(lim.inf.en.x,(max.y.class+(w/2)), by=w)
  clases.h
  
  xlim.h <- range(clases.h) 
  xlim.h
  
  label.x <- (clases.h-lim.inf.en.x)
  label.x
  paso.x <- clases.h[2:length(clases.h)]-lim.inf.en.x
  paso.x
  label.x <- c("",paso.x)
  label.x
  
  lo.q.necesitamos <- unique(paso.x)
  lo.q.necesitamos
  
  x1 <- sort(lo.q.hay)
  y1 <- sort(lo.q.necesitamos)
  x1
  y1
  
  #se crea dataframe a nivel de  hectarea
  n.dap <- rep(db$y, db$frec)
  length(n.dap) 
  
  n.cd <- rep(db$y.class, db$frec)
  length(n.cd) 
  
  #n.anho <- rep(db$anhomed, db$frec)
  #length(n.anho) 
  
  if(length(group.var)==0){db$g <- "no.spp"} else {nada2=0}
  
  n.esp <- as.data.frame(rep(db$g, db$frec))
  length(n.esp)
  names(n.esp) <- "n.esp"
  
  n.ha <-as.data.frame(cbind(n.dap, n.cd, n.esp))
  
  utils::head(n.ha)
  
  #la densidad total es
  sum(table(n.ha$n.cd))
  
  if(length(group.var)>0){text.here <- paste("The selected factor-variable was: ", group.var, sep="")  }	else {
    text.here <- "Notice that no factor variable was choosen."} 
  
  text.here
  ######################################33
  if(sum(x1) != sum(y1)){
    #para identificar las CD que faltan y generar ficticiamente en nuestros datos
    db3 <- data.frame(y1)
    db3
    
    db3$cd.falt <- 1
    
    for(i in 1:length(x1)){
      db3[db3[,"y1"]==x1[i],"cd.falt"]=0}
    db3
    
    db4 <- subset(db3, cd.falt==1)
    db4
    
    unique(db4$y1) #aca estan las clases diametricas a agregar
    para.agregar <- unique(db4$y1)
    para.agregar
    
    #-----------------------------------------------------------------------
    #-----------------------------------------------------------------------
    #esto es para que posteriormente standtables posea
    #todas las clases diametricas, incluso aquellas para las cuales no hay datos, pero se
    # necesitan por asuntos graficos 
    n.esp2 <- unique(n.ha$n.esp)
    n.esp2
    n.cd2 <- length(unique(db4$y1))
    n.cd2
    
    new.esp<-rep(n.esp2, n.cd2)
    new.esp <- data.frame(new.esp)
    new.esp
    
    spp <- length(n.esp2)
    spp
    
    cd2 <- unique(db4$y1)
    cd2
    
    clase <- c()
    for(i in 1:length(cd2)){
      xx<-rep(cd2[i], spp)
      clase<-c(clase, xx)    
    }
    
    clase
    length(clase)
    length(new.esp$new.esp)
    
    n.dap2 <- rep(0, length(clase))
    n.dap2
    n.anho2 <- n.dap2
    n.anho2
    
    
    new.n.ha <- #data.frame(cbind(n.dap2, clase, n.anho2, new.esp))
      data.frame(cbind(n.dap2, clase, new.esp))
    utils::head(new.n.ha)
    colnames(new.n.ha) <- #c('n.dap','n.cd','n.anho','n.esp')
      c('n.dap','n.cd','n.esp')
    utils::head(new.n.ha)
    #str(new.n.ha)
    #str(n.ha)
    
    
    new.n.ha$n.esp<-"Eliminar"
    new.n.ha$n.esp<-as.character(new.n.ha$n.esp)
    new.n.ha$n.esp<-as.factor(new.n.ha$n.esp)
    #class(new.n.ha$n.esp)
    #class(n.ha$n.esp)
    
    
    #-----------------------------------------------------------------------
    #-----------------------------------------------------------------------
    #aca se junta data falsa con real 
    dim(n.ha)
    n.ha.st <- rbind(n.ha, new.n.ha)
    utils::head(n.ha.st)
    dim(n.ha.st)
    unique(n.ha.st$n.cd)
    
    #-----------------------------------------------------------------------
    #-----------------------------------------------------------------------
    #aca se se crea columna con valores verdares o falsos 
    #que sirven para generar tabla de rodal total  
    n.ha.st$total<-"f"
    
    for (i in 1:nrow(n.ha.st)){
      if(n.ha.st$n.esp[i] == "Eliminar"){n.ha.st$total[i] <- "false"} else{n.ha.st$total[i] <- "true" }
    }
    #unique(n.ha.st$n.anho)
    utils::head(n.ha.st)
    utils::tail(n.ha.st)
    #-----------------------------------------------------------------------
    #-----------------------------------------------------------------------
    #Stand table
    
    #The overal stand table (for all levels of the factor variable, no segregation is applied)
    table(n.ha.st$n.cd)
    
    stand.table.total0 <- table(n.ha.st$total, by = n.ha.st$n.cd)
    stand.table.total<-stand.table.total0[-1,]#Elimina Fila de datos falsos
    stand.table.total
    nha.tot <- sum(stand.table.total)
    
    
    a <- data.frame(db) 
    data.name <- deparse(substitute(a))
    #storage.mode(data)
    #names_of_dataframes <- ls.str(mode = "list")
    # see the name of the first dataframe
    #  data.name <- names_of_dataframes[1]
    
    begin.time<-Sys.time()                                  #|
    begin.times <- format(begin.time, "%a %b %d, %Y at %X") #|
    
    file.name <- paste(filenametable,".out",sep="")
    sink(file.name)
    (cat("==============","\n")    )
    cat("biometRics R package","\n")
    (cat("","\n")    )
    #cat("http://cseljatib.wixsite.com/biometria","\n")
    (cat("+++++++++++++++","\n")    )  
    cat("Date:", begin.times , "\n")
    cat(" R operative system:", R.version$os, "\n",
        R.version.string,"\n",
        'Working directory:',getwd(),"\n")
    cat(" Computer name:",Sys.info()["nodename"][1], " \n")
    (cat("+++++++++++++++","\n")    )
    (cat("==============","\n")    )  
    cat("This output file is about: Size distribution","\n")  
    cat("The selected size-variable was: ",var.int," \n")  
    cat("Total density is ",nha.tot," individuals/ha, distributed in the following size-classes:", "\n")  
    #cat("The size variable is: ",var.int, "from the dataframe: ", var.int ,"\n")  
    #cat("The dataframe is: ", (data.name)," \n")  
    (cat("-------------------","\n")    )
    print((stand.table.total))
    (cat("-------------------","\n")    )
    sink()
    
    tr.total <- as.data.frame(stand.table.total) 
    names(tr.total)[1] <- "n.ha"
    tr.total$y.class <- as.numeric(rownames(tr.total))
    names(tr.total)[2] <- paste(var.int,".class",sep="")
    
    names.y.class <- names(tr.total)[2]
    
    tr.total <- as.data.frame(tr.total)
    tr.total <- tr.total[,c(names.y.class,"n.ha")]
    
    file.name <- paste(filenametable,".csv",sep="")
    
    ff::write.csv(tr.total, file=file.name, row.names=F)
    
    #======================================
    #The stand table by species 
    stand.table0 <- table(n.ha.st$n.esp, by = n.ha.st$n.cd)
    stand.table0
    stand.table <-    stand.table0[-nrow(stand.table0),]#Elimina Fila de datos falsos
    stand.table
    sum(stand.table)
    
    ##write the datafile if group variable was choosen
    if(length(group.var)>0){ 
      tr.gr <- as.data.frame(stand.table) 
      names(tr.gr)[1] <- paste(group.var,sep="")
      names(tr.gr)[2] <- paste(var.int,".class",sep="")
      names(tr.gr)[3] <- "n.ha"
      #tr.gr$y.class <- as.numeric(rownames(tr.gr))
      #names(tr.gr)[2] <- paste(var.int,"class",sep="")
      
      #names.y.class <- names(tr.gr)[2]
      
      tr.gr <- as.data.frame(tr.gr)
      tr.gr <- tr.gr[order(tr.gr[,1]),] #order by factor first #tr.total[,c(names.y.class,"n.ha")]
      
      
      file.name <- paste(filenametablegroup,".csv",sep="")
      ff::write.csv(tr.gr, file=file.name, row.names=F)
      
    } else {nada=0}
    
    file.name <- paste(filenametablegroup,".out",sep="")
    sink(file.name)
    (cat("==============","\n")    )
    cat("biometRics R package","\n")
    (cat("","\n")    )
    #cat("http://cseljatib.wixsite.com/biometria","\n")
    (cat("+++++++++++++++","\n")    )  
    cat("Date:", begin.times , "\n")
    cat(" R operative system:", R.version$os, "\n",
        R.version.string,"\n",
        'Working directory:',getwd(),"\n")
    cat(" Computer name:",Sys.info()["nodename"][1], " \n")
    (cat("+++++++++++++++","\n")    )
    (cat("==============","\n")    )  
    cat("This output file is about: Size distribution by a factor variable","\n")  
    cat("The selected size-variable was: ",var.int," \n")  
    #if(length(group.var)==0){group.var.here <- "no factor variable was choosen"} else {group.var.here <- group.var}
    #if(length(group.var)>0){text.here <- paste("The selected factor-variable was: ", group.var, sep="")  }	else {
    #	text.here <- "Notice that no factor variable was choosen."} 
    
    cat(text.here," \n")  
    #cat(text.here"The selected factor-variable was: ",group.var.here," \n")  
    if(length(group.var)>0){
      cat("Total density is ",nha.tot," individuals/ha, distributed in the following size-classes and levels of the factor:", "\n")  } else {
        cat("Total density is ",nha.tot," individuals/ha, distributed in the following size-classes:", "\n") 
      }
    #cat("The size variable is: ",var.int, "from the dataframe: ", var.int ,"\n")  
    #cat("The dataframe is: ", (data.name)," \n")  
    (cat("-------------------","\n")    )
    print((stand.table))
    (cat("-------------------","\n")    )
    sink()
    
    
  } else {stand.table<-table(n.ha$n.esp, by = n.ha$n.cd)  
  
  stand.table.total<-table(n.ha$n.cd)} 
  
  if(is.null(group.var)==TRUE){ 
    out<-stand.table.total} else {out<- stand.table} #{print(stand.table)}
  
  if(is.null(group.var)==TRUE){ 
    text.out<-("This output is about: Size distribution")  } else {text.out<- "This output is about: Size distribution by a factor variable"} #{print(stand.table)}
  
  if(is.null(group.var)==TRUE){ 
    text.out2<-text.here } else {text.out2<- text.here}
  
  
  cat(text.out,"\n")
  cat("The selected size-variable was: ",var.int," \n")  
  cat(text.out2,"\n")
  (cat("-------------------","\n")    )
  print(out)
  #stand.table.total
  #stand.table
  
  
  
  #=============
  #3. Inicio de graficos
  #=============
  # para graficos
  lim.inf.en.x <- w.amp/2
  clases.h <- seq(lim.inf.en.x,(max.y.class+lim.inf.en.x), by=w.amp)
  clases.h
  
  xlim.h <- range(clases.h) 
  xlim.h
  
  label.x <- (clases.h-lim.inf.en.x)
  label.x
  paso.x <- clases.h[2:length(clases.h)]-lim.inf.en.x
  paso.x
  label.x <- c("",paso.x)
  label.x
  
  
  if(eng==T & prod(is.na(ylab))){ylab<-paste("Density ",unit.density,sep="")} else {nada=0}
  if(eng==F & prod(is.na(ylab))){ylab<-paste("Densidad ",unit.density,sep="")} else {nada=0}
  
  if(eng==T & prod(is.na(xlab)) &prod(!is.na(unit.var.int))){xlab<-paste(var.int,".class (",unit.var.int,")",sep="")} else {nada=0}
  if(eng==F & prod(is.na(xlab)) &prod(!is.na(unit.var.int))){xlab<-paste("Clase.",var.int," (",unit.var.int,")",sep="")} else {nada=0}
  
  if(eng==T & prod(is.na(xlab)) &prod(is.na(unit.var.int))){xlab<-paste(var.int,".class",sep="")} else {nada=0}
  if(eng==F & prod(is.na(xlab)) &prod(is.na(unit.var.int))){xlab<-paste("Clase.",var.int,sep="")} else {nada=0}
  
  #if(col==""){col <- 'gray' } else {nada=0}
  
  
  y.max  <- max(stand.table.total)
  if(prod(!is.na(max.y.all))){y.max=max.y.all} else {nada=999}
  
  if(is.null(group.var)==FALSE){ 
    
    y.max.spp  <- max(stand.table)
    
    
    if(prod(!is.na(max.y.by.group))){y.max.spp=max.y.by.group} else {nada=999}  
    
    num.gr.med <- length(unique(db$g))
    
    levels.aqui <- unique(db$g)
    if(class(levels.i.want)=="character"){levels.aqui <- levels.i.want}else{
      levels.aqui <- levels.aqui
    } 
    
    col.levels.aqui <-grDevices::terrain.colors(length(levels.aqui), alpha = 1)
    
    if(class(col.lev.i.want)=="character" & prod(is.na(levels.i.want)) & length(col.lev.i.want)!=length(levels.i.want)){
      stop("The length of objects levels.i.want and col.lev.i.want must be equal ")} 
    
    if(class(col.lev.i.want)=="character"){col.levels.aqui <- col.lev.i.want}else{
      col.levels.aqui <- col.levels.aqui
    } 
    
    #col.here<-rainbow(num.gr.med, alpha = 1)
    
    col.here <- col.levels.aqui
    
    #	if(col==""){col.here<-col} else {nada=66}
    
    #	col.here <- #terrain.colors(num.gr.med, alpha = 1)
    #	  rainbow(num.gr.med, alpha = 1)
    graphics::barplot(stand.table, ylim = c(0,y.max.spp*1.1),
            xlab=xlab, ylab=ylab, las=1,
            beside=T,col=col.here)
    graphics::abline(h=0)
    graphics::legend(posi.leg.group, #max(db$dbh.class)/1.3, max(stand.table)/1.2,
                    legend=rownames(stand.table),
           #fill=#terrain.colors(num.gr.med, alpha = 1), #
            # col.here,
           plot = TRUE)
    #histogram(~n.dap |  factor(n.esp), data=n.ha, as.table=T) #,    
    #            col=c('gray'),type='count', ylab=ylab, xlab=xlab,
    #            par.settings =
    #              list(cex=2, axis.text = list(font = 1, cex =
    #                                             1.0, col='black')),
    #            ylim=c(0,NA), breaks=clases.h,
    #             xlim=c(NA,NA) ) #xlim.h   ) 
    #  # breaks=clases.h,
    #  #scales = list(x = list(at = paso.x)),
    #  #xlim=c(NA,NA), ylim=c(0,NA) )
  } else { 
    graphics::barplot(stand.table.total, ylim = c(0,y.max*1.1), xlab=xlab, ylab=ylab, las=1,col=col.bar.all)
    graphics::abline(h=0)
    
    #histogram(~n.dap, data=n.ha,  as.table=T,# freq=T,          
    # col=c('gray'),type='count', ylab=ylab, xlab=xlab,
    #          breaks=clases.h,
    #          scales = list(x = list(at = paso.x)),
    #          xlim=c(NA,NA), ylim=c(0,NA) )
    
    ##write the datafile if group variable was choosen
    #if(length(group.var)==0){ 
  } #else {nada=11}
  
}
#---------------------------
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
