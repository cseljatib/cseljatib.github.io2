#' Gives a list of all the listed packages of an R session, and
#' their respective versions  
#'
#' No details are given
#' 
#' @title Computes basal area in larger trees
#' 
#' @return Returns a list of all the listed packages
#' @author Christian Salas-Eljatib
#' @examples
#' loaded.pack()
#' 
#' @rdname loaded.pack
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
loaded.pack <- function(){
  version=c()
  list.loaded.pack=(.packages()) 
  for(i in 1:length(list.loaded.pack)){
    pack.p=list.loaded.pack[i] 
    version.p=utils::packageDescription(list.loaded.pack[i])$Version
    paso=c(pack.p,version.p)
    version=rbind(version,paso)
  }
  version=data.frame(version,row.names=NULL)
  names(version)=c('Package','Version')
  cat("List of all loaded packages and their versions",'\n')
  cat("----------------------------------------------",'\n')
  version
}