pred.new.gls.corre<- function(ori.data, gls.mod.obj, myverbose){
output=c();  
  for(i in 1:nrow(ori.data))    
    {
if(myverbose==1){      
cat('Starting cross-validation for generalized least square model, observation No.',i,sep='','\n')} else {}      
# 1. selecting the data, taking out an observation
      dbnew=ori.data[-i,]
      #fitting the mixed-effects model for this new dataset

##obtaining the best correlation structure, and the best model
gls.new.corre= comparCorreFunc(gls.mod.obj,dbnew,1)

#      gls.new=update(gls.mod.obj, data=dbnew)
#      Betas.fix.gls=coef(gls.new)

mean.pred=stats::predict(gls.new.corre , newdata=ori.data[i,])

pred.i.out=mean.pred

pred.i.out0=cbind(pred.i.out)
output=rbind(output,pred.i.out0)     
#output=c(dagre,rmse)
#   names(output)=c('pred.value')
   output
}
}