#' Ratkowsky 
#'
#' Mathematical expression for the Ratkowsky function for relating variable Y versus X
#' @title Mathematical expression for the Ratkowsky function for relating variable Y versus X
#' @param params Vector with value of parameters at model (The values must be added in an orderly way, see example)
#' @param X Vector containing the values for the predictor variable
#' @param intercept Value of intercept of function. Default value is 0.
#'
#' @return The value of the function for every value of the vector X and the parameters.
#' @author Christian Salas.
#' @references - Zhang L (1997) Cross validation of non linear growth functions for modelling tree height diameter relationships. Annals of Botany 79(3) 251 257.
#' @examples
#'
#' b0<- 39.5
#' b1<- 21.12
#' b2<- 9.68
#' params<-c(b0,b1,b2) 
#' X <- c(70)
#' y<-ratkowsky(params,X,intercept=1.3)
#' plot(y~X,type='p')
#' 
#' @rdname ratkowsky  
#' @export
ratkowsky <- function (params, X,intercept=NA){
  if (is.na(intercept)==TRUE) {intercept=0}
  b0<-params[1]
  b1<-params[2]
  b2<-params[3]
  x<-X[1]
  y<-intercept + b0*exp(-b1/(x+b2))
}
