#' poder
#'
#' Mathematical expression for the Poder function for relating variable Y versus X
#' @title Mathematical expression for the Poder function for relating variable Y versus X
#' @param params Vector with value of parameters (The values must be added in an orderly way, see example)
#' @param X Vector containing the values for the predictor variable
#' @param intercept Value of intercept of function. Default value is 0.
#' 
#' @return The value of the function for every value of the vector X and the parameters.
#' @author Christian Salas.
#' @references Stage AR (1975) Prediction of height increment for models of forest growth. USDA For. Serv. Res. Pap.
#' INT164, USA. 20 p.
#' @examples
#'
#' b0<-5.22
#' b1<-0.43
#' params<-c(b0,b1) 
#' X <- c(70)
#' y<-poder(params,X,intercept=1.3)
#' plot(y~X,type='p')
#' 
#' @rdname poder 
#' @export
poder <-function (params, X, intercept=NA){
  b0<-params[1]
  b1<-params[2]
  x<-X[1]
  y<- intercept + b0*(x^b1) 
}
