#' For each plot and time calculates the following stand variables: density, basal area, quadratic diameter diameter, 
#' mean height, height of the dominant trees, and volume. 
#' 
#'   
#' 
#' @title Calculate stand variables for a given tree list 
#' @param data data frame having the tree list
#' @param area column name having the plot area in square meters
#' @param id column name with the plot code/number
#' @param categories column names of the variables used as factors to calculate the stand variables
#' @param t column name having the time variable, if not provided the current year is assigned as the time variable
#' @param d diameter at the breast-heigth, in centimeters
#' @param h total height in meters
#' @param v total volume in cubic meters
#' 
#' @return This function returns a data frame with the stand variables of each plot and time. If categories are given, 
#'  the result will be a data that will contain the previous one and will have the values of the stand variables for each 
#'  of the categories. 
#'  For the calculation of the height of the dominant trees, the TopHeight and Uestimator functions are used (Garcia, 2005).
#'  
#'  
#'  
#'  
#' @author Christian Salas-Eljatib and Joaquin Riquelme-Alarcon
#' @note In order to use this function, the packages 'dplyr' and 'data.table' must be previously installed.
#' @examples
#' #not yet implemented
#'
#' @rdname standVar
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
standVar <- function (data = data, area = sup, id = plot.id, categories = NA, 
                      t = NA, d = dap, h = h.m, v = vtot) 
{
  df <- data
  df$area <- df[, area]
  df$frec <- 10000/df[, area]
  df$d <- df[, d]
  df$h <- df[, h]
  df$id <- df[, id]
  df$g <- (df[, d]^2) * pi/40000
  df$g.ha <- df$g * df$frec
  df$v.ha <- df[, v] * df$frec
  catego <- prod(!is.na(categories))
  sv.names <- c("nha", "gha", "qmd", "hmed", "hdom", "ddom", "vha")
  if (is.na(t)) {
    df$t <- data.table::year(Sys.Date())
    t = "t"
  }
  else {
    else.1 = 1
  }
  if (!is.na(t)) {
    df$t <- df[, t]
  }
  else {
    else.2 = 2
  }
  grupos <- dplyr::group_by(df, id, t)
  out <- dplyr::summarise(grupos, sum(frec, na.rm = TRUE), 
                          sum(g.ha, na.rm = TRUE), 
                          sqrt((sum(g.ha, na.rm = TRUE)/sum(frec, 
                                                            na.rm = TRUE)) * (40000/pi)), 
                          mean(h, na.rm = TRUE), 
                          topHeight(sort(h), mean(area)/10000 * 100), 
                          topHeight(sort(d), mean(area)/10000 * 100), 
                          
                          sum(v.ha, 
                              na.rm = TRUE))
  out <- data.frame(out, stringsAsFactors = FALSE)
  names(out) <- c(id, t, sv.names)
  if (catego == TRUE) {
    for (i in 1:length(unique(categories))) {
      df$categoria.i <- df[, categories[i]]
      grupos.i <- dplyr::group_by(df, id, t, categoria.i)
      out.i <- dplyr::summarise(grupos.i, sum(frec, na.rm = TRUE), 
                                sum(g.ha, na.rm = TRUE), sqrt((sum(g.ha, na.rm = TRUE)/sum(frec, 
                                                                                           na.rm = TRUE)) * (40000/pi)), mean(h, na.rm = TRUE), 
                                topHeight(sort(h), mean(area)/10000 * 100), 
                                topHeight(sort(d), mean(area)/10000 * 100),
                                sum(v.ha, 
                                    na.rm = TRUE))
      out.i <- data.frame(out.i)
      names(out.i) <- c(id, t, "sub.categorie", sv.names)
      out.i$categorie <- categories[i]
      out.i$sub.categorie <- as.character(out.i$sub.categorie)
      if (i == 1) {
        out.categories <- out.i
      }
      else {
        sigue = 1
      }
      if (i != 1) {
        out.categories <- rbind(out.categories, out.i)
      }
      else {
        sigue = 2
      }
    }
    out$categorie <- "Total"
    out$sub.categorie <- "Total"
    out <- rbind(out, out.categories)
    out <- out[, c(id, t, "categorie", "sub.categorie", sv.names)]
  }
  else {
    aaa = 1
  }
  out
}