#' Computes relative density of forest plots from the study of Salas-Eljatib & Weiskittel (2018).
#' 
#' You must be careful in using it outside the range for which the model was built.
#' 
#' @title Computes relative density of forest plots from the study of Salas-Eljatib & Weiskittel (2018)
#' @param data a dataframe containing variables as columns
#' @param qmd indicates the name of the column having the quadratic mean diameter (in cm) of the sample plot
#' @param nha indicates the name of the column having the tree density (in trees/ha) of the sample plot
#'
#' @return This function returns a vector having the relative density value.
#' @author Christian Salas-Eljatib.
#' @references   Salas-Eljatib C, Weiskittel AR. 2018. Evaluation of modeling strategies for assessing self-thinning behavior and carrying
#'  capacity. Ecology and Evolution 8 (22): 10768-10779.
#' @examples
#'
#' #creating a fake dataframe
#' set.seed(1234)
#' plot.no <- 1:10 # plot ID column
#' dg <- round(rnorm(10,30,5),1)
#' tph <- round(rnorm(10,600,100),1)
#' df<-data.frame(plot.no,dg,tph)
#' #using the function
#' rdRoraco(data=df, qmd="dg", nha = "tph")
#' @rdname rdRoraco
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
rdRoraco<-function(data=data, qmd=qmd, nha=nha){
  db<-data  
  db$qmd<-db[,qmd]
  db$nha<-db[,nha]
  
  if(is.numeric(qmd)==FALSE)
    db$rd <- 100*(db$nha/exp(12.257-1.4742*log(db$qmd)))
  
  begin.time<-Sys.time()                                  #|
  begin.times <- format(begin.time, "%a %b %d, %Y at %X") #|
  
  sink("relativeDensity.out")
  (cat("==============","\n")    )
  cat("biometRics R package","\n")
  (cat("","\n")    )
  cat("http://cseljatib.wixsite.com/biometria","\n")
  (cat("+++++++++++++++","\n")    )  
  cat("Date:", begin.times , "\n")
  cat(" R operative system:", R.version$os, "\n",
      R.version.string,"\n",
      'Working directory:',getwd(),"\n")
  cat(" Computer name:",Sys.info()["nodename"][1], " \n")
  (cat("+++++++++++++++","\n")    )
  (cat("==============","\n")    )  
  cat("This output file is about: Relative density of forest plots","\n")  
  cat("The selected density-variable was: ",nha," \n")  #var.nha ========>nha
  cat("The selected mean diameter-variable was: ",qmd," \n")  #var.qmd ======> qmd
  cat("A summary statistics of the relative density is shown here", "\n")  
  #cat("The size variable is: ",var.int, "from the dataframe: ", var.int ,"\n")  
  #cat("The dataframe is: ", (data.name)," \n")  
  (cat("-------------------","\n")    )
  print((summary(db$rd)))
  (cat("-------------------","\n")    )
  sink()
  
  
  
  cat("This output is about: Relative density of forest plots","\n")
  cat("The selected density-variable was: ",nha," \n")             #var.nha =====> nha
  cat("The selected mean diameter-variable was: ",qmd," \n")       #var.nha =====> qmd
  cat("A summary statistics of the relative density is shown here", "\n")  
  (cat("-------------------","\n")    )
  print((summary(db$rd)))
  db$rd
}