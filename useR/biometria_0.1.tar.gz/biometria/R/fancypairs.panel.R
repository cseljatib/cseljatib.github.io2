#' This function is a modified version of pairs.panels() from library(psych). It proproduces a panel
#'  of mutiple dispersion plots.
#' 
#' Notice that the data must contain only numeric variables
#' 
#' @title Generates a multi panel dispersion plot panel with trend curves
#' @param x is a dataframe containing all the numeric variables to be used for drawing the panel plot
#' @param smooth a logical value for drawing smooth curves. Defauls is set to TRUE.
#' @param scale scales the correlation font by the size of the absolute correlation. Defauls is set to FALSE.
#' @param density a logical value for drawing a density curve. Defauls is set to TRUE.
#' @param ellipses a optional logical value for drawing an ellipse for the scatter-plots. Defauls is set to FALSE.
#' @param digits an optional numeric value for the digits to be used for drawing the correlation coefficient in the panel.
#'   Defauls is set to 2.
#' @param method a string giving the method to be used for computing the correlation coefficient. Defauls is set to "pearson".
#' @param pch The plot character (defaults to 20 which is a '.').
#' @param lm Plot the linear fit rather than the LOESS smoothed fits. The default is FALSE.
#' @param cor If plotting regressions, should correlations be reported? The default is TRUE.
#' @param jiggle Should the points be jittered before plotting? The default is FALSE.
#' @param factor factor for jittering (1-5), therefore only needed if "jiggle" is set to TRUE.
#' @param hist.col a string giving the color to be used for the histograms of the panel. Defauls is set to "blue".
#' @param show.points a logical value for drawing the points in the scatter-plots. Defauls is set to TRUE.
#' @param rug  a logical value for drawing the rugs in the histograms. Defauls is set to TRUE.
#' @param breaks a string giving the method to be used for obtaining the breaks of the histogram. Defauls is set to "Sturges".
#' @param cex.cor If this is specified, this will change the size of the text in the correlations. this 
#'  allows one to also change the size of the points in the plot by specifying the normal cex values. If just
#'  specifying cex, it will change the character size, if cex.cor is specified, then cex will function to change the point size.
#' @param wt If specified, then weight the correlations by a weights matrix (see note for some comments)
#' @param smoother If TRUE, then smooth.scatter the data points – slow but pretty with lots of subjects
#' @param stars a logical value for drawing starts for the significance of the correlation coefficient. Defauls is set to FALSE.
#' @param ci Draw confidence intervals for the linear model or for the loess fit, defaults to ci=FALSE. If confidence
#'   intervals are not drawn, the fitting function is lowess.
#' @param alpha an optional numeric value for the significance level. Defauls is set to 0.05.
#'
#' @return This function returns a multi-panel plot
#' @author From "pairs.panels" (library "psych"), and modified by Christian Salas-Eljatib.
#' @examples
#'
#' #df <- data.frame(x=runif(1000),y=rnorm(1000),z=rbeta(1000,.2,2),x3=rnorm(1000,mean=43,sd=10))
#' #fancypairs.panel.(df)
#' @rdname fancypairs.panel
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
fancypairs.panel <- function (x, smooth = TRUE, scale = FALSE, density = TRUE, ellipses = FALSE, 
                                   digits = 2, method = "pearson", pch = 20, lm = FALSE, cor = TRUE, 
                                   jiggle = FALSE, factor = 2, hist.col = "blue", show.points = TRUE, 
                                   rug = TRUE, breaks = "Sturges", cex.cor = 1, wt = NULL, smoother = FALSE, 
                                   stars = FALSE, ci = FALSE, alpha = 0.05) 
{
  #dev.off()
  "panel.hist.density" <- function(x) {
    usr <- graphics::par("usr")
    on.exit(graphics::par(usr))
    graphics::par(usr = c(usr[1], usr[2], 0, 1.5))
    tax <- table(x)
    if (length(tax) < 11) {
      breaks <- as.numeric(names(tax))
      y <- tax/max(tax)
      interbreak <- min(diff(breaks)) * (length(tax) - 
                                           1)/41
      graphics::rect(breaks - interbreak, 0, breaks + interbreak, 
           y, col = hist.col)
    }
    else {
      h <- graphics::hist(x, breaks = breaks, plot = FALSE)
      breaks <- h$breaks
      nB <- length(breaks)
      y <- h$counts
      y <- y/max(y)
      graphics::rect(breaks[-nB], 0, breaks[-1], y, col = hist.col)
    }
    if (density) {
      tryd <- try(d <- density(x, na.rm = TRUE, bw = "nrd", 
                               adjust = 1.2), silent = TRUE)
      if (class(tryd) != "try-error") {
        d$y <- d$y/max(d$y)
        graphics::lines(d)
      }
    }
    if (rug) 
      rug(x)
  }
  "panel.cor" <- function(x, y, digits = 2, prefix = "") {
    usr <- graphics::par("usr")
    on.exit(graphics::par(usr))
    graphics::par(usr = c(0, 1, 0, 1))
    if (is.null(wt)) {
      r <- stats::cor(x, y, use = "pairwise", method = method)
    }
    else {
      r <- cor.wt(data.frame(x, y), w = wt[, c(1:2)])$r[1, 
                                                        2]
    }
    txt <- format(c(round(r, digits), 0.123456789), digits = digits)[1]
    txt <- paste(prefix, txt, sep = "")
    if (stars) {
      pval <- r.test(sum(!is.na(x * y)), r)$p
      symp <- symnum(pval, corr = FALSE, cutpoints = c(0, 
                                                       0.001, 0.01, 0.05, 1), symbols = c("***", "**", 
                                                                                          "*", " "), legend = FALSE)
      txt <- paste0(txt, symp)
    }
    cex <- cex.cor * 0.8/(max(strwidth("0.12***"), strwidth(txt)))
    if (scale) {
      cex1 <- cex * abs(r)
      if (cex1 < 0.25) 
        cex1 <- 0.25
      text(0.5, 0.5, txt, cex = cex1)
    }
    else {
      text(0.5, 0.5, txt, cex = cex)
    }
  }
  "panel.smoother" <- function(x, y, pch = graphics::par("pch"), col.smooth = "red", col.points = "black",
                               span = 2/3, iter = 3, ...) {
    xm <- mean(x, na.rm = TRUE)
    ym <- mean(y, na.rm = TRUE)
    xs <- sd(x, na.rm = TRUE)
    ys <- sd(y, na.rm = TRUE)
    r = cor(x, y, use = "pairwise", method = method)
    if (jiggle) {
      x <- jitter(x, factor = factor)
      y <- jitter(y, factor = factor)
    }
    if (smoother) {
      smoothScatter(x, y, add = TRUE, nrpoints = 0)
    }
    else {
      if (show.points) 
        points(x, y, pch = pch, col= col.points)
    }
    ok <- is.finite(x) & is.finite(y)
    if (any(ok)) {
      if (smooth & ci) {
        lml <- loess(y ~ x, degree = 1, family = "symmetric")
        tempx <- data.frame(x = seq(min(x, na.rm = TRUE), 
                                    max(x, na.rm = TRUE), length.out = 47))
        pred <- predict(lml, newdata = tempx, se = TRUE)
        if (ci) {
          upperci <- pred$fit + confid * pred$se.fit
          lowerci <- pred$fit - confid * pred$se.fit
          polygon(c(tempx$x, rev(tempx$x)), c(lowerci, 
                                              rev(upperci)), col = adjustcolor("light grey", 
                                                                               alpha.f = 0.8), border = NA)
        }
        graphics::lines(tempx$x, pred$fit, col = col.smooth)
      }
      else {
        if (smooth) 
          graphics::lines(stats::lowess(x[ok], y[ok], f = span, 
                              iter = iter), col = col.smooth)
      }
    }
    if (ellipses) 
      draw.ellipse(xm, ym, xs, ys, r, col.smooth = col.smooth)
  }
  "panel.lm" <- function(x, y, pch = graphics::par("pch"), col.lm = "red") {
    ymin <- min(y)
    ymax <- max(y)
    xmin <- min(x)
    xmax <- max(x)
    ylim <- c(min(ymin, xmin), max(ymax, xmax))
    xlim <- ylim
    if (jiggle) {
      x <- jitter(x, factor = factor)
      y <- jitter(y, factor = factor)
    }
    if (smoother) {
      smoothScatter(x, y, add = TRUE, nrpoints = 0)
    }
    else {
      if (show.points) {
        points(x, y, pch = pch, ylim = ylim, xlim = xlim)
      }
    }
    ok <- is.finite(x) & is.finite(y)
    if (any(ok)) {
      lml <- lm(y ~ x)
      if (ci) {
        tempx <- data.frame(x = seq(min(x, na.rm = TRUE), 
                                    max(x, na.rm = TRUE), length.out = 47))
        pred <- predict.lm(lml, newdata = tempx, se.fit = TRUE)
        upperci <- pred$fit + confid * pred$se.fit
        lowerci <- pred$fit - confid * pred$se.fit
        polygon(c(tempx$x, rev(tempx$x)), c(lowerci, 
                                            rev(upperci)), col = adjustcolor("light grey", 
                                                                             alpha.f = 0.8), border = NA)
      }
      if (ellipses) {
        xm <- mean(x, na.rm = TRUE)
        ym <- mean(y, na.rm = TRUE)
        xs <- sd(x, na.rm = TRUE)
        ys <- sd(y, na.rm = TRUE)
        r = cor(x, y, use = "pairwise", method = method)
        draw.ellipse(xm, ym, xs, ys, r, col.smooth = col.lm)
      }
      abline(lml, col = col.lm)
    }
  }
  "draw.ellipse" <- function(x = 0, y = 0, xs = 1, ys = 1, 
                             r = 0, col.smooth, add = TRUE, segments = 51) {
    angles <- (0:segments) * 2 * pi/segments
    unit.circle <- cbind(cos(angles), sin(angles))
    if (!is.na(r)) {
      if (abs(r) > 0) 
        theta <- sign(r)/sqrt(2)
      else theta = 1/sqrt(2)
      shape <- diag(c(sqrt(1 + r), sqrt(1 - r))) %*% matrix(c(theta, 
                                                              theta, -theta, theta), ncol = 2, byrow = TRUE)
      ellipse <- unit.circle %*% shape
      ellipse[, 1] <- ellipse[, 1] * xs + x
      ellipse[, 2] <- ellipse[, 2] * ys + y
      if (show.points) 
        points(x, y, pch = 19, col = col.smooth, cex = 1.5)
      graphics::lines(ellipse)
    }
  }
  "panel.ellipse" <- function(x, y, pch = graphics::par("pch"), col.smooth = "red") {
    segments = 51
    usr <- graphics::par("usr")
    on.exit(graphics::par(usr))
    graphics::par(usr = c(usr[1] - abs(0.05 * usr[1]), usr[2] + abs(0.05 * 
                                                            usr[2]), 0, 1.5))
    xm <- mean(x, na.rm = TRUE)
    ym <- mean(y, na.rm = TRUE)
    xs <- sd(x, na.rm = TRUE)
    ys <- sd(y, na.rm = TRUE)
    r = cor(x, y, use = "pairwise", method = method)
    if (jiggle) {
      x <- jitter(x, factor = factor)
      y <- jitter(y, factor = factor)
    }
    if (smoother) {
      smoothScatter(x, y, add = TRUE, nrpoints = 0)
    }
    else {
      if (show.points) {
        points(x, y, pch = pch)
      }
    }
    angles <- (0:segments) * 2 * pi/segments
    unit.circle <- cbind(cos(angles), sin(angles))
    if (!is.na(r)) {
      if (abs(r) > 0) 
        theta <- sign(r)/sqrt(2)
      else theta = 1/sqrt(2)
      shape <- diag(c(sqrt(1 + r), sqrt(1 - r))) %*% matrix(c(theta, 
                                                              theta, -theta, theta), ncol = 2, byrow = TRUE)
      ellipse <- unit.circle %*% shape
      ellipse[, 1] <- ellipse[, 1] * xs + xm
      ellipse[, 2] <- ellipse[, 2] * ys + ym
      points(xm, ym, pch = 19, col = col.smooth, cex = 1.5)
      if (ellipses) 
        graphics::lines(ellipse)
    }
  }
  old.par <- graphics::par(no.readonly = TRUE)
  on.exit(graphics::par(old.par))
  if (missing(cex.cor)) 
    cex.cor <- 1
  for (i in 1:ncol(x)) {
    if (is.character(x[[i]])) {
      x[[i]] <- as.numeric(as.factor(x[[i]]))
      colnames(x)[i] <- paste(colnames(x)[i], "*", sep = "")
    }
  }
  n.obs <- nrow(x)
  confid <- qt(1 - alpha/2, n.obs - 2)
  if (!lm) {
    if (cor) {
      graphics::pairs(x, diag.panel = panel.hist.density, upper.panel = panel.cor, 
            lower.panel = panel.smoother, pch = pch, ...)
    }
    else {
      graphics::pairs(x, diag.panel = panel.hist.density, upper.panel = panel.smoother, 
            lower.panel = panel.smoother, pch = pch)
    }
  }
  else {
    if (!cor) {
      graphics::pairs(x, diag.panel = panel.hist.density, upper.panel = panel.lm, 
            lower.panel = panel.lm, pch = pch)
    }
    else {
      graphics::pairs(x, diag.panel = panel.hist.density, upper.panel = panel.cor, 
            lower.panel = panel.lm, pch = pch)
    }
  }
}
