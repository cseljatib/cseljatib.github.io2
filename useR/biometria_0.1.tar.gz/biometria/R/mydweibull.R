mydweibull<-deriv(~(shape/scale)*(d/scale)^(shape-1)*exp(-(d/scale)^shape),
                  c("shape","scale"),function(d,shape,scale){})