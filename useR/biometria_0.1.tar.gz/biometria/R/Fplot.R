Fplot <-function(Fest.out,Fenve.out,unit.dist){                                            #
F.est<-Fest.out$rs;F.low<-Fenve.out$lo;F.high<-Fenve.out$hi                                 #
# Starting the plot                                                                         #
#x.range=c(min(Fest.out$r),max(Fest.out$r));y.range=c(min(F.low,F.est),max(F.high,F.est));  #
x.range=c(min(Fest.out$r),max(Fest.out$r));y.range=c(0,1);                                  #
graphics::plot(Fest.out$r,F.est,type='l',xlim=x.range,ylim=y.range,main="",                           #
xlab=paste("Distance t, in ",unit.dist),ylab=expression(italic(hat(F)(t))));
graphics::par(new=T);    #  
graphics::plot(Fest.out$r,F.low,type='l',xlim=x.range,ylim=y.range,main="",xlab="",ylab="",lty=2)     #
graphics::par(new=T);                                                                                 #
graphics::plot(Fest.out$r,F.high,type='l',xlim=x.range,ylim=y.range,main="",xlab="",ylab="",lty=2)} 