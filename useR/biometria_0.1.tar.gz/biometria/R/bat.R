#' Computes the basal area in taller trees (BAT) for any given tree within a sample plot. The 
#'  BAT is similar to BAL (basal area in larger trees), but here the reference variable is height
#'  instead of tree basal area.
#' 
#' @title Computes basal area in taller trees (BAT)
#' @param data data frame having plot level data
#' @param dbh column name having the diameter at breast height on trees in centimeters
#' @param h column name having the height of trees in meters
#' @param plot.area column name containing the plot size in square meters
#' 
#' @return This function returns a data frame with two columns, the first is BAT
#'  and the second the percentile of BAT
#' @author Christian Salas-Eljatib
#' @examples
#' #df<-data(pinaster)
#' #head(df)
#' #df$sup<-500
#' #bat(data=df,dbh='dbh',h = 'htot',plot.area = 'sup')
#' 
#' @rdname bat
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
bat <- function(data=data, dbh=dbh, h=h, plot.area=plot.area) {
  df <- data
  df$a<-df[,plot.area]
  df$frec <- 10000/df$a
  df$dbh<-df[,dbh]
  df$h<-df[,h]
  df$g <- df$dbh^2*pi/40000
  df$tree.gha <- df$g*df$frec
  sumba <- sum(df$tree.gha)  #stand or plot basal area
  bashortereq <- 0
  p.bat <- 0 #percentil of BAT
  bat <- 0
  for (i in 1 : length(df$tree.gha)) {
    bax <- df$h[i]
    bashortereq <- sum(df$tree.gha[df$h <= bax])
    bat[i] <- sumba - bashortereq
    p.bat[i] <- bashortereq / sumba #percentile of BAT
  }
  out<- data.frame(bat,p.bat)
  return(out)
}
