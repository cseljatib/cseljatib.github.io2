valesta.nls2 <- function(n.par,y.pred,y.obs){
  n=length(y.pred)
  med.y <- mean(y.obs)
  res.y=y.obs-y.pred
  res.y.2=(y.obs-y.pred)^2
  df<-n+1-n.par
  rmse=sqrt( sum(res.y.2)/df )
  rmse.p=(rmse/med.y)*100
  rmse=c(rmse,rmse.p)
  rmsd=sqrt(sum(res.y.2)/n )
  rmsd.p=(rmsd/med.y)*100
  rmsd=c(rmsd,rmsd.p)
  dagre=sum(res.y)/n
  dagre.p=(dagre/med.y)*100
  dagre=c(dagre,dagre.p)
  difa=sum(abs(res.y))/n
  difa.p=(difa/med.y)*100
  difa=c(difa,difa.p)
  output=c(rmse,rmsd,dagre,difa)
  names(output)=c('rmse','rmseP','rmsd','rmsdP','dagre','dagreP','difa','difaP')
  output}    