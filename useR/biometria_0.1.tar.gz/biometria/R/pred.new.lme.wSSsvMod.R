pred.new.lme.wSSsvMod <- function(ori.data,mix.mod.obj,varXlme,myverbose){
# varXlme must be the tipe of cbind(dbase$stand ,dbase$band3, dbase$band7)                    
output=c();  
  for(i in 1:nrow(ori.data))    
    {
if(myverbose==1){      
cat('Starting cross-validation for mixed-effects models, observation No.',i,sep='','\n')} else {}      
# 1. selecting the data, taking out an observation
      dbnew=ori.data[-i,]
      #fitting the mixed-effects model for this new dataset      
      lme.new=stats::update(mix.mod.obj,data=dbnew)
      Betas.fix.lme=lme4::fixef(lme.new)

# 2. fitting the Model to estimate the mixed-effects
      db.random=lme4::ranef(lme.new,augFrame=TRUE)   
      b0.average <- lme4::fixef(lme.new)[1]
      b0.average
      names(db.random)[1]=c('b0.dev')
#db.random$b0.spec <- (db.random$b0.dev+b0.average)
# this is for do not re-write everything again
db.random$EL <-db.random$eleve
db.random$SL <-db.random$slope
db.random$ASP <-db.random$aspect
#db.random$cos.ASP <- cos((db.random$ASP*pi/180))
#db.random$sin.ASP <- sin((db.random$ASP*pi/180))

# Fitting a regression model between the specified Asym-paramter
 #sv.new <- stagesalasSVmod(db.random,db.random$b0.spec)
#sv.new <- stagesalasSVmod(db.random,db.random$b0.dev,db.random$stand)
sv.new <- stagesalasSVmod(db.random,db.random$b0.dev,db.random$group.factor)
using.groups.sv=1
 Betas.fix.sv=stats::coefficients(sv.new)      
 
#mean prediction of the LME model for this new observation
num.p=ncol(varXlme)
if(num.p==1){
 new.pred.value.lme=data.frame(cbind(1,varXlme[i,]))} else {
new.pred.value.lme=data.frame(c(1,varXlme[i,]))      }

#new.predictors.value%*%Betas.fix.lme
if(num.p==1){
mean.pred=as.matrix(new.pred.value.lme)%*%as.matrix(Betas.fix.lme)} else {
  mean.pred=as.matrix(t(new.pred.value.lme))%*%as.matrix(Betas.fix.lme)
}

#prediction of the random-effects
if(using.groups.sv==0){
reff.pred= stats::predict(sv.new,newdata=ori.data[i,])    } else {
     #Start of if: SV model with factor variable
  num.coef.for.factor.variable=length(levels(db.random$group.factor))-1
  # i. Getting the Parameters estimated for Habitat type
summary(sv.new)

  Betas.fix.sv=stats::coefficients(sv.new)      

beta.group.intercepet <- Betas.fix.sv[1]
beta.groups <-Betas.fix.sv[2:(2+num.coef.for.factor.variable-1)] 
  loc.param=0

loc.param=2+length(beta.groups)
#  ii. Getting the Parameters estimated for Slope/Aspect
beta.EL <- Betas.fix.sv[loc.param]
beta.EL
  loc.param=loc.param+1
beta.EL2 <-  Betas.fix.sv[loc.param]
beta.EL2
    loc.param=loc.param+1
beta.SL <- Betas.fix.sv[loc.param]#beta.Asym.hat.SV[10]
beta.SL  
    loc.param=loc.param+1
beta.SL.cos.ASP <-  Betas.fix.sv[loc.param]# beta.Asym.hat.SV[11]
beta.SL.cos.ASP
    loc.param=loc.param+1
beta.SL.sin.ASP <-  Betas.fix.sv[loc.param]#beta.Asym.hat.SV[12]
beta.SL.sin.ASP
    loc.param=loc.param+1
beta.SL.ln.EL <-  Betas.fix.sv[loc.param]#beta.Asym.hat.SV[13]
beta.SL.ln.EL
    loc.param=loc.param+1
beta.SL.ln.EL.cos.ASP <-  Betas.fix.sv[loc.param]#beta.Asym.hat.SV[14]
beta.SL.ln.EL.cos.ASP
    loc.param=loc.param+1
beta.SL.ln.EL.sin.ASP <-  Betas.fix.sv[loc.param]#beta.Asym.hat.SV[15]
beta.SL.ln.EL.sin.ASP
    loc.param=loc.param+1
beta.SL.EL2 <-  Betas.fix.sv[loc.param]#beta.Asym.hat.SV[16]
beta.SL.EL2
    loc.param=loc.param+1
beta.SL.EL2.cos.ASP <-  Betas.fix.sv[loc.param]#beta.Asym.hat.SV[17]
beta.SL.EL2.cos.ASP
    loc.param=loc.param+1
beta.SL.EL2.sin.ASP <-  Betas.fix.sv[loc.param]#beta.Asym.hat.SV[18]
beta.SL.EL2.sin.ASP
  
betas.sv=c(beta.group.intercepet,beta.groups,beta.EL,beta.EL2,beta.SL,beta.SL.cos.ASP,beta.SL.sin.ASP,beta.SL.ln.EL,beta.SL.ln.EL.cos.ASP,beta.SL.ln.EL.sin.ASP,beta.SL.EL2,beta.SL.EL2.cos.ASP,beta.SL.EL2.sin.ASP)
  # iii. adding the new column beta.hab.ba to the database (trees) using the SV model
# creating these new variables
  
#creating a vector with the betas for the respective hab.types
  for(z in 1:length(levels(ori.data$group.factor))){
    if(ori.data[i,'group.factor']==levels(ori.data$group.factor)[1]){
       beta.group=0
     } else {
       beta.group=#dbase[dbase[i,"group.factor"]==levels(db.random$group.facor)[z],"beta.hab"]=
         betas.sv[z]
     } }
         
# Imputing the random-effect
reff.pred <- ( beta.group.intercepet
                      + beta.group
                      + beta.EL*(ori.data$EL[i]) 
                      + beta.EL2*(ori.data$EL[i]^2)
                      + beta.SL*(ori.data$SL[i]) 
                      + beta.SL.cos.ASP*(ori.data$SL[i]*  ori.data$cos.ASP[i])
                      + beta.SL.sin.ASP*(ori.data$SL[i]*  ori.data$sin.ASP[i])
                      + beta.SL.ln.EL*(ori.data$SL[i]*(log( ori.data$EL[i]))) 
   + beta.SL.ln.EL.cos.ASP*(  ori.data$SL[i]*(log(  ori.data$EL[i]))*  ori.data$cos.ASP[i]) 
   + beta.SL.ln.EL.sin.ASP*(  ori.data$SL[i]*(log(  ori.data$EL[i]))*  ori.data$sin.ASP[i])
   + beta.SL.EL2*(ori.data$SL[i]*(ori.data$EL[i]^2)) 
   + beta.SL.EL2.cos.ASP*(  ori.data$SL[i]*(  ori.data$EL[i]^2)*  ori.data$cos.ASP[i])
   + beta.SL.EL2.sin.ASP*(  ori.data$SL[i]*(  ori.data$EL[i]^2)*  ori.data$sin.ASP[i])
                      )

# reff.pred
}      #End of if: SV model with factor variable

pred.i.out=mean.pred+reff.pred

pred.i.out0=cbind(mean.pred,reff.pred,pred.i.out)
#      output=c(output,pred.i.out)
   output=rbind(output,pred.i.out0)     
#output=c(dagre,rmse)
#   names(output)=c('pred.value')
   output
}
}