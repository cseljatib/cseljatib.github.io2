#' Modificated-exponential-v2 
#'
#' Mathematical expression for the exponential function for relating variable Y versus X
#' @title Mathematical expression for the exponential function for relating variable Y versus X
#' @param params Vector with value of parameters (The values must be added in an orderly way, see example)
#' @param X Vector containing the values for the predictor variable
#' @param intercept Value of intercept of function. Default value is 0.
#'
#' @return The value of the function for every value of the vector X and the parameters.
#' @author Christian Salas.
#' @examples
#'
#' b0<-0.1
#' b1<-0.2
#' b2<-0.3
#' b3<-0.4
#' params<-c(b0,b1,b2,b3) 
#' X <- c(70)
#' y<-expModV2(params,X,intercept=1.3)
#' plot(y~X,type='p')
#' 
#' @rdname expModV2  
#' @export
expModV2<-function(params,X,intercept=NA){
  if (is.na(intercept)==TRUE){intercept=0}
  b0<-params[1]
  b1<-params[2]
  b2<-params[3]
  b3<-params[4]
  x<-X[1]
  y<-intercept+b0*exp(-b1/((x^b2)+b3))
}
