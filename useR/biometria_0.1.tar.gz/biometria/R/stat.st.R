#' Statistics for a Stratified Random Sample without replacement
#' 
#'   
#' @title Statistics for a Stratified Random Sample without replacement
#' @param tau.yh is the total value of the variable at the h-th stratum
#' @param n is the sample size
#' @param var.yh is the variance of the variable at the h-th stratum
#' @param conf is the confidence level in (percentage) for building the confidence intervals
#' @param total put 0 when computing at the stratum level, and 1 at the TOTAL level
#' @param L is the total numbers of stratum used
#' @return Statistics for a Stratified Random Sample without replacement
#' @author Christian Salas-Eljatib
#' @examples
#' #not yet implemented
#' 
#' @rdname stat.st
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
stat.st <- function(tau.yh,n,var.yh,conf,total,L){
#       {if(total==0) df=n-L else df=n-1}
      df=total*(n-L)+(n-1)
      sd.yh <- sqrt(var.yh)
      alpha=1-(conf/100)
      p=1-(alpha/2)
      ttab<- stats::qt(p, df)
      sam.error <- ttab*sd.yh
      low.tau.yh <- tau.yh - sam.error
      upp.tau.yh <- tau.yh + sam.error
       CI <- c(low.tau.yh,upp.tau.yh)
       names(CI) <- c("Lower value", "Upper value")
       CI
}