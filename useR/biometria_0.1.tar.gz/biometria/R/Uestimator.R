#' Calculate the U estimator
#'    
#' Calculate the U estimator
#' @title Calculate the height of the dominant trees in a stand 
#' @param heights vector or list of tree heights, sorted by increasing dbh
#' @param trees.per.are length(heights) / (plot area in ares).  If not integer, it is rounded to the nearest integer, with a warning.
#' 
#' @return   Calculate U-estimator, for integer trees/are 
#' @author Christian Salas-Eljatib and Joaquin Riquelme-Alarcon
#' @note see topHeight() 
#'
#' @references Garcia,O. and Batho,A. Western Journal of Applied Forestry 20(1), 64-68. 2005.
#'
#' @examples 
#' 
#' N <- 760
#' A <- 0.03
#' n <- round(N * A)
#' heights <- sort(rnorm(n, 15, 4))
#' m <- round(n / (100 * A))
#' trees.per.are<-m
#' choose(n, m)    # subsets
#' Uestimator(heights, trees.per.are)
#' @rdname Uestimator
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
Uestimator <- function(heights, trees.per.are) {
  m <- round(trees.per.are)
  if (m != trees.per.are) warning("trees.per.are = ", trees.per.are, " has been rounded")
  sum(choose(0:(length(heights) - 1), m - 1) * heights) / choose(length(heights), m)
}
