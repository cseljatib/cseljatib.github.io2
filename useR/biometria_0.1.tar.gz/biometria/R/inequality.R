#'Index of inequality 
#'
#' @title calculate different index about inequality of a variable, for example IBA,GINI,Atkinson.
#' @param data dataframe with variables
#' @param dbh diameter of tree
#' @param superficie surface of plot 
#' @param tolerancia type of tolerant at shade
#' @param esp especie of tree
#' @param ref.og.nha column name containing reference value of density plot for forest old growth
#' @param ref.og.gha column name containing reference value of basal area plot for forest old growth
#' @param ref.og.gha.80 column name containing reference value of density plot for forest old growth
#' @param ref.og.gha.tol column name containing reference value of density plot for forest old growth
#' @param ref.og.gini column name containing reference value of gini coefficient of plot for forest old growth
#' @param ref.sg.nha column name containing reference value of density plot for forest secundary growth
#' @param ref.sg.gha column name containing reference value of basa area plot for forest secundary growth
#' @param ref.sg.gha.80 column name containing reference value of density plot for forest secundary growth
#' @param ref.sg.gha.tol column name containing reference value of density plot for forest secundary growth
#' @param ref.sg.gini column name containing reference value of density plot for forest secondary growth
#'
#'
#' @return This function returns the iba value, with the different variables that employing for the calculate index
#' @author Christian Salas-Eljatib and Nicolas Pino
#' @examples
#' 
#' #df<-data.frame(d=rnorm(10,mean=80,sd=20))
#' #df$supe<-1200
#' #df$tol<-sample(x=c('SI','NO'),size = nrow(df),replace=TRUE)#input
#'
#' 
#' @rdname inequality
#' @export
#'
inequality<-function(data=data,dbh=dbh,superficie=superficie,tolerancia=NA,esp=esp,
                     ref.og.nha=NA,ref.og.gha=NA,ref.og.gha.80=NA,ref.og.gha.tol=NA,ref.og.gini=NA,
                     ref.sg.nha=NA,ref.sg.gha=NA,ref.sg.gha.80=NA,ref.sg.gha.tol=NA,ref.sg.gini=NA){
  
  # datos recopilados desde paper de Diego Ponce et al 2019  
  
  if(is.na(ref.og.nha)==TRUE){ref.og.nha=1014}
  if(is.na(ref.og.gha)==TRUE){ref.og.gha=85.82}
  if(is.na(ref.og.gha.80)==TRUE){ref.og.gha.80=37.7}
  if(is.na(ref.og.gha.tol)==TRUE){ref.og.gha.tol=48.75}
  if(is.na(ref.og.gini)==TRUE){ref.og.gini=0.8}
  
  if(is.na(ref.sg.nha)==TRUE){ref.sg.nha=2052}
  if(is.na(ref.sg.gha)==TRUE){ref.sg.gha=66.02}
  if(is.na(ref.sg.gha.80)==TRUE){ref.sg.gha.80=0}
  if(is.na(ref.sg.gha.tol)==TRUE){ref.sg.gha.tol=6.22}
  if(is.na(ref.sg.gini)==TRUE){ref.sg.gini=0.63}
  
  
  db<-data
  if(is.na(tolerancia)==FALSE){db$tolerancia<-db[,tolerancia]}
  db$dbh<-db[,dbh]
  db$superficie<-db[,superficie]
  db$esp<-db[,esp]
  
  if(is.na(tolerancia)==TRUE){db<-assignsTol(data = db, name.esp = "esp")
  db$tolerancia<-db$shadeTolerance}
  
  dbh_iba<-80         #'  # paper recomienda sobre 80
  a=unique(db$superficie)  #'    # input deberia venir en el set de datos de entrada
  freq<-10000/a
  
  ref.og<-list(ref.og.nha,ref.og.gha,ref.og.gha.80,ref.og.gha.tol,ref.og.gini)
  ref.sg<-list(ref.sg.nha,ref.sg.gha,ref.sg.gha.80,ref.sg.gha.tol,ref.sg.gini)
  
  #Calculo variable densidad total
  nha<-freq*(sum(nrow(db)))
  
  #Calculo variable "area basal de parcela y a nivel individual"
  gha<-freq*sum((pi*(db$dbh)^2)/40000)
  db$gha.tree<-(pi*(db$dbh)^2)/40000
  
  #Calculo variable "area basal, arboles con dap mayores a 80" sugerida por el paper
  gha.80<-freq*sum(pi*db$dbh[db$dbh>80]^2/40000)
  
  #Calculo variable "area basal 
  gha.tol<-freq*sum((pi*(db$dbh[db$tolerancia=='Shade-tolerant'])^2)/40000)
  
  #Calculo Gini
  gini<-ineq::Gini(db$gha.tree, corr = FALSE, na.rm = TRUE)                    #function ineq
  #calculo iba
  var.iba<-list(nha,gha,gha.80,gha.tol,gini)
  #var.iba<-list(unique(db$N),unique(db$G),unique(db$G_dap),unique(db$G_tol))
  k=1
  iba<-0
  for (i in var.iba) {
    #Condiciones respecto a bosque secundario.
    if (k!=1 & i<ref.sg[[k]]) {
      i=ref.sg[[k]]
    }
    if (k==1  & i>ref.sg[[k]]) {
      i=ref.sg[[k]]
    }
    #Condiciones respecto a bosque adulto
    if (k!=1 & i > ref.og[[k]]){
      i=ref.og[[k]]
    }
    if (k==1 & i < ref.og[[k]]) {
      i=ref.og[[k]]
    }
    aux0<-abs((i-ref.sg[[k]])/(ref.og[[k]]-ref.sg[[k]]))
    iba<-aux0+iba
    k=k+1
  }
  iba<-(100/length(var.iba))*iba
  #indices funcion ineq
  concentration<-ineq::conc(db$gha.tree, na.rm = TRUE)
  rs<-ineq::RS(db$gha.tree, na.rm = TRUE)
  atkinson<-ineq::Atkinson(db$gha.tree, parameter = 0.5, na.rm = TRUE)
  theil<-ineq::Theil(db$gha.tree, parameter = 0, na.rm = TRUE)
  kolm<-ineq::Kolm(db$gha.tree, parameter = 1, na.rm = TRUE)
  var.coef<-ineq::var.coeff(db$gha.tree, square = FALSE, na.rm = TRUE)
  entrop<-ineq::entropy(db$gha.tree, parameter = 0.5, na.rm = TRUE)
  out=data.frame(nha=nha,gha=gha,gha.80=gha.80,gha.tol=gha.tol,gini=gini,rs=rs,atkinson=atkinson,
                 theil=theil,kolm=kolm,var.coef=var.coef,entrop=entrop,concentration=concentration,iba=iba)
  return(out)
} 
