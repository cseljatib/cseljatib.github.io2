#' This function assings dominance of species by tree density and stand basal area.
#'
#'
#' @title Assing dominance of species by tree density and stand basal area.
#' @param data a dataframe having the stand-level variables per plot. The style of the file must be "nha.sppname1" and "gha.sppname1"
#'   to represent tree density and basal area of "sppname1", respectively. Notice that each row must be a unique sample plot.
#' @param num.def.dom the number of positions that define dominance. By default is equal to 3, and the possibles values are 1, 2, or 3.
#'
#' @return This function returns a dataframe having the following columns: plot.id, list.of.species, dom.by.nha and dom.by.gha.
#' @author Christian Salas-Eljatib
#' @note Be sure to prepare the input data as requested.
#' @examples
#' n <-7; plot <- 1:n
#' nha <- runif(n, 850, 2500); gha <- runif(n, 20, 45)
#' nha.Roble <- c(0.5, 0.2, 0.1,0.4,0,0,0)*nha
#' gha.Roble <- c(0.7, 0.2,0.1,0.3,0,0,0)*gha
#' nha.Rauli <- c(0.35, 0.6,0.2,0.5,0,0,0.5)*nha
#' gha.Rauli<- c(0.15,   0.6,0.2,0.3,0,0,0.5)*gha
#' nha.Coigue <- c(0.15, 0.2,0.7,0.1,0,0,0.2)*nha
#' gha.Coigue<- c(0.1,  0.2,0.7,0.4,0,0,0.3)*gha
#' nha.Laurel <- c(0.05, 0.02,0.2,0,0,0,0)*nha
#' gha.Laurel<- c(0.1,  0.04,0.01,0,0,0,0)*gha
#' nha.Alerce <- c(0, 0,0,0,50,0,0)
#' gha.Alerce<- c(0,  0,0,0,60,0,0)
#' nha.Canelo <- c(0, 0,0,0,850,0,0)
#' gha.Canelo<- c(0,  0,0,0,10,0,0)
#' nha.Araucaria <- c(0, 0,0,0,0,300,0)
#' gha.Araucaria<- c(0,  0,0,0,0,35,0)
#' nha.Nhirre <- c(0, 0,0,0,0,600,0)
#' gha.Nhirre<- c(0,  0,0,0,0,10,0)
#' nha.Tepa <- c(0, 0,0,0,0,1000,50)
#' gha.Tepa<- c(0,  0,0,0,0,5,4)
#' nha.Lenga <- c(0, 0,0,0,0,500,100)
#' gha.Lenga<- c(0,  0,0,0,0,15,4)
#' nha.Manhio <- c(0, 0,0,0,0,0,50)
#' gha.Manhio<- c(0,  0,0,0,0,0,25)
#' df <- data.frame(plot,nha,nha.Alerce,nha.Araucaria,
#'                  nha.Roble,nha.Coigue,nha.Rauli,
#'                  nha.Tepa,nha.Laurel,nha.Lenga,nha.Manhio,
#'                  nha.Canelo,nha.Nhirre,gha,gha.Alerce,
#'                  gha.Araucaria,gha.Coigue,
#'                  gha.Roble,gha.Rauli,gha.Tepa,gha.Laurel,
#'                  gha.Lenga,gha.Manhio,gha.Canelo,
#'                  gha.Nhirre)
#' head(df)
#' assignDomi(data=df)
#' assignDomi(data=df, num.def.dom = 2)
#' assignDomi(data=df, num.def.dom = 1)
#' @rdname assignDomi
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
assignDomi<-function(data=data,num.def.dom=3){
  #library(tidyr)
  #library(dplyr)
  #source("./functions/nele.list.R")
  #source("./functions/findColumn.byname.R")
  db <- data
  #=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
  ##assign name of the association like, Ro-Ra, o Ro solo..... creo que ya teniamos eso resuelto
  ##name of the species
  #=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
  names(db) #gsub("nha.","","nha.alerece")
  db.h <- db
  db.h
  col.gha <- to.del.col <- findColumn.byname(db.h,"gha"); db.h <- db.h[,-to.del.col]    
  to.del.col <- findColumn.byname(db.h,"plot"); db.h <- db.h[,-to.del.col]
  to.del.col <- findColumn.byname(db.h,"nha"); db.h <- db.h[,-to.del.col]  
  name.spp <- gsub("nha.","",names(db.h))
  name.spp <- unique(gsub("gha.","",name.spp))
  
  num.name.spp <- length(name.spp)
  num.name.spp
  db.h.nha <- db[1:(2+num.name.spp)]
  db.h.gha <-  db[c(1,c(col.gha:ncol(db)))] #df[c(1,c((col.gha+num.name.spp):ncol(df)))]
  
  name.groups <- c("all",name.spp)
  names(db.h.nha) <- c(names(db.h.nha)[1],name.groups)
  names(db.h.gha) <- c(names(db.h.gha)[1],name.groups)
  
  ##+-+-+-+-+-+-+-+-+-+-+-+
  ##dominance by stand density
  ##+-+-+-+-+-+-+-+-+-+-+-+  
  #long.nha <-db.h.nha %>% gather(species,nha,name.groups)
  long.nha <-tidyr::gather(db.h.nha,species,nha,name.groups)
  long.nha
  long.nha <- long.nha[with(long.nha, order(plot)),]
  nha.data <-subset(long.nha, species!="all")
  nha.data <- subset(nha.data, nha >0)
  nha.data <- nha.data[with(nha.data, order(plot,species)),]
  
  #list.spp.plot <- data.frame(aggregate(species ~ plot, data=nha.data, I))
  #the following is the same being accomplish when I used the aggregate() function
  #list.spp.plot <- nha.data %>%  group_by(plot) %>%
  #  summarize(species = toString(unique(species)))
  list.spp.plot <-dplyr::summarize(dplyr::group_by(nha.data,plot),species = toString(unique(species)))
  names(list.spp.plot)[2] <- "list.of.species"
  list.spp.plot
  
  nha.dom1 <- nha.data[order(nha.data$plot,-nha.data$nha),] 
  nha.dom1
  nha.dom2 <- nha.dom1[,1:2]
  nha.dom2
  nha.dom <- data.frame(stats::aggregate(species ~ plot, data=nha.dom2, I))
  class(nha.dom)
  utils::head(nha.dom)
  
  #the following is the same being accomplish when I used the aggregate() function
  #nha.dom <- nha.dom2 %>%  group_by(plot) %>%
  # summarize(species = toString(unique(species)))
  spp1.dom.nha<-nele.list(nha.dom$species,1)
  spp2.dom.nha<-nele.list(nha.dom$species,2)
  spp3.dom.nha<-nele.list(nha.dom$species,3)
  dom1.nha <-spp1.dom.nha
  dom2.nha <-paste(spp1.dom.nha,spp2.dom.nha,sep="-")
  dom2.nha <- gsub("-NA","",dom2.nha)
  dom3.nha <-paste(dom2.nha,spp3.dom.nha,sep="-")
  dom3.nha <- gsub("-NA","",dom3.nha)
  
  #+-+-+-+-+-+-+-+-+-+-+-+
  ##dominance by stand basal area  
  #+-+-+-+-+-+-+-+-+-+-+-+  
  #long.gha <-db.h.gha %>% gather(species,gha,name.groups)
  long.gha <-tidyr::gather(db.h.gha,species,gha,name.groups)
  long.gha <- long.gha[with(long.gha, order(plot)),]
  gha.data <-subset(long.gha, species!="all")
  gha.data <- subset(gha.data, gha >0) ###aca
  #nha.dom1 <- nha.data[order(nha.data$plot,-nha.data$nha),]   
  gha.dom1 <- gha.data[order(gha.data$plot, - gha.data$gha),] #gha.data 
  gha.dom2 <- gha.dom1[,1:2]
  gha.dom <- data.frame(stats::aggregate(species ~ plot, data=gha.dom2, I))
  
  #xtabs(count ~ name + type, data = db.h.nha)
  spp1.dom.gha<-nele.list(gha.dom$species,1)
  spp2.dom.gha<-nele.list(gha.dom$species,2)
  spp3.dom.gha<-nele.list(gha.dom$species,3)
  
  dom1.gha <-spp1.dom.gha
  dom2.gha <-paste(spp1.dom.gha,spp2.dom.gha,sep="-")
  dom2.gha <- gsub("-NA","",dom2.gha)
  dom3.gha <-paste(dom2.gha,spp3.dom.gha,sep="-")
  dom3.gha <- gsub("-NA","",dom3.gha)
  
  plot <- nha.dom$plot
  list.spp <- list.spp.plot$list.of.species
  
  dominancia.spp.ng <- data.frame(plot,list.spp,dom1.nha,dom2.nha,dom3.nha,dom1.gha,dom2.gha,dom3.gha)
  
  if(num.def.dom==3){dom.by.nha <- dom3.nha; dom.by.gha <- dom3.gha} else {nada=99} 
  if(num.def.dom==2){dom.by.nha <- dom2.nha; dom.by.gha <- dom2.gha} else {nada=99} 
  if(num.def.dom==1){dom.by.nha <- dom1.nha; dom.by.gha <- dom1.gha} else {nada=99} 
  
  dominancia.spp.ng <- data.frame(plot,list.spp,dom.by.nha,dom.by.gha)
  
  out.list <- list(data.our=db, #nha.data=db.h.nha,  gha.data=db.h.gha, long.nha=long.nha, long.gha=long.gha,
                   #list.spp= name.spp, #nha.dom=nha.dom, gha.dom=gha.dom,
                   dominancia=dominancia.spp.ng) 
  out <- dominancia.spp.ng
  return(out) 
}
#---------------------------
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
