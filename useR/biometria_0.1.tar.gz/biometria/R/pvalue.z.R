#' Computes the p-value for a Standar t-distributed random variable.
#' 
#' @title Computes the p-value for a Standar t-distributed random variable
#' @param z.value a random variable following a normal distribution
#' 
#' @return This function returns the p-value or probability of geting a value as large as x.
#' @author Christian Salas-Eljatib       
#' 
#' @examples
#' 
#' pvalue.z(1.96)
#' 
#' @rdname pvalue.z
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
pvalue.z<-function(z.value){round(((1-stats::pnorm(abs(z.value)))*2),4)}