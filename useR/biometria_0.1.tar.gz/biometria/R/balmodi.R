#' Computes a modification of the basal area in larger trees for any given tree
#'  within a sample plot, that depends on tree density and top height. This index
#'  was originally proposed by Schroder and Gadow (1999)
#'  
#' 
#' @title Computes modified basal area in larger trees
#' @param data data frame having plot level data
#' @param bal column name having the basal area in larger trees (BAL)
#' @param nha column name having tree density in trees per hectare
#' @param gha column name having basal area of sample plot in square meters per hectare
#' @param hdom column name containing top height in meters
#' 
#' @return The function returns an object, vector, the modified BAL
#' @author Created by Christian Salas-Eljatib
#' @references Schroder J. and von Gadow K, 1999. Testing a new competition index for
#' maritime pine in northwestern Spain. Canadian Journal of Forest Research 29: 280-283.
#' @note Please review the reference for further details.
#' @examples
#'
#' #Creating an example dataframe
#' BAL<-sort(c(0,runif(10,1,36),36.7))
#' n <- length(bal)
#' plot.id <- c(rep(1,n),rep(2,n))
#' TPH <- c(rep(1000,n),rep(600,n))
#' BA <- c(rep(37,n),rep(37,n))
#' Toph<- c(rep(25,n),rep(30,n))
#' df <- data.frame(plot.id,BAL,TPH,BA,Toph)
#' head(df)
#' #Using the function
#' df$balmodi <- balmodi(data=df, bal="BAL", nha = "TPH", gha = "BA", hdom = "Toph") 
#' head(df)
#' @rdname balmodi
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
balmodi <- function(data=data, bal=bal, nha=nha, gha=gha,hdom=hdom){
  df <- data
  df$bal<-df[,bal]; df$nha<-df[,nha]; df$gha <- df[,gha]; df$hdom<-df[,hdom]
  df$mean.dist <- sqrt(10000/df$nha)
  df$rs <- df$mean.dist/df$nha
  balmodi <- (df$bal/df$gha)/df$rs
  out<- balmodi
  return(out)
}