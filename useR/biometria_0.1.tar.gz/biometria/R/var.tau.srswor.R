var.tau.srswor <- function(N,n,nvar.y){
	f    <- 1/N
      var.tau.y <- N^2 * ( (1/n) - f ) * nvar.y
	return(var.tau.y)
}