#' function of summary statistic of variables individuals and separared by categories.
#' 
#' 
#'   
#' 
#' @title A statistic summary of tree-level, separated per categories
#' @param data data frame having the tree list
#' @param id column name with the plot codenumber
#' @param t column name having the time variable, if not provided the current year is assigned as the time variable
#' @param categories column names of the variables used as factors
#' @param y column names of the y variables
#' @param dap column name with the diameter at breast heigth, if not given can not calculate the statistics for g
#' @return This function returns a data frame with the statiscal summary of each plot and time for the y variables. 
#'         If categories are given, the result will be a data that will contain the previous one and will have the values  for each 
#'         of the categories. 

#' @author Christian Salas-Eljatib and Joaquin Riquelme-Alarcon
#' @note In order to use this function, the package 'dplyr' must be previously installed. See 'skew.coef' and'kurt.coef'
#' @examples
#' #not yet implemented
#'
#' @rdname statVar
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
statVar <- function (data = data, dap = NA, y = dap, id = plot.id, t = NA,
          categories = NA)
{
  df <- data
  if (sum(is.element(y, "g"))) {
    if (is.na(dap)) {
      stop("ERROR: no se provee columna dap para calculo de g")
    }
    df$g <- df[, dap]^2 * pi/40000
  }
  df$id <- df[, id]
  catego <- prod(!is.na(categories))
  if (is.na(t)) {
    df$t <- data.table::year(Sys.Date())
    t = "t"
  }
  else {
    else.1 = 1
  }
  if (!is.na(t)) {
    df$t <- df[, t]
  }
  else {
    else.2 = 2
  }
  stat.names <- c("min", "max", "median", "mean", "sd", "cv",
                  "skewness", "kurtosis")
  for (i in 1:length(unique(y))) {
    df$y <- df[, y[i]]
    grupos.i <- dplyr::group_by(df, id, t)
    out.i <- dplyr::summarise(grupos.i, min = min(y, na.rm = T),
                              max = max(y, na.rm = T), median = stats::median(y, na.rm = T),
                              mean = mean(y, na.rm = T), sd = stats::sd(y, na.rm = T),
                              cv = stats::sd(y, na.rm = T)/mean(y, na.rm = T) * 100, skewness = skew.coef(y,
                                                                                                   na.rm = T), kurtosis = kurt.coef(y, na.rm = T))
    out.i <- data.frame(out.i)
    inicio.stats <- 3
    fin.stats <- 2 + length(stat.names)
    names(out.i) <- c(id, t, paste(stat.names, ".", y[i],
                                   sep = ""))
    if (i == 1) {
      out <- out.i
    }
    else {
      sigue = 1
    }
    if (i != 1) {
      out <- merge(out, out.i, by = c(id, t))
    }
    else {
      sigue = 2
    }
  }
  if (catego == T) {
    for (j in 1:length(unique(categories))) {
      df$categorie.j <- df[, categories[j]]
      for (i in 1:length(unique(y))) {
        df$y <- df[, y[i]]
        grupos.ij <- dplyr::group_by(df, id, t, categorie.j)
        out.ij <- dplyr::summarise(grupos.ij, min = min(y,
                                                        na.rm = T), max = max(y, na.rm = T), median = stats::median(y,
                                                                                                             na.rm = T), mean = mean(y, na.rm = T), sd = stats::sd(y,
                                                                                                                                                            na.rm = T), cv = stats::sd(y, na.rm = T)/mean(y, na.rm = T) *
                                     100, skewness = skew.coef(y, na.rm = T), kurtosis = kurt.coef(y,
                                                                                                   na.rm = T))
        out.ij <- data.frame(out.ij)
        inicio.stats <- 4
        fin.stats <- 3 + length(stat.names)
        names(out.ij) <- c(id, t, "sub.categorie", paste(stat.names,
                                                         ".", y[i], sep = ""))
        out.ij$categorie <- categories[j]
        out.ij$sub.categorie <- as.character(out.ij$sub.categorie)
        if (i == 1) {
          out.j <- out.ij
        }
        else {
          sigue = 1
        }
        if (i != 1) {
          out.j <- merge(out.j, out.ij, by = c(id, t,
                                               "categorie", "sub.categorie"))
        }
        else {
          sigue = 2
        }
      }
      if (j == 1) {
        out.categories <- out.j
      }
      else {
        sigue = 1
      }
      if (j != 1) {
        out.categories <- rbind(out.categories, out.j)
      }
      else {
        sigue = 2
      }
    }
    out$categorie <- "Total"
    out$sub.categorie <- "Total"
    out <- rbind(out, out.categories)
  }
  out
}
  