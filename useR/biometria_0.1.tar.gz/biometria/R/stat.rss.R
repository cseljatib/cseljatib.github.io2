#' Statistics for a Random Sample without replacement
#' 
#'   
#' 
#' @title Statistics for a Stratified Random Sample without replacement
#' @param n is the sample size
#' @param N is the population size
#' @param y vector with the target variable
#' @param conf  is the confidence level in percentagee for building the confidence intervals
#' @return  Statistics for a Simple Random Sample without replacement
#' @author Christian Salas-Eljatib
#' @examples
#' #not yet implemented
#' 
#' @rdname stat.rss
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
stat.rss <- function(n,N,y,conf){
#       {if(total==0) df=n-L else df=n-1}
      df=n-1 #total*(n-L)+(n-1)
      mean.y=mean(y)
      min.y=min(y); max.y=max(y)
      sd.y <- stats::sd(y)
      f <- n/N
      se.y <- sqrt((sd.y^2/n)*(1-f))
      se.y.p <- 100*(se.y/mean.y)
      alpha=1-(conf/100)
      p=1-(alpha/2)
      ttab<- stats::qt(p, df)
      sam.error <- ttab*se.y
      sam.error.p <- 100*(sam.error/mean.y)
      low.mu.y <- mean.y - sam.error
      upp.mu.y <- mean.y + sam.error
#       CI <- c(low.mu.y,upp.mu.y)
#       names(CI) <- c("Lower value", "Upper value")
       output <- c(n,min.y,max.y,mean.y,se.y,se.y.p,sam.error,sam.error.p,low.mu.y,upp.mu.y)
       names(output) <- c("n","Min","Max","Mean","St.Error","St.Error%","Samp.Error","Samp.E%","Lower value", "Upper value")
       output
}