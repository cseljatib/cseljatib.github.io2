stat.rat.srs <- function(y,x,tau.x,tau.y,N){
   n <- length(y); r <- (y/x);
   corr.coef <- stats::cor(y,x)
   mu.x <- tau.x/N; mu.y <- tau.y/N
   mean.y <- mean(y);  mean.x <- mean(x); mean.r    <- mean(r); 
   sum.y <- sum(y); sum.x <- sum(x); sum.r <- sum(r)
   var.y <-stats::var(y);  var.x <- stats::var(x); var.r <-stats::var(r); 
   R.est     <- (mean.y/mean.x); HT.y <- N * mean.y; HT.x <- N * mean.x
   fsc       <- ((1/n)-(1/N));
   
   tau.y.rat1.srs <- R.est * tau.x  # Estimator 1
   tau.y.rat2.srs <- mean.r  * tau.x # Estimator 2
   part.1 <-(((N-1)/N) * (n/(n-1))); part.2 <- (HT.y - mean.r*HT.x)
   tau.y.rat3.srs <- tau.y.rat2.srs + part.1 * part.2 # Estimator 3
   
# Computing the estimated of the variances   
   var.rm.rat1 <- (1/(n-1)) * sum( (y - R.est*x)^2 )   
   var.est.tau.y.rat1.srs <- (N^2*mu.x^2/mean.x^2)*fsc*var.rm.rat1  # VarHat. of Estimator 1
   var.est.tau.y.rat2.srs <- fsc*(tau.x^2*var.r)  # VarHat. of Estimator 2
   
   # VarHat. of Estimator 3 (using notation given by Goodman & Hartley (1958) pag498-499
     s.22=sum(y^2);s.21=sum(y*x);s.12=sum(y*r);s.20=sum(x^2);s.02=sum(r^2);s.11=sum(y);
     s.10=sum(x);s.01=sum(r)
   #things needed for computing k.22  
      part1=( n/ ((n-1)*(n-2)*(n-3)) );  part2=(n+1)*s.22;  part3=( (2*(n+1))/n )*s.21*s.01;
      part4=( (2*(n+1))/n )*s.12*s.10;   part5=( (n-1)/n )*s.20*s.02;
      part6=( (2*(n-1)) /n )*(s.11^2);   part7=(8/n)*s.11*s.10*s.01;
      part8=(2/n)*s.20*(s.01^2);          part9=(2/n)*s.02*(s.10^2);
      part10=(6/(n^2)) * (s.10^2) * (s.01^2); #part10=(6/10)*(s.10^2)*(s.01^2);
#      k.22=part1*(part2- part3 - part4 - part5 - part6 - part7 + part8 + part9 - part10)
      k.22=part1*(part2- part3 - part4 - part5 - part6 + part7 + part8 + part9 - part10) #after corrigenda
      c.prima=(1/(n-1)) * sum( ( ((r-mean.r)^2)*(x-mean.x) ) ) #Eq.32
# c.prima=(1/(n-1)) * ( sum(y*r) - (2*sum.y) + (mean.r^2)*sum.x - (n-1)*mean.x*var.r ) #Eq.36b   
#      c.const=(1/(n*(n-1))) * ( n* sum(y) - ( sum(x)* sum(r) ) ) #Eq.36 a, easier
      c.const=stats::cov(x,r)        
        #things needed for computing the variance estimator [Finally ;-) ]
 paso=( (n-1)*var.r*var.x + (n-3)*c.const^2 + (1-(2/n))*(n-1)*k.22 )/ ( (n^2)-n-2 )
#var.est.tau.y.rat3.srs <- ((1/n)*tau.x^2*var.r)+((1/(n-2))*2*tau.x*c.prima)+paso #VarHat.of Est. 3
        #new version
paso.x1 <- fsc*(tau.x^2*var.r)+ fsc*((n/(n-2))*2*N*tau.x*c.prima)+paso*n*(N^2)*fsc #
var.est.tau.y.rat3.srs <- paso.x1

        #new version2        
paso.x1 <- ( mu.x^2*var.r/n ) +( 2 *mu.x* c.prima / (n-2)) + paso # = Eq.35 (but for mu.y.hat)    
var.est.tau.y.rat3.srs <- paso.x1 * n * (N^2)*fsc #

#please notice that i am not saving the variance, but the SE%!!!   
      var.est.tau.y.rat1.per <- (sqrt(var.est.tau.y.rat1.srs)/tau.y)*100
      var.est.tau.y.rat2.per <- (sqrt(var.est.tau.y.rat2.srs)/tau.y)*100      
      var.est.tau.y.rat3.per <- (sqrt(var.est.tau.y.rat3.srs)/tau.y)*100
                 
    output <-  c(tau.y.rat1.srs, tau.y.rat2.srs, tau.y.rat3.srs, n,
            var.est.tau.y.rat1.per,var.est.tau.y.rat2.per,var.est.tau.y.rat3.per,
            corr.coef,mean.x,mean.y,mean.r,var.x,var.y,var.r,
                 var.rm.rat1,k.22,c.const,c.prima) #
    names(output) <- c("Tau.y.rat1","Tau.y.rat2","Tau.y.rat3",
                       "n","EstSE%rat1","EstSE%rat2","EstSE%rat3",
              "Corre.Coef","mean.x","mean.y","mean.r","var.x","var.y","var.r",
                       "var.rm.rat1","k.22","c.const","c.prima")
    output
}