#' Schumacher 
#'
#' Mathematical expression for the Schumacher function for relating variable Y versus X
#' @title Mathematical expression for the Schumacher function for relating variable Y versus X
#' @param params Vector with value of parameters (The values must be added in an orderly way, see example)
#' @param X Vector containing the values for the predictor variable
#' @param intercept Value of intercept of function. Default value is 0.
#'
#' @return The value of the function for every value of the vector X and the parameters.
#' @author Christian Salas.
#' @references - Schumacher FX (1939) A new growth curve and its application to timber yield studies. Journal of Forestry 37(10) 819 820.
#'
#' @references Burkhart HE & MR Strub (1974) A model for simulation of planted loblolly pine stands. In J. Fries (Ed.) Growth models for tree and stand simulation, Res.Note 30. Proc. IUFRO Working Party S4.01-4 Meetings,Dep. For. Yield Res., Royal Coll. For., Stockholm, Sweeden, p. 128-135.
#' @examples
#'
#' b0<- 31.92
#' b1<- 9.34
#' params<-c(b0,b1)
#' X <- c(70)
#' y<-schumacher(params,X,intercept=1.3)
#' plot(y~X,type='p')
#' 
#' @rdname schumacher  
#' @export
schumacher <- function(params,X,intercept=NA){
  if (is.na(intercept)==TRUE) {intercept=0}
  b0<-params[1]
  b1<-params[2]
  x<-X[1]
  y <- intercept + b0*exp(-b1/x )
}