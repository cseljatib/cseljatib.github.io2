#' Returns a string vector containing Luebert and Pliscoff vegetative floor abbreviation
#' by taking the vegetative floor id 
#'
#' No details are given
#' 
#' @title Assings Luebert and Pliscoff vegetative floor 
#' @param data data frame having data
#' @param lyp.id column name having Luebert and Pliscoff vegetative floor
#' 
#' @return This function returns a data frame with one column containing
#' Lueber and Pliscoff vegetative floor, abbreviated
#' @author Joaquin Riquelme
#' @references Luebert F, Pliscoff P, 2006. Sinopsis bioclimatica y vegetacional de Chile. Editorial Universitaria, Santiago, Chile.
#' @examples
#' df <- data.frame(code.id=c(61,48,53,54,56,58,59,61,62))
#' assignLPclassi(data = df, lyp.id = "code.id")
#' @rdname assignLPclassi
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
assignLPclassi <- function(data=data, lyp.id="lyp.id"){  
  db <- data
  db$lyp.id <- db[,lyp.id] 
  
  db$lyp.id <-   gsub(pattern = " ", replacement = "", x = db$lyp.id)  
  db$lyp.abrevia <- "No data"
  db$lyp.abrevia[db$lyp.id==48] <- "Ro-Cc"
  db$lyp.abrevia[db$lyp.id==53] <- "Ro-Li"
  db$lyp.abrevia[db$lyp.id==54] <- "Ro-La"
  db$lyp.abrevia[db$lyp.id==56] <- "Ra-Li"
  db$lyp.abrevia[db$lyp.id==58] <- "Ra-Tr"
  db$lyp.abrevia[db$lyp.id==59] <- "Ra-Co"
  db$lyp.abrevia[db$lyp.id==61] <- "Le-Ar"
  db$lyp.abrevia[db$lyp.id==62] <- "Le-Ce"
  db$lyp.abrevia[db$lyp.id==63] <- "Le-Bi"
  db$lyp.abrevia[db$lyp.id==73] <- "Ti-Te"
  db$lyp.abrevia[db$lyp.id==74] <- "Co-Ul"
  db$lyp.abrevia[db$lyp.id==79] <- "Al"
  db$lyp.abrevia[db$lyp.id==83] <- "Co-Ch"
  db$lyp.abrevia[db$lyp.id==85] <- "Cch-Mp"
   
  db$lyp.abrevia
}
