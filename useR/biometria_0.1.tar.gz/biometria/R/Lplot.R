Lplot <-function(kest.out,enve.out,unit.dist){                                             #
L.est<-csabounds::l(kest.out$iso,kest.out$r);
L.low<-csabounds::l(enve.out$lo,enve.out$r);                         #
L.high<-csabounds::l(enve.out$hi,enve.out$r)                                                           #
# Starting the plot                                                                         #
x.range=c(min(kest.out$r),max(kest.out$r));y.range=c(min(L.low,L.est),max(L.high,L.est));   #
graphics::plot(kest.out$r,L.est,type='l',xlim=x.range,ylim=y.range,main="",xlab="",ylab="")           #
graphics::mtext(side=2, expression(italic(hat(L)(t))),line=2.2, las=0);                               #
graphics::mtext(side=1, paste("Distance t, in ",unit.dist),line=2.5);
graphics::par(new=T);                      #
graphics::plot(kest.out$r,L.low,type='l',xlim=x.range,ylim=y.range,main="",xlab="",ylab="",lty=2)     #
graphics::par(new=T);                                                                                 #
graphics::plot(kest.out$r,L.high,type='l',xlim=x.range,ylim=y.range,main="",xlab="",ylab="",lty=2)    #
graphics::par(new=T);graphics::abline(h=0)}