#' Computes the cumulative distribution for a given random variable.
#' 
#' @title Computes the cumulative distribution for a given random variable.
#' @param X a vector of a random variable
#' 
#' @return Returns a dataframe having two columns: the first is the random variable and the
#'  second the  cummulative distribution for the random variable.
#' @author Christian Salas-Eljatib       
#' @examples
#' Y<- rnorm(10)
#' a.cdf(Y)
#' @rdname a.cdf
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
a.cdf<-function(X=X) {
  xname <- deparse(substitute(X))
  X<-sort(stats::na.omit(X))
  pr.acum.x<-(1:length(X)-0.5)/length(X)
  out <- data.frame(X,pr.acum.x)
  names(out) <- c(paste0(xname),paste0("cum.dist.",xname))
  return(out)}
