#' asigna posicion de de menor a mayor a una columna especifica dentro de la db, 
#' si tienen el mismo valor asigna el mismo puesto en el ranking
#' 
#'   
#' 
#' @title Computes the skewness of given vector
#' @param data is a db that contais at least a numeric vector to apply the ranking
#' @param vector is the name of the numeric column to apply the ranking
#' @param ranking is the name of the column where will save the ranking
#' @return  the value of the the skewness of given vector
#'  
#' @author Joaquin Riquelme-Alarcon
#' @examples
#' 
#' vector <- sample(2:20, 10, replace = TRUE)
#' asd<-letters[1:10]
#' data<-data.frame(vector=vector,asd= asd, stringsAsFactors = FALSE)
#' ranking2(data=data, vector = "vector", ranking = "posi")
#'
#' @rdname ranking2
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
ranking2 <- function(data, vector, ranking){
  db <- data
  vec<-vector
  db[,vec]<-as.numeric(as.character(db[,vec]))
  db<-db[order(db[,vec]),]
  db[,ranking]<-NA
  
  posicion<-1
  for (i in unique(db[,vec])){
    db[db[,vec]==i, ranking]<-posicion
    posicion<-posicion+1
  }
  
  db
}