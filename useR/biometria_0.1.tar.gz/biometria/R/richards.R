#' Richards 
#'
#' Mathematical expression for the Richards function for relating variable Y versus X
#' @title Mathematical expression for the Richards function for relating variable Y versus X
#' @param params Vector with value of parameters (The values must be added in an orderly way, see example)
#' @param X Vector containing the values for the predictor variable
#' @param intercept Value of intercept of function. Default value is 0.
#'
#' @return The value of the function for every value of the vector X and the parameters.
#' @author Christian Salas.
#' @references - Richards FJ (1959) A fexible growth function for empirical use. Journal of Experimental Botany 10(29), 290-300.
#' @examples
#'
#' b0<- 34.19
#' b1<- 0.03
#' b2<- 2.91
#' params<-c(b0,b1,b2) 
#' X <- c(70)
#' y<-richards(params,X,intercept=1.3)
#' plot(y~X,type='p')
#' 
#' @rdname richards 
#' @export
richards <- function (params,X,intercept=NA){
  if (is.na(intercept)==TRUE) {intercept=0}
  b0<-params[1]
  b1<-params[2]
  b2<-params[3]
  x<-X[1]
  y<-intercept + b0*( 1 - exp(-b1*x) )^b2
}