#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
# Function: "xyHist"                                             #
# It creates a scattterplot with histograms in both axys      #
# How this function works?:                                            #
# > xyHist(x, y, col.x, col.y,...)   #
#                                                                      #
# Where:                                                               #
# - x: vector of variable X, or the predictor variable                                                   #
# - y: vector of variable Y, or the response variable
# - col.x: string with color for the histogram of variable X   #
# - col.y: string with color for the histogram of variable Y   #
# - ylab, xlab:  these options can be specified as usual in R          #
#                                                                      #
# Created  by: Christian Salas-Eljatib                                 #
# Date: jun6, 2020                                                   # 
# Santiago, Chile                                                      #
#----------------------------------------------------------------------#
xyHist<-function(x=x, y=y, col.x="blue",col.y="red",
                 xlab=NULL, ylab=NULL){
  
  xvar<-x; yvar <- y;
  xrange <- c(0, max(xvar))
  yrange <- c(0, max(yvar))
  N=length(xvar)
  
  #label.y.variable <- expression(paste("Volume (m"^{3},paste( ")" )))
 # label.y.variable <- ylab #"Volumen (m)" #Peso (gr)" #Altura (m)"
  #label.x.variable <- xlab#Tiempo (dias)" #Diametro a la altura del pecho (cm)"
  
  x<-(hist(xvar,plot=FALSE)$counts/N)*100; 
  names(x) <- hist(xvar,plot=FALSE)$mids
  max.xHist<-max(x);
  
  op <- par( mfrow=c(1,1), mai=c(0.7,0.7,0.1,0.1), 
             mgp=c(2.5,1,0),las=1 )
  
  xhist <- hist(xvar,  plot=FALSE) #breaks=seq(-3,3,0.5),
  yhist <- hist(yvar, plot=FALSE) #breaks=seq(-3,3,0.5),
  top <- max(c(xhist$counts, yhist$counts))
  nf <- layout(matrix(c(2,0,1,3),2,2,byrow=TRUE), c(3,1), c(1,3), TRUE)
  
  par(mar=c(3.5,3.5,1,1))
  plot(xvar, yvar, xlab=xlab, ylab=ylab)#label.x.variable, ylab=label.y.variable,col="black",xlim=xrange, ylim=yrange)
  par(mar=c(0,3,1,1))
  barplot(xhist$counts, axes=FALSE, ylim=c(0, top), space=0,
          col=col.x)
  par(mar=c(3,0,1,1))
  barplot(yhist$counts, axes=FALSE, xlim=c(0, top), space=0,
          horiz=TRUE,  col=col.y)
  #abline(v=0)        

}
#---------------------------
##how to use this funcion?
#
#library(datana)
#data("treevolroble")
#df <- treevolroble
##using the function
#xyHist(x=df$dbh,x=df$htot)
##now, specifying colors
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
