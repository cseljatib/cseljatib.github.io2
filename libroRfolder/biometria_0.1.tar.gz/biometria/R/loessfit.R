#' Estimates a simple locally weighted regression, as a way to depict a curve for 
#   representing the main trend in a scatterplot. 
#'
#' Be careful for interpreting the trend.
#'
#' @title Draw a curve for the trend of points, from a LOESS fit, over a previously produced scatter-plot
#' @param x predictor variable
#' @param y response variable
#' @param col is the color to be used for the curve, default is "blue"
#' @param lty defains the option "lty" for plotting. Default is set to 2.
#' @param lwd defains the option "lwd" for plotting. Default is set to 2.
#'
#' @return This function draw a curve for the trend between two variables in
#'  a previously produced scatter-plot.
#' @author Timothy G. Gregoire and Christian Salas-Eljatib
#' @examples
#'
#' #creating a fake dataframe
#' set.seed(1234)
#' x <-runif(100, 5, 60)
#' e <- runif(100, -20, 20)
#' y <- 1.5 + 2.4*x - .05*x^2 +e
#' df <- as.data.frame(cbind(Y=y,X=x))
#' df
#' #fitting a candidate model
#' plot(Y~X, data=df)
#' #using the function
#' loessfit(x=df$X, y=df$Y)
#' #qplot(mpg, wt, data = mtcars, geom = c("point", "smooth"))
#' @rdname loessfit
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
loessfit <- function(x, y, col=NA, lty=NA,lwd=NA){  
	if(prod(is.na(col))){col="blue"}  
	if(prod(is.na(lty))){lty=2}  
	if(prod(is.na(lwd))){lwd=2}  	
	nonparmfit <- stats::fitted(stats::loess( y~x ) )
xordered <- order(x)
graphics::lines(x[xordered], nonparmfit[xordered], col=col, lty=lty, lwd=lwd)
} 
