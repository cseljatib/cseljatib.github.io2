#' This function computes the geometric mean
#'
#' @title Computes the geometric mean
#' @param v is a numeric vector
#'
#' @return This function returns the geometrics mean, a numeric scalar. 
#' @author Christian Salas-Eljatib.
#' @note Init seed
#' @examples
#'
#' set.seed(1234)
#' y <- rnorm(10, 45)
#' #using the function
#' geomean(y)
#' @rdname geomean
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
geomean <- function(v){
	prod(v)^(1/length(v))
	}