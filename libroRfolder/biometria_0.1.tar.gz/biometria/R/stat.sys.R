#'  Statistics for a systematic sample
#' 
#'   
#' 
#' @title  Statistics for a systematic sample
#' @param y vector with the target variable
#' @param N population size
#' @param conf is the confidence level in percentage for building the confidence intervals
#' @param suc.var.est is an indicator number 1 for estimating the variance of the sampling based on successive differences and 0 otherwise
#' @return Statistics for a systematic sample
#' @author Christian Salas-Eljatib
#' @examples
#' #not yet implemented
#' 
#' @rdname stat.sys
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
stat.sys <- function(y,N,conf,suc.var.est){
      {if(suc.var.est==1) paso1=1 else paso2=0}
      {if(suc.var.est==0) paso1=0 else paso2=1}
      suc.dif2 <- 0
  mean.y    <- mean(y)
      tau.y.est <- N * mean.y
      mu.y.est <- mean.y
      n <- length(y)
# Loop for computing the succesive difference
for (i in 2:n){
        suc.dif2 <- suc.dif2 + 
           (y[i] - y[i-1])^2
               }
      var.tau.y.sys <- (N^2) * ( (1/n) -(1/N) ) * (suc.dif2)/(2*(n-1))
      var.tau.y.srs <- (N^2) * ( (1/n) -(1/N) ) * stats::var(y)
      var.tau.y.est <- var.tau.y.sys * paso1 + var.tau.y.srs*paso2
      var.mu.y.est <- var.tau.y.est / N^2
# confidence intervals
      df=(n-1)
      sd.tau.y <- sqrt(var.tau.y.est)
      sd.mu.y <- sqrt(var.mu.y.est)
      alpha=1-(conf/100)
      p=1-(alpha/2)
      ttab<- stats::qt(p, df)
      sam.error.tau <- ttab*sd.tau.y
      low.tau.y <- tau.y.est - sam.error.tau
      upp.tau.y <- tau.y.est + sam.error.tau
      sam.error.mu <- ttab*sd.mu.y
      low.mu.y <- mu.y.est - sam.error.mu
      upp.mu.y <- mu.y.est + sam.error.mu
    output <-  c(tau.y.est, mu.y.est,
                 var.tau.y.est, var.mu.y.est,
                 sam.error.tau, sam.error.mu,
                 low.tau.y, upp.tau.y,
                 low.mu.y, upp.mu.y)
    names(output) <- c("Tau.y.est","Mu.y.est",
                  "Var.Tau.y.est", "Var.Mu.y.est",
                  "sam.error.tau", "sam.error.mu",
                  "Lower tau value", "Upper tau value",
                  "Lower mu value", "Upper mu value")
    output
}