#' Computes the p-value for a Standar t-distributed random variable.
#' 
#' @title Computes the p-value for a Standar t-distributed random variable
#' @param t.value a random variable following a t-student pdf distribution
#' @param df degrees of freedom of the random variable following a t-student pdf distribution.
#' 
#' @return This function returns the p-value or probability of geting a value as large as t.value.
#' @author Christian Salas-Eljatib          
#' 
#' @examples
#' # Load dataset
#' 
#' #aa <- biometria::araucaria
#' #
#' ## Calculate t value
#' #t.value <- t.test(aa$hdom)
#' #t.v <- as.numeric(t.value$statistic)
#' #deg.f <- as.numeric(t.value$parameter)
#' 
#' ## Calculate p value
#' #pvalue.t(t.v,deg.f)
#' 
#' @rdname pvalue.t
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
pvalue.t<-function(t.value,df){round(((1-stats::pt(abs(t.value),df))*2),4)} 