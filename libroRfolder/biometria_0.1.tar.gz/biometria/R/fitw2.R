fitw2<-function(d) {
  #       est<-mle(function(shape=5,scale=20)
  est<-mle(function(shape=1,scale=80)  
    nLLweibull(d,shape,scale))
  if (class(est)=="try-error") list(par=rep(NA,2),neg2LL=NA,conv=NA)
  else list(
    par=coef(est),
    neg2LL=2*attributes(est)$min,
    conv=attributes(est)$details$convergence,
    summaryFit=summary(est))
}