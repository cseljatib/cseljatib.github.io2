 BbME.rat <- function(y,x,Sys.e){
      N=length(y);
      f <- 1/N;
      mu.y    <- mean(y); 
      mu.x    <- mean(x); 
      var.y <- stats::var(y); 
      var.x <- stats::var(x);
      sd.x=stats::sd(x)
      tau.y <-sum(y);
      tau.x <-sum(x)
      cv.y <- (stats::sd(y))/mu.y ; 
      cv.x <- (stats::sd(x))/mu.x
      cv.x.me <- (stats::sd(x)+Sys.e)/mu.x
      cov.yx <- stats::cov(y,x)
      r <- (y/x); 
      mu.r <- mean(r);
      R.est<- (mu.y/mu.x)
      rho <- stats::cor(y,x)   # correlation coefficient  

#TGG ratio of bias (B/B*) for rat1 -------
#      numera.cte <- var.x - rho*cv.y*mu.x
#      denomina.1 <- numera.cte - rho*cv.y*Sys.e
#      red.fac <- (1+(Sys.e/mu.x))^2
#    rat.bias.est1<-red.fac*(numera.cte/denomina.1)
#----------
#CS ratio of bias (B/B*) for rat1 -------
      numera.cte <- sd.x - rho*cv.y*mu.x
      denomina.1 <- (numera.cte - (rho*cv.y*Sys.e) )
      red.fac <- (1+(Sys.e/mu.x))
      
#      numera.cte <- cv.x - rho*cv.y
#      denomina.1 <- (sd.x/(mu.x+Sys.e))-(rho*cv.y)
#      red.fac <- (1+(Sys.e/mu.x))
      
#    rat.bias.est1<-red.fac*(numera.cte/denomina.1)
    #rat.bias.est1<-red.fac*(numera.cte/denomina.1)#*(1/(1+(Sys.e/mu.x)))
     rat.bias.est1<-red.fac^2*(numera.cte/denomina.1)
      
# for rat2    
bias.tau.y.rat2 <-  sum ( r *(mu.x - x) )
biasE.tau.y.rat2 <-  sum ( r *(x*(((mu.x+Sys.e)/(x+Sys.e)) - 1) ))                    
   rat.bias.est2 <-bias.tau.y.rat2/biasE.tau.y.rat2
    output <-  c(rat.bias.est1,rat.bias.est2)    
#    names(output) <- c("")
    output
}
