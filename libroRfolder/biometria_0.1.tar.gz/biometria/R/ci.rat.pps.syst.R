ci.rat.pps.syst <- function(tau.y,var.tau.y,n,conf){
# confidence intervals
      df=(n-1)
      sd.tau.y <- sqrt(var.tau.y)
      alpha=1-(conf/100)
      p=1-(alpha/2)
      ttab<-stats::qt(p, df)
      sam.error.tau <- ttab*sd.tau.y
      low.tau.y <- tau.y - sam.error.tau
      upp.tau.y <- tau.y + sam.error.tau
    output <-  c(tau.y,var.tau.y,
                 sam.error.tau,
                 low.tau.y, upp.tau.y)
    names(output) <- c("Tau.y.est","Var.Tau.y.est",
                  "sam.error.tau",
                  "Lower tau value", "Upper tau value")
    output
}