#' Expression for computing the value of Beta in the Richards growth model, depending
#'    on the parameters alpha (a.param) and gamma (c.param), site index (sitio),
#'    and based-age (tb), for a polymorphic version of the growth model.
#'
#' Please check that the resulting values of beta, are similar to the one fitted for the expected
#' curve.
#' 
#' @title Computes the value of the parameter beta of the Richards growth model, depending on
#'  site index and the base-age. 
#' @param a.param is the estimated alpha parameter
#' @param c.param is the estimated gamma parameter
#' @param site.index is the value of site index
#' @param tb is the base-age for the site index curves.
#' 
#' @return This function returns the value of the beta parameter, depending upon the value of site index, and the
#' rest of the parameters already fitted for the Richards growth model.
#' @author Christian Salas-Eljatib          
#' 
#' @references Garcia O. 1983. A stochastic differential equation model for the
#'  height growth of forest stands. Biometrics 39(4) 1059 1072.
#' @examples
#' 
#' #Using the function
#' beta.rich.si(a.param=50,c.param=1,site.index=25,tb=20)
#' 
#' @rdname beta.rich.si
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
beta.rich.si <-  function(a.param, c.param, site.index,tb){
  (-log(1-(site.index/a.param)^c.param))/tb}