#' Alternative implementation of Uestimator, useful for translation to C, VisualBasic, or other procedural languages.
#' 
#'   
#' Description function
#' @title Alternative Uestimator
#' @param height vector or list of tree heights, sorted by increasing dbh
#' @param trees.per.are length(heights) / (plot area in ares).  If not integer, it is rounded to the nearest integer, with a warning.
#' 
#' @return   Calculate U-estimator, for integer trees/are  
#' @author Christian Salas-Eljatib
#' @note see topHeight()
#' @references Garcia,O. and Batho,A. Western Journal of Applied Forestry 20(1), 64-68. 2005.
#' @examples
#' #not yet implemented
#'
#' @rdname Uestimator.alt
#' @export 
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
Uestimator.alt <- function(height, trees.per.are) {
  m <- round(trees.per.are)
  if (m != trees.per.are) warning("trees.per.are = ", trees.per.are, " has been rounded")
  n <- length(height)
  U <- height[m]
  for (i in (m+1):n) {
    U <- height[i] + (i - m) * U / (i - 1)
  }
  return (m * U / n)
}
