Jplot <-function(Jest.out,Jenve.out,unit.dist){                                            #
Jest.out$rs[is.na(Jest.out$rs)] <- 0;  #To avoid plotting problems for some big ranges of t #
J.est<-Jest.out$rs;J.low<-Jenve.out$lo;J.high<-Jenve.out$hi                                 #
# Starting the plot                                                                         #
x.range=c(min(Jest.out$r),max(Jest.out$r));                                                 #
y.range=c(min((J.low[!is.na(J.low)]),J.est),max((J.high[!is.na(J.high)]),J.est));           #
#x.range=c(min(Jest.out$r),max(Jest.out$r));y.range=c(0,1);                                 #
graphics::plot(Jest.out$r,J.est,type='l',main="",xlim=x.range,ylim=y.range,                           #
xlab=paste("Distance t, in ",unit.dist),ylab=expression(italic(hat(J)(t)))); graphics::par(new=T);    #  
graphics::plot(Jest.out$r,J.low,type='l',main="",xlab="",ylab="",lty=2,xlim=x.range,ylim=y.range)     #
graphics::par(new=T);                                                                                 #
graphics::plot(Jest.out$r,J.high,type='l',main="",xlab="",ylab="",lty=2,xlim=x.range,ylim=y.range)} 