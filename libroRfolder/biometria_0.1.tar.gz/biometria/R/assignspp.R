#' creates a new dataframe that includes columns with scientific and common name of species,
#' abbreviation and code of scientific name.
#'
#' No details are given
#' 
#' @title creates a dataframe including scientific and common name of species
#' @param data data frame having tree data, including species common names
#' @param name.esp column name having the species common names
#' @param cod user must indicate whether the codified name is provided in name.esp ('yes') or not ('no')
#'
#' @return This function returns a data frame including scientific and common name of species,
#' abbreviation and code of scientific name.
#' @author Christian Salas-Eljatib
#' @examples
#' 
#' # How to use this function
#' 
#' #data(speciesList) #Loads list of tree species from the datasets
#' 
#' # Sample dataframe
#' # solo con la columna esp
#' # db1 <- data.frame(narb=1:100,esp=sample(x = c("nob","nal"), size = 100, replace = TRUE))
#' # con spp.name pero con otro nombre
#' #db2 <- data.frame(narb=1:100,spp.nammm=sample(x = c("Roble","Rauli"), size = 100, replace = TRUE))
#' # esp y spp.name
#' #db3 <- data.frame(narb=1:100,
#' #                  esp=sample(x = c("nob","nal"), size = 100, replace = TRUE),
#' #                  spp.name=sample(x = c("Roble","Rauli"), size = 100, replace = TRUE))
#' 
#' #e1 <- assignspp(data = db1, name.esp = "esp", cod = c("yes"))
#' #head(e1)
#' 
#' #e2 <- assignspp(data = db2, name.esp = "spp.nammm", cod = c("no"))
#' #head(e2)
#' 
#' #e3 <- assignspp(data = db3, name.esp = "esp", cod = c("yes"))
#' #head(e3)
#' 
#' @rdname assignspp
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

assignspp <- function (data = data, name.esp = name.esp, cod = "yes")
{
  df <- data
  data(speciesList)
  especie <- speciesList
  if (cod == "yes") {
    df$esp <- df[, name.esp]
    df$spp.name <- NULL
    assignspp.code <- merge(x = df, y = especie[, c("common.name", "spp.ci.name", "esp", "spp.ci.abb")],
                            by = "esp", all.x = TRUE)
    out.code <- assignspp.code
    return(out.code)
  }
  if (cod == "no") {
    df$common.name <- df[, name.esp]
    df$esp <- NULL
    assignspp.code <- merge(x = df, y = especie[, c("common.name", "spp.ci.name", "esp", "spp.ci.abb")],
                            by = "common.name", all.x = TRUE)
    out.code <- assignspp.code
  }
}  
