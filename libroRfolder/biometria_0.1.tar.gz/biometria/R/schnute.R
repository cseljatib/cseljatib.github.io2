#' Schnute 
#'
#' Mathematical expression for the Schnute function for relating variable Y versus X
#' @title Mathematical expression for the Schnute function for relating variable Y versus X
#' @param params Vector with value of parameters (The values must be added in an orderly way, see example)
#' @param X Vector containing the values for the predictor variable
#' @param intercept Value of intercept of function. Default value is 0.
#'
#' @return The value of the function for every value of the vector X and the parameters.
#' @author Christian Salas.
#' @references - Schnute I (1981) A versatile growth model with statistically stable parameters. Can. J. Fish. Aquat. Sci.38(9), 1128-1140.
#'
#' @examples
#'
#' b0<-37
#' b1<-0.05
#' b2<-0.03
#' params<-c(b0,b1,b2) 
#' X <- c(70)
#' y<-schnute(params,X,intercept=1.3)
#' plot(y~X,type='p')
#' 
#' @rdname schnute 
#' @export
schnute<-function(params,X,intercept){
  if (is.na(intercept)==TRUE) {intercept=0}
  b0<-params[1]
  b1<-params[2]
  b2<-params[3]
  x<-X[1]
  y<-(intercept^b1+(b2^b1-intercept^b1)*((1-exp(-b0*(x-0)))/(1-exp(-b0*(100-0)))) )^(1/b1)
}