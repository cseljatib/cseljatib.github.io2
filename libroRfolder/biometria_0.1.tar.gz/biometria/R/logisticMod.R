#' LogisticoModificado 
#'
#' Mathematical expression for the Logistic function for relating variable Y versus X
#' @title Mathematical expression for the Logistic function for relating variable Y versus X
#' @param params Vector with value of parameters (The values must be added in an orderly way, see example)
#' @param X Vector containing the values for the predictor variable
#' @param intercept Value of intercept of function. Default value is 0.
#'
#' @return The value of the function for every value of the vector X and the parameters.
#' @author Christian Salas.
#' @references - Monserud RA (1984) Height growth and site index curves for Inland Douglas-fir based on stem analysis dataand forest habitat type. Forest Science 30(4)943-965.
#' @examples
#'
#' b0<- 29.28
#' b1<- 0.82
#' b2<- 0.07
#' params<-c(b0,b1,b2) 
#' X <- c(70)
#' y<-logisticMod(params,X,intercept=1.3)
#' plot(y~X,type='p')
#' 
#' @rdname logisticMod 
#' @export
logisticMod <- function (params, X, intercept=NA) {
  if (is.na(intercept)==TRUE) {intercept=0}
  b0<-params[1]
  b1<-params[2]
  b2<-params[3]
  x<-X[1]
  y<-intercept + b0/( 1+(exp(b1-(b2*x))))
}