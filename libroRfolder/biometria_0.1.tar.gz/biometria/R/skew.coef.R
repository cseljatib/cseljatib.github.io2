#' Computes the skewness of given vector
#' 
#'   
#' 
#' @title Computes the skewness of given vector
#' @param x vector of numbers
#' @param na.rm if want to remove NA values
#' 
#' @return  the value of the the skewness of given vector
#'  
#' @author Christian Salas-Eljatib and Joaquin Riquelme-Alarcon
#' @examples
#' #not yet implemented
#'
#' @rdname skew.coef
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
skew.coef <-  function(x, na.rm=T) {
m3 <- mean((x-mean(x,na.rm=na.rm))^3,na.rm=na.rm)
skew.coef <- m3/(stats::sd(x,na.rm=na.rm)^3)
skew.coef
}
