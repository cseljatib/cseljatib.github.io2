nLLweibull<-function(x, shape=5,scale=20){ 
    -sum(dweibull(x,shape=shape,scale=scale,log=TRUE))
      
}