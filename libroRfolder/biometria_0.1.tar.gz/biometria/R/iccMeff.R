#' This function computes the intra-class correlation of a mixed-effects model
#'
#' @title Computes the intra-class correlation of a mixed-effects model
#' @param mod is an object obtained by fitting a linear or non-linear mixed-effects
#'  model.
#' @param num.f number of factors (default = 2)
#'
#' @return This function returns the ICC for a given fitted mixed-effects model. 
#' @author Christian Salas-Eljatib.
#' @note In order to use this function, you most likely will need to load the nlme
#'  or the lme4 packages. 
#' @examples
#'
#' #Not yet implemented
#' 
#' @rdname iccMeff
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
iccMeff <- function(mod,num.f=NA){
  if (is.na(num.f)==TRUE) {num.f==2}
	varests <- as.numeric(nlme::VarCorr(mod)[1:num.f])
	icc <- sum(varests[1:(num.f-1)])/sum(varests)
	return(icc)
}