siteFactorModFit <- function(data=data,respvar.y=respvar.y,classiVege=classiVege,ele=ele,
                         slo=slo,asp=asp){
  data$Y<- data[,respvar.y]
  data$classiVege<- data[,classiVege] 
  data$classiVege=as.factor(data$classiVege)
  data$ele<- data[,ele]
  data$slo<- data[,slo]
  data$asp<- data[,asp]   #in degrees
  data$cos.asp <- cos(data$asp*(pi/180))
  data$sin.asp <- sin(data$asp*(pi/180))
#fitting the model  
  model.out <-  stats::lm(Y ~ classiVege +
                     ele + I(ele^2)
                   + slo + I(slo*cos.asp) +  I(slo*sin.asp)
                   + I(slo*log(ele)) + I(slo*log(ele)*cos.asp) + I(slo*log(ele)*sin.asp)
                   + I(slo*ele^2) + I(slo*ele^2*cos.asp)+ I(slo*ele^2*sin.asp),
                   data=data)   
}
