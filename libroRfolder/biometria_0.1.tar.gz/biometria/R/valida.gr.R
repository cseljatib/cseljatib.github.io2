#' Computing validation statistics for a growth model being already fitted
#'  with annualized coefficients, as in Weiskittel et al (2007). The computation is based on
#'  predicted the periodic annual increment (pai)
#'
#' @title Computes validation statistics for an already fitted annualized growth model
#' @param mod is an already annualized fitted growth model
#' @param data is a dataframe
#' @param vary is the response varible 
#' @param dt is the period length 
#'
#' @return This function returns the following statistics as a vector: 
#' (RMSD,RMSD.p,AD,AD.p,AAD,AAD.p); where RMSD.p stands for
#' RMSD expressed as a percentage, and the same applied to AD.p and AAD.p.
#' @note  It uses the function valesta(). Please check the references for further details.
#' @references   Weiskittel AR, Garber SM, Johnson GP, Maguire DA, Monserud RA. 2007. Annualized
#'  diameter and height growth equations for Pacific Northwest plantation-grown Douglas-fir,
#'   western hemlock, and red alder. Forest Ecology and Management. 250: 266-278
#' 
#' @examples
#' #Not yet implemented
#' @rdname valida.gr
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
valida.gr <- function(mod=mod,data,vary=vary,dt=dt){
  perlen <- data[,dt]
  y.obs <- data[,vary]
  pai.obs <- y.obs/perlen	
  y.hat <- stats::predict(mod)
  pai.hat <- y.hat/perlen
  return(valesta(pai.obs,pai.hat))
}