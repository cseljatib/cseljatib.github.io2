#' Computes the Clark and Evans aggregation index
#' 
#'   
#' 
#' @title Computes the Clark and Evans aggregation index
#' @param pppData is a ppp object (the data with the Cartesian positions as an R object)
#' @param plot.area is the area of the plot in the same units that the distance was measured
#'
#' @return  Computes the Clark & Evans spatial statistic indice  
#' @author Christian Salas-Eljatib
#' @references - Clark, P.J. and Evans, F.C. (1954) Distance to nearest neighbour as a measure of spatial relationships
#'  in populations. Ecology 35, 445-453.
#' @note this takes a while to run for large datasets
#' @examples
#' # Load data with trees and their position (coordinates) 
#' 
#' #aa <- data(araucaria)
#' #area.plot <- 500
#' 
#' # Create an object of class "ppp",
#' # representing the point pattern dataset in the two-dimensional plane
#' #df <- spatstat::ppp(aa$x.utm, aa$y.utm,
#' #          c(min(aa$x.utm),max(aa$x.utm)),
#' #          c(min(aa$y.utm),max(aa$y.utm)))
#'           
#' # Calculate Clark & Evans spatia
#' 
#' @rdname ClarkE
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
ClarkE<-function(pppData,plot.area){                                                       
   temp<-nndist(pppData); n<-length(temp); lambda<-n/plot.area;                            
   (2*sqrt(lambda)/n*sum(temp)-1)/sqrt((4-pi)/(n*pi))}
