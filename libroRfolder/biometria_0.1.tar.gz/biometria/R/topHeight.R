#' Computes dominant height of a sample plot
#' 
#'   
#' 
#' @title Calculate the height of the dominant trees in a stand 
#' @param height vector or list of tree heights, sorted by increasing dbh
#' @param area column name having the plot area in ares (1 hectare = 100 ares)
#' 
#' @return   Calculate top height using the interpolated U-estimator.
#'           Reference: Garcia,O. and Batho,A. Western Journal of Applied forestry 20(1), 64-68. 2005.
#'  
#'  
#' @author Garcia, 0. and Batho, A.
#' @note This function need the 'Uestimator' function 
#' @examples
#' 
#' N <- 760
#' A <- 0.03
#' n <- round(N * A)
#' heights <- rnorm(n, 15, 4)
#' m <- round(n / (100 * A))
#' choose(n, m)    # subsets
#' Uestimator(sort(heights), m)
#' # find the largest in each subset...
#' h <- combn(heights, m, FUN=max)
#' # the mean is the top height U-estimate:
#' mean(h)
#' topHeight(sort(heights), 100 * A)
#'
#' @rdname topHeight
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
topHeight <- function(height, area) {
  m <- length(height) / area
  mlo <- floor(m)
  mhi <- ceiling(m)
  U.lo <- Uestimator(height, mlo)
  U.hi <- Uestimator(height, mhi)
  if (mhi == mlo) return(U.hi)
  (mhi - m) * U.lo + (m - mlo) * U.hi
}
