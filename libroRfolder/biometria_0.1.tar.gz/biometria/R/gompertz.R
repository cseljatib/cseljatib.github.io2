#' Gompertz 
#'
#' Mathematical expression for the Gompertz function for relating variable Y versus X
#' @title Mathematical expression for the Gompertz function for relating variable Y versus X
#' @param params Vector with value of parameters (The values must be added in an orderly way, see example)
#' @param X Vector containing the values for the predictor variable
#' @param intercept Value of intercept of function. Default value is 0.
#'
#' @return The value of the function for every value of the vector X and the parameters.
#' @author Christian Salas.
#' @references - Nokoe S (1978) Demonstrating the flexibility of the Gompertz function as yield model using mature speciesdata. Commonw. For. Rev. 57(1), 35-42.
#'
#' @references - Schabenberger O & FJ Pierce (2002) Contemporary Statistical Models for the Plant and Soil Sciences. CRCPress, Boca Raton, FL, USA. 738 p.
#' @examples
#'
#' b0<- 30.16
#' b1<- 0.06
#' b2<- 25.59
#' params<-c(b0,b1,b2) 
#' X <- c(70)
#' y<-gompertz(params,X,intercept=1.3)
#' plot(y~X,type='p')
#' 
#' @rdname gompertz 
#' @export
gompertz <- function (params, X,intercept=NA) {
  if (is.na(intercept)==TRUE){intercept=0}
  b0<-params[1]
  b1<-params[2]
  b2<-params[3]
  x<-X[1]
  y<- intercept + b0*exp( (-exp(-b1*(x-b2))) )
}