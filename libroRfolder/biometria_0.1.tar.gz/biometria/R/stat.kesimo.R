stat.kesimo <- function(y,fe){
   n <- length(y) 
   mean.y <- mean(y)
   sum.y <- sum(y)
   sd.y <- sd(y); cv.y <- (sd.y*100)/mean.y
q1.y <- quantile(y,0.25)
q2.y <- quantile(y,0.5)
q3.y <- quantile(y,0.75)
riq.y<- q3.y-q1.y
      se.y <- sd.y/sqrt(n)
      nha=(n-0.5)*mean(fe)
      yha=mean(fe) *
          (
sum(y[1:n-1])+ (0.5*y[n])
              )
output <- data.frame(cbind(
    n,nha,yha,mean.y,q2.y,sd.y,cv.y,riq.y))
names(output) <-
 c("n","nha","yha","mean","median","sd","cv.p", "riq")
output
}