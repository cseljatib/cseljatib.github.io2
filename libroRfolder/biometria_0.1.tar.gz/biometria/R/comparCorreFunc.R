#' Compares fitted models (gls or lme) using different spatial correlation functions
#'  with and without nugget effects. The main ouput is the model as an object. 
#'  
#' 
#' @title Compares variant models depending on the spatial correlation functions
#' @param mod a model object, fitter either using gls() or lme().
#' @param data the dataframe for fitting the object model.
#' @param is.lme is a logical value to identify if the model was fitted by lme, otherwise (FALSE) the
#'  model "mod" must be fitted by gls. The default is set to TRUE.
#'
#' @return an object with fitting results.
#' @author Christian Salas-Eljatib.
#' @references  Pinheiro JC, and Bates DM. 2000. Mixed-effects models in S
#'    and Splus. Springer-Verlag, New York, NY. 528 p.
#' @examples
#'  
#' #not yet implemented
#' @rdname comparaCorreFunc
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
comparCorreFunc <- function(mod=mod,data=data,is.lme=TRUE){  
  if(is.lme==TRUE){prefijo.mod=c('lme')} else {prefijo.mod=c('gls')}
  
  type.spat.correfx <- c("exponential","gaussian","linear","ratio","spherical")
  type.nugget <- c(FALSE,TRUE)
  type.met <- c('euclidean','maximum','manhattan')
  #"euclidean"  "maximum" for the maximum difference; and "manhattan
  
  n.type.spat.correfx <- length(type.spat.correfx)
  n.type.nugget <- length(type.nugget)
  n.type.met <- length(type.met)
  
  aic.out=c()
  name.model.out=c()
  corfx.out=c(); nugg.out=c(); met.out=c()
  counter=0; counter.out=c()
  
  for(i in 1:n.type.spat.correfx){
    
    for(j in 1:n.type.nugget) {
      
      # if(j==1){nugget.si=c('NuggetYes')} else {nugget.si=c('NuggetNo')}
      if(j==1){nugget.si=c('with')} else {nugget.si=c('without')}    
      for(z in 1:n.type.met) {
        my.corspat <- nlme::corSpatial(#range.corre,
          form= ~ x + y, type= type.spat.correfx[i], nugget=type.nugget[j],
          met=type.met[z])
        my.corspat.run <-  nlme::Initialize(my.corspat, data[,c('x','y')])
        
        
        new.model <- try(stats::update(mod,
                                corr = my.corspat.run),silent=TRUE)
        
        #name.model=paste(prefijo.mod,'.Cor',type.spat.correfx[i], nugget.si,sep='')
        name.model=paste(prefijo.mod,'.Cor_',type.spat.correfx[i], '.',nugget.si,'Nugget','.Met_',type.met[z],sep='')
        
        #getting the AIC for this model
        if(length(new.model)>1){aic.run=stats::AIC(new.model)} else {aic.run=10000000}
        if(length(new.model)<1){new.model=0} else {nada=1}
        
        aic.out=c(aic.out,aic.run)
        name.model.out=c(name.model.out,name.model)
        corfx.out=c(corfx.out,i)
        nugg.out=c(nugg.out,j)
        met.out=c(met.out,z)
        counter=counter+1
        counter.out=c(counter.out,counter)
      }
    }
  }
  
  #paso.aic=data.frame(corfx.out,nugg.out,name.model.out,aic.out)
  paso.aic=data.frame(corfx.out,nugg.out,met.out,name.model.out,aic.out)
  paso.aic
  or<-order(paso.aic$aic.out,decreasing=F)
  paso.2<-paso.aic[or,]
  paso.2
  selec.mod.name=paso.2$name.model.out[1]
  selec.mod.name
  selec.corfx=as.numeric(paso.2$corfx.out[1])
  selec.corfx
  selec.nugg=as.numeric(paso.2$nugg.out[1])
  selec.nugg
  selec.met=as.numeric(paso.2$met.out[1])
  selec.met
  #anova(lme.p,lme.p2,lme.p3)
  
  # fit AGAIN only the best model
  my.corspat <- nlme::corSpatial(#range.corre,
    form= ~ x + y, type= type.spat.correfx[selec.corfx], nugget=type.nugget[selec.nugg],
    metric=type.met[selec.met])
  my.corspat.run <-  nlme::Initialize(my.corspat, data[,c('x','y')])
  
  new.model <- stats::update(mod, corr = my.corspat.run)
  
  final.mod <- new.model
  attr(final.mod,"best.model") <- selec.mod.name
  #output=list(c(final.mod,selec.mod.name))
  #cat('the best model is ', attr(final.mod,"best.model"), sep='', '\n')
  output=final.mod
  output
  #ls()
} 
#corMatrix(best.gls)
#getVarCov(best.gls)
# End of "comparCorreFunc"
