#' crea columna tree.id a partir de los niveles: plot.id, cuadrante, narb, anho.med
#' 
#'   
#' 
#' @title Plot id generator
#' @param data is a db that contais the internal format  proy.id, predio, rodal, conglomerado, parc, cuadrante, narb, anho.med
#' @param tree.id.anho quiere crear tree.id.anho
#' @param tree.id.latex quiere crear tree.id.latex y plot.id.anho.latex 
#' @return  data de entrada con la columna plot.id, opcionales plot.id.anho, plot.id.latex, plot.id.anho.latex
#'  
#' @author Joaquin Riquelme-Alarcon
#' @note require una data con plot.id see plotIdGenerator
#' @examples
#' #df.0 <- dbBiometria$mediTree$datos
#' #df.1 <- plotIdGenerator(df.0)
#' #df.2 <- treeIdGenerator(df.1)
#' #df.3 <- treeIdGenerator(df.1, plot.id.anho = F, plot.id.latex = T); 
#' @rdname treeIdGenerator
#' @export
#' @keywords internal
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
treeIdGenerator <- function(data, tree.id.anho=T, tree.id.latex=T){
  
  db <- data
  
  if(is.null(db$plot.id)){stop("Los datos no tiene la columna plot.id, proceso no pudo completarse")}
  # tiene cuadrante
  db$tree.id[!is.na(db$cuadrante)] <-  paste(db$plot.id[!is.na(db$cuadrante)],
                                             db$cuadrante[!is.na(db$cuadrante)], sep="_q")
  # no tiene cuadrante
  db$tree.id[is.na(db$cuadrante)] <-  paste(db$plot.id[is.na(db$cuadrante)], 
                                            "999", sep="_q")
  # agrega arbol
  db$tree.id <- paste(db$tree.id, db$narb, sep="_t")
  
  if(tree.id.anho==T){
    # tree.id.anho
    db$tree.id.anho <- paste(db$tree.id, db$anho.med, sep="_")
  }
  
  if(tree.id.latex==T){
    # tree.id.latex
    db$tree.id.latex <- gsub(x = db$tree.id, pattern = "_", replacement = "\\_", fixed = T)
  }
  
  if(tree.id.anho*tree.id.latex==T){
    # tree.id.anho.latex
    db$tree.id.anho.latex <- gsub(x = db$tree.id.anho, pattern = "_", replacement = "\\_", fixed = T)
  }
  
  db
  
}