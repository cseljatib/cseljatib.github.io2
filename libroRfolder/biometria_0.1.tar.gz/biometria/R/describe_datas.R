#' Presence or absence of sea ice from logbook records of annual cruises
#' @description
#' Data containing 52717 observations , about presence of sea ice from logbook records of annual 
#' cruises to the B-C-B in an unbroken record between  years 1850 to 1910. 
#' @usage
#' data(presenceIce)
#' @format The data frame contains nine variables as follows:
#' \describe{
#'   \item{ship.id}{The code number for ships.}
#'   \item{move.type}{Type of movement of ships. 0 indicates a sail-powered vessel and 1 indicates an auxiliary-powered vessel.}
#'   \item{year}{Year of registry.}
#'   \item{month}{Month of registry.}
#'   \item{day}{Day of registry.}
#'   \item{lat.dec}{Decimal latitude.}
#'   \item{long.dec}{Decimal longitude.}
#'   \item{e.w}{East or west of the Prime Meridian.}
#'   \item{ice.cov}{Sea Ice Observed. 0 no see (Not registered) and 1 presence sea ice (Registered).}
#'  }
#' @source 
#' The data were provided from Sea Ice Group at the Geophysical Institute.   
#' @references
#' Mahoney A, Bockstoce J, Botkin D, Eicken H, Nisbet R. 2011. Sea-Ice Distribution in the Bering and Chukchi Seas: Information from Historical Whaleships' Logbooks and Journals
#' ARCTIC. 64(4): 465-477.
#' @examples
#' data(presenceIce)    
#' head(presenceIce) 
'presenceIce'
#' Metrosideros polymorpha in Hawaii
#' @description
#' Data containing 64 observations at the current annual growth rate (defined as dbh increment within one calendar year) 
#' of each tree was measured from 1986 to 1988 using band dendrometers.
#' @usage
#' data(hawaii)
#' @format The data frame contains eight variables as follows:
#' \describe{
#'   \item{tree.code}{Tree number identification.}
#'   \item{dbh}{Initial stem diameter, in cm.}
#'   \item{htot}{Total height in m.}
#'   \item{crown.area}{Crown outline area, in square meters.}
#'   \item{comp.ind}{Competition index (Basal area of nearest neighbor divided by square of distance to nearest neighbor plus
#'          basal area of second nearest neighbor divided by square of distance to second nearest neighbor).}
#'   \item{cai.1986}{Current annual stem diameter increment during 1986, in mm.}
#'   \item{cai.1987}{Current annual stem diameter increment during 1987, in mm.}
#'   \item{cai.1988}{Current annual stem diameter increment during 1988, in mm.}
#'  }
#' @source 
#' The data were provided from .  
#' @references
#' Gerrish G, Mueller-Dombois D. 1999. Measuring stem growth rates for
#' determining age and cohort analysis of a tropical evergreen tree.
#' Pacific Science. 53(4): 418-429. 
#' @examples
#' data(hawaii)    
#' head(hawaii) 
'hawaii'
#' Data from a Pinus radiata plantation near Capitan Pastene, Region de La Araucania, Chile.  
#' @description
#' Tree-level information collected within sample plots in a forestry plantation of Pinus radiata near Capitan Pastene, 
#' Southern Chile. Sample plots size is 150 square meters.
#' @usage
#' data(radiatapl)
#' @format The data frame contains four variables as follows:
#' \describe{
#'   \item{plot}{Plot number identification.}
#'   \item{tree}{Tree number identification.}
#'   \item{dbh}{Diameter at breast height in cm.}
#'   \item{heigth}{Total height in m.}
#'  }
#' @source 
#' The data are provided courtesy of Dr. Christian Salas at
#' the Universidad Mayor (Santiago, Chile).  
#' @examples
#' data(radiatapl)    
#' head(radiatapl) 
'radiatapl'
#' Contains information of annual precipitations in cities of Chile.  
#' @description
#' Data contains annual precipitations in six cities in Chile (Santiago, Talca, Chillan, Temuco, Valdivia, and Puerto Montt) at different years.  
#' @usage
#' data(annualppCities)
#' @format The data frame contains three variables as follows:
#' \describe{
#'   \item{city}{Name of city.}
#'   \item{year}{Year of registry.}
#'   \item{annual}{Value of the annual precipitation of a given year (mm).}
#'  }
#' @source 
#' The data were provided from \url{http://explorador.cr2.cl/}.  
#' @examples
#' data(annualppCities)    
#' head(annualppCities) 
'annualppCities'
#' Contains information of .  
#' @description
#' Data contains.  
#' @usage
#' data(treegrowth)
#' @format Contains 7 variables, as follows:
#' \describe{
#'   \item{tree.id}{.}
#'   \item{forest}{.}
#'   \item{habitat}{.}
#'   \item{tree.code}{.}
#'   \item{age}{.}
#'   \item{dbh}{.}
#'   \item{htot}{.}
#'  }
#' @source 
#' The data were provided.  
#' @references
#' not yet 
#' @examples
#' data(treegrowth)    
#' head(treegrowth) 
'treegrowth'
#' Contains information of .  
#' @description
#' Data contains.  
#' @usage
#' data(fertilizaexpe)
#' @format Contains 3 variables, as follows:
#' \describe{
#'   \item{years}{Year at capture.}
#'   \item{length}{Length at capture (mm).}
#'  }
#' @source 
#' The data were provided.  
#' @references
#' not yet 
#' @examples
#' data(fertilizaexpe)    
#' head(fertilizaexpe) 
'fertilizaexpe'
#' Contains information of wblake datasets of alr4 library .  
#' @description
#' Data on samples of small mouth bass collected in West Bearskin Lake, Minnesota, in 1991. The
#' file wblake includes only fish of ages 8 or younger.  
#' @usage
#' data(fishgrowth)
#' @format Contains 3 variables, as follows:
#' \describe{
#'   \item{years}{Year at capture.}
#'   \item{length}{Length at capture (mm).}
#' \item{scale}{radius of a key scale (mm).}
#'  }
#' @source 
#' The data were provided from alr4 library of R.  
#' @references
#' Weisberg S. 2014. Applied Linear Regression. 4th edition. Hoboken NJ: Wiley 
#' @examples
#' data(fishgrowth)    
#' head(fishgrowth) 
'fishgrowth'
#' Contains information of invasive of pinus spp.  
#' @description
#' These are tree-lavel measurement data from Pinus spp invasion in Araucaria-Nothofagus forests in 
#' the Malalcahuello National Reserve in La Araucania region in southhern Chile, measured in 2012. 
#' The plots area was 100 square meters
#' @usage
#' data(pinusSpp)
#' @format Contains 8 variables, as follows:
#' \describe{
#' \item{plot.id}{Plot sample indentificator number.}
#' \item{size.plot}{Plot size in square meters.}
#' \item{Lat.s}{Decimal coordinate of S latitude.}
#' \item{Long.w}{Decimal coordinate of W longitude.}
#' \item{indv.id}{Tree identificator number in each plot. Same indv/id for multi-stem trees.}
#' \item{stem.id}{Stem identificator number in each plot.}
#' \item{sp}{Specie.}
#' \item{dbh}{Diameter at breast height on trees, in cm.}
#' \item{h}{Height of trees, in m.}
#' \item{canopy.h}{Height at which the live canopy begins, in m.}
#' \item{canopy.lenght}{Lenght of live canopy, in m.}
#' \item{obs}{Extra information.}
#' }
#' @source 
#'  The data are provided courtesy of Drs. Anibal Pauchard and Rafael Garcia at the Laboratorio de Invasiones
#'  Biologicas, Universidad de Concepcion (Chile).
#' @references
#'  Cobar-Carranza A, Garcia R, Pauchard A & Pena E. 2014. Effect of Pinus contorta invasion on forest fuel properties and
#'  its potential implications on the fire regime of Araucaria araucana and Nothofagus antarctica forests.
#'  Biological Invasions. 16(11): 2273 - 2291
#
#' @examples
#' data(pinusSpp)    
#' head(pinusSpp) 
'pinusSpp'
#' Contains information of invasive of pinus contorta.  
#' @description
#' These are tree-lavel measurement data, with x,y location of each tree, from Pinus contorta invasion in 
#' Patagonian steppe in Coyhaique in southhern Chile, measured in 2011. The plots area was 10000 square meters.   
#' @usage
#' data(pinusContorta)
#' @format Contains 8 variables, as follows:
#' \describe{
#'   \item{plot.id}{Plot sample identificativo number.}
#'   \item{tree.id}{Tree identificator number in each plot. Same indv/id for multi-stem trees.}
#' \item{y.coord}{coordinate of S latitude.}
#' \item{x.coord}{coordinate of W longitude.}
#' \item{substrate}{Ground cover in which each pine grow. Bare soil, Festuca pallescens, Baccharis magellanica, 
#' Oreopulus glacialis, Acaena integerrima and others species.}
#' \item{drc}{Diameter at the root collar on trees, in mm.}
#' \item{h}{Height of trees, in cm.}
#' \item{canopy.area}{Proyection of canopy area of each tree, in square meters.}
#' }
#' @source 
#'  The data are provided courtesy of Drs. Anibal Pauchard and Rafael Garcia at the Laboratorio de Invasiones Biologicas,
#'  Universidad de Concepcion (Chile).
#' @references
#'  Pauchard A, A Escudero, RA Garcia, M de la Cruz, B Langdon, LA Cavieres & J Esquivel. 2016.
#'  Pine invasions in treeless environments: dispersal overruns microsite heterogeneity. 
#'  Ecology and Evolution. 6(2): 447 - 459
#' @examples
#' data(pinusContorta)    
#' head(pinusContorta) 
'pinusContorta'
#' Contains information of data airquality of datasets library.  
#' @description
#' Daily air quality measurements in New York, May to September 1973.   
#' @usage
#' data(airquality)
#' @format Contains 6 variables, as follows:
#' \describe{
#'   \item{ozone}{numeric	Ozone (ppb).}
#'   \item{solar}{numeric	Solar R (lang).}
#' \item{wind}{numeric	Wind (mph).}
#' \item{temp}{numeric	Temperature (degrees F).}
#' \item{month}{numeric	Month (1--12).}
#' \item{day}{numeric	Day of month (1--31).}
#'  }
#' @source 
#' The data were provided from datasets library datasets.  
#' @references
#' Chambers J, Cleveland W, Kleiner B, Tukey P. 1983. Graphical Methods for Data Analysis. Belmont. CA: Wadsworth.
#' @examples
#' data(airquality)    
#' head(airquality) 
'airquality'
#' Contains information of florida datasets of alr4 library .  
#' @description
#' County-by-county vote for president in Florida in 2000 for Bush, Gore and Buchanan.  
#' @usage
#' data(election)
#' @format Contains 3 variables, as follows:
#' \describe{
#'   \item{gore}{Vote for Gore.}
#'   \item{bush}{Vote for Bush.}
#' \item{buchaman}{Vote for Buchaman.}
#'  }
#' @source 
#' The data were provided from alr4 library of R.  
#' @references
#' Weisberg S. 2014. Applied Linear Regression. 4th edition. Hoboken NJ: Wiley 
#' @examples
#' data(election)    
#' head(election) 
'election'
#' Contains information of data ufc of alr4 library.  
#' @description
#' These data are forest inventory measures from the Upper Flat Creek stand of the University 
#' of Idaho Experimental Forest, dated 1991.   
#' @usage
#' data(idahohd)
#' @format Contains 5 variables, as follows:
#' \describe{
#'   \item{plot}{plot number.}
#'   \item{tree}{tree within plot.}
#' \item{species}{a factor with levels DF = Douglas-fir, GF = Grand fir, SF = Subalpine fir, WL = Western larch,
#'                 WC = Western red cedar, WP = White pine.}
#' \item{dbh}{Diameter 137 cm perpendicular to the bole, mm.}
#' \item{height}{Height of the tree, in decimeters.}
#'  }
#' @source 
#' The data were provided from alr4 library of R.  
#' @references
#' Weisberg S. 2014. Applied Linear Regression. 4th edition. New York: Wiley.
#' @examples
#' data(idahohd)    
#' head(idahohd) 
'idahohd'
#' Contains information of ChichWeigth data of alr4 library.  
#' @description
#' The body weights of the chicks were measured at birth and every second day thereafter until day 20. They were 
#' also measured on day 21. There were four groups on chicks on different protein diets.  
#' @usage
#' data(chicksw)
#' @format Contains 4 variables, as follows:
#' \describe{
#'   \item{weight}{a numeric vector giving the body weight of the chick (gm).}
#'   \item{time}{a numeric vector giving the number of days since birth when the measurement was made.}
#' \item{chick}{an ordered factor with levels different giving a unique identifier for the chick. The ordering of the
#'             levels groups chicks on the same diet together and orders them according to their final weight 
#'             (lightest to heaviest) within diet.}
#' \item{diet}{a factor with levels 1,2,3 and 4 indicating which experimental diet the chick received.}
#'  }
#' @source 
#' The data were provided from alr4 library of R.  
#' @references
#' Crowder M, Hand D. 1990. Analysis of Repeated Measures. Chapman and Hall
#' @examples
#' data(chicksw)    
#' head(chicksw) 
'chicksw'
#' Contains information of .  
#' @description
#' Dataset contains 36 observations   
#' @usage
#' data(sludge)
#' @format Contains 4 variables, as follows:
#' \describe{
#'   \item{ciudad}{.}
#'   \item{tasa}{.}
#' \item{zinc}{.}
#' \item{trt.comb}{.}
#'  }
#' @source 
#' The data were provided from.  
#' @references
#' not yet 
#' @examples
#' data(sludge)    
#' head(sludge) 
'sludge'
#' Contains information of annual basal area increment (BAI) for different species.  
#' @description
#' Dataset contains 157 observations, of the last 10 years in 6-8 adult trees of different species 
#' at three elevations of altitudinal gradients sampled in four locations of Chile and two in Spain.
#' @usage
#' data(baiTreelines)
#' @format Contains 7 variables, as follows:
#' \describe{
#'   \item{climate}{Climate of each location, mediterranean and temperate.}
#'   \item{site}{Name of Location of study (termmas:Termas de Chillan , antillanca:Antillanca area within Puyehue National Park,
#'               castillo:Cerro Castillo Natural Reserve, farellones:Farellones in Central Chile, 
#'               pyrenees: Sierra de Cutas area in Spanish Central Pyrenees,sierra:Sierra Nevada).}
#' \item{species}{name species of study (lenga: Nothofagus pumilio, frangel: Kageneckia angustifolia,
#'                uncinata: Pinus uncinata, sylvestris: Pinus sylvestris).}
#' \item{elevation}{Type of elevation. "Treeline", intermediate named as "inter", and closed or
#'       montane forest named as low.}
#' \item{tree}{Id for tree.}
#' \item{bai}{Value of annual basal area increment.}
#' \item{mean.bai}{Mean of annual basal area increment.}
#'  }
#' @source 
#' The data were provided from DRYAD repository.  
#' @references
#' Piper F, Vinegla B, Linares J, Camarero J, Cavieres L,Fajardo A. 2016. Mediterranean and temperate treelines are 
#' controlled by different environmental drivers. Journal Ecology. 104: 691-702. DOI:10.1111/1365-2745.12555 
#' @examples
#' data(baiTreelines)    
#' head(baiTreelines) 
'baiTreelines'
#' Contains information of carbohydrates concentrations .  
#' @description
#' Dataset contains 863 observations, about of  total soluble carbohydrate, starch, and non structural carbohydrates 
#' concentrations per mass unit and per volume unit, in three tissues in early summer and early autumn6-8 adult trees
#' of different specie at three elevations of altitudinal gradients sampled in four locations of Chile,
#' and Spain.
#' @usage
#' data(carbohydrateTreelines)
#' @format Contains 16 variables, as follows:
#' \describe{
#'   \item{climate}{Climate of each location, mediterranean and temperate.}
#'   \item{site}{Name of Location of study (termmas:Termas de Chillan , antillanca:Antillanca area within Puyehue National Park,
#'               castillo:Cerro Castillo Natural Reserve, farellones:Farellones in Central Chile, 
#'               pyrenees: Sierra de Cutas area in Spanish Central Pyrenees,sierra:Sierra Nevada).}
#' \item{species}{name species of study (lenga: Nothofagus pumilio, frangel: Kageneckia angustifolia,
#'                uncinata: Pinus uncinata, sylvestris: Pinus sylvestris).}
#' \item{tissue}{Type of tissue, new developing twings, stem sapwood and branches.}
#' \item{time}{Meauserement season (spring or autumn).}
#' \item{elevation}{Type of elevation. "Treeline", intermediate named as "mid", and closed or
#'       montane forest named as "low".}
#' \item{tree}{Id for tree.}
#' \item{tree.site}{Id site for each location of study.}
#' \item{tss}{Value of concentrations soluble carbohydrate per mass unit.}
#' \item{st}{Value of concentrations starch per mass unit.}
#' \item{nsc}{Value of concentrations non structural carbohydrates per mass unit.}
#' \item{tss.nsc}{.}
#' \item{wd}{.}
#' \item{tss.mv}{Value of concentrations soluble carbohydrate per volume unit.}
#' \item{st.mv}{Value of concentrations starch per volume unit.}
#' \item{nsc.mv}{Value of concentrations non structural carbohydrates per volume unit.}
#'  }
#' @source 
#' The data were provided from DRYAD repository.  
#' @references
#' Piper F, Vinegla B, Linares J, Camarero J, Cavieres L,Fajardo A. 2016. Mediterranean and temperate treelines are 
#' controlled by different environmental drivers. Journal Ecology. 104: 691-702. DOI:10.1111/1365-2745.12555 
#' @examples
#' data(carbohydrateTreelines)    
#' head(carbohydrateTreelines) 
'carbohydrateTreelines'
#' Contains information of plants Hawaiians.  
#' @description
#' Dataset contains 43590 observations,   
#' @usage
#' data(forestHawaiian)
#' @format Contains 18 variables, as follows:
#' \describe{
#'   \item{island}{Island name.}
#'   \item{plot.id}{Unique numeric identifier for each plot.}
#' \item{study}{Brief name of study.}
#' \item{plot.area}{Plot area in m2.}
#' \item{longitude}{Longitude of plot in decimal degrees; WGS84 coordinate system.}
#' \item{latitude}{Latitude of plot in decimal degrees; WGS84 coordinate system.}
#' \item{year}{Year in which plot data was collected.}
#' \item{census}{Numeric identifier for each census.}
#' \item{tree.id}{Unique numeric identifier for each individual.}
#' \item{scientific.name}{Genus and species of each individual following TPL v. 1.1.}
#' \item{family}{Family of each individual following TPL v. 1.1.}
#' \item{angiosperm}{Binary variable (1 = yes, 0 = no) indicating whether an individual is classified as an angiosperm following APG III.}
#' \item{monocot}{Binary variable (1 = yes, 0 = no) indicating whether an individual is classified as a monocot following APG III.}
#' \item{native.status}{Categorical variable ('native', 'alien', 'uncertain') indicating alien status of each individual following Wagner et al. (2005).}
#' \item{cultivated.status}{Binary variable (1 = yes, 0 = no, NA = not applicable) indicating if species is cultivated following PIER.}
#' \item{abundance}{Number of individuals (all = 1).}
#' \item{abundance.ha}{Abundance of each individual on a per hectare basis.}
#' \item{dbh}{Diameter at 1.3 m (DBH in cm) for each individual; NA indicates that size was not measured, but was classified by size class.}
#'  }
#' @source 
#' The data were provided from DRYAD repository.  
#' @references
#' - Craven D, Knight T,Barton K,Bialic-Murphy L,Cordell S, Giardina C, Gillespie T, Ostertag R, Sack L,Chase J. 2018. 
#' OpenNahele: the open Hawaiian forest plot database. Biodiversity Data Journal 6: e28406. \url{https://doi.org/10.3897/BDJ.6.e28406}  
#' @examples
#' data(forestHawaiian)    
#' head(forestHawaiian) 
'forestHawaiian'
#' Contains information of plants Hawaiians.  
#' @description
#' Dataset contains 58 observations,   
#' @usage
#' data(plantsHawaiian)
#' @format Contains 6 variables, as follows:
#' \describe{
#'   \item{scientific.name}{Genus and epithet of each individual following The Plant List v. 1.1 (2013).}
#'   \item{family}{Family of each individual following The Plant List v. 1.1 (2013).}
#' \item{native.status}{Categorical variable ('native', 'alien', 'uncertain') indicating alien status of each individual following Wagner et al. (2005).}
#' \item{n}{Number of individuals used to estimate maximum plant size.}
#' \item{d.95}{Maximum plant size, estimated as D950.1 (King et al. 2006).}
#' \item{d.max.3}{Maximum plant size, estimated as Dmax3 (King et al. 2006).}
#'  }
#' @source 
#' The data were provided from DRYAD repository.  
#' @references
#' - Craven D, Knight T,Barton K,Bialic-Murphy L,Cordell S, Giardina C, Gillespie T, Ostertag R, Sack L,Chase J.
#' 2018. OpenNahele: the open Hawaiian forest plot database. Biodiversity Data Journal 6: e28406. \url{https://doi.org/10.3897/BDJ.6.e28406}  
#' @examples
#' data(plantsHawaiian)    
#' head(plantsHawaiian) 
'plantsHawaiian'
#' Contains information of .  
#' @description
#' Dataset contains E   
#' @usage
#' data(floraChile)
#' @format Contains xx variables, as follows:
#' \describe{
#'   \item{family}{.}
#'   \item{genus}{.}
#' \item{scientific.name}{.}
#' \item{author}{.}
#' \item{origin}{.}
#' \item{life.form}{.}
#' \item{lat...}{.}
#'  }
#' @source 
#' The data were provided from Jan Bannister researcher at Institute National Forest in Chile (INFOR).  
#' @references
#' not yet 
#' @examples
#' data(floraChile)    
#' head(floraChile) 
'floraChile'
#' Contains information about regeneration of nothofagus.  
#' @description
#' Dataset contains 442 observations.   
#' @usage
#' data(regenerationNothofagus)
#' @format Contains 15 variables, as follows:
#' \describe{
#'   \item{site}{Id site of study.}
#'   \item{plot}{Number of plot.}
#' \item{scar}{Scarification in percentage of total area.}
#' \item{x.trans.total}{Transmitted radiation in percentage.}
#' \item{kPa}{Soil resistance to penetration.}
#' \item{SWC}{Soil water content.}
#' \item{SM}{Exposed mineral soil.}
#' \item{litter}{Litter cover in percentage.}
#' \item{CWD}{Ocular estimation in the regeneration plot in percentage.}
#' \item{MT}{Microtopography. 1 plane, 2 convex, 3 concave, 4 mixed (convex and concave) in the regeneration plot.}
#' \item{S}{Ground-layer vascular species richness in the regeneration plot..}
#' \item{LLES}{Long-lived early-seral tree species (N. dombeyi , N. alpina , Nothofagus pumilio ).}
#' \item{SLES}{Short-lived early-seral plants (Ribes spp. and Fuchsia sp).}
#' \item{LLLS}{Long-lived late-seral tree species (L. philippiana and Dasyphyllum diacantaoides ).}
#' \item{log.bam}{Logarithm of the cover of bamboo (%) in the regeneration plot.}
#'  }
#' @source 
#' The data were provided from DRYAD repository  
#' @references
#'  - Soto D, Puettmann K.2018.Topsoil removal through scarification improves natural regeneration
#'   in high-graded Nothofagus old-growth forests.Journal Applied Ecology. 55: 967- 976. \url{https://doi.org/10.1111/1365-2664.12989} 
#' @examples
#' data(regeneraNothofagus)    
#' head(regeneraNothofagus) 
'regeneraNothofagus'
#' Contains information of demography of species.  
#' @description
#' Dataset contains 61 observations about life histories values for each species and site,
#'  as obtained from the parameterization carried out in studies that used the model SORTIE   
#' @usage
#' data(demograph)
#' @format Contains 15 variables, as follows:
#' \describe{
#'   \item{sp}{Name specie.}
#'   \item{site}{Name of site of study.}
#' \item{country}{Name of country.}
#' \item{site.n}{Code of site.}
#' \item{code}{Code of specie.}
#' \item{genus}{Genus of specie.}
#' \item{sps}{Abbreviated name specie.}
#' \item{family}{Family of specie.}
#' \item{phyl}{Type of phylogeny.}
#' \item{l.hab}{Type of leaf habit.}
#' \item{l.type}{.}
#' \item{leaf}{Type of leaf.}
#' \item{growth.l}{Growth at full light (time in years).}
#' \item{growth.d}{Growth in shade.}
#' \item{surv.d}{Survival in shade.}
#'  }
#' @source 
#' The data were provided from DRYAD repository  
#' @references
#'  - Ameztegui A, Paquette A, Shipley B, Heym M, Messier C, Gravel D. 2016 . Shade tolerance and 
#'  the functional trait: demography relationship in temperate and boreal forests. Functional Ecology, 
#'  31: 821-830. DOI:10.1111/1365-2435.12804
#' @examples
#' data(demograph)    
#' head(demograph) 
'demograph'
#' Contains information of functional traits of species.
#' @description
#' Dataset contains 48 observations about about functional trait values for each of the 48 study species, 
#' including 23 evergreen and 25 deciduous.
#' @usage
#' data(sppTraits)
#' @format Contains 17 variables, as follows:
#' \describe{
#' 	\item{sp}{Abbreviated name of specie.}
#'   	\item{sp.name}{Name of specie.}
#' 	\item{family}{Family of specie.}
#' 	\item{genus}{Genus of specie.}
#' 	\item{phyl}{Type of phylogeny.}
#' 	\item{l.hab}{Type of leaf habit.}
#' 	\item{leaf}{Type of leaf.}
#' 	\item{lt}{.}
#' 	\item{lma}{Leaf mass area.}
#' 	\item{amass}{Photosynthetic capacity per unit leaf mass.}
#' 	\item{n.mass}{Leaf N content per unit mass.}
#' 	\item{pmass}{Leaf P content per unit mass.}
#' 	\item{l.lifespan}{Leaf life span.}
#' 	\item{l.length}{Leaf length.}
#' 	\item{sem}{Seed mass.}
#' 	\item{wd}{Wood density.}
#' 	\item{max.h}{Maximum height.}
#'   }
#' @source 
#' The data were provided from DRYAD repository  
#' @references
#'  - Ameztegui A, Paquette A, Shipley B, Heym M, Messier C, Gravel D. 2016 . Shade tolerance and 
#'  the functional trait: demography relationship in temperate and boreal forests.Functional Ecology, 
#'  31: 821-830. DOI:10.1111/1365-2435.12804
#' @examples
#' data(sppTraits)    
#' head(sppTraits) 
'sppTraits'
#' Contains information of Camera trap data on medium to large terrestrial mammals 
#' collected at 54 camera stations in Ruaha National Park, southern Tanzania.
#' @description
#' Dataset contains 14604 observations and sampling was carried out for two months during the
#' dry season of 2013 and two months during the wet season of 2014. Each camera station is associated
#' with a randomly placed camera and a trail-based camer, with the aim of comparing communities 
#' resulting from the two camera trap placement strategies. 
#' @usage
#' data(trailCameraTrap)
#' @format Contains 6 variables, as follows:
#' \describe{
#'   \item{reference}{Number of observation od datasets.}
#'   \item{placement}{Type of "placement" placed in each station (random or trail).}
#' \item{season}{Season where were made the samplings.}
#' \item{station}{Station where were collected the data.}
#' \item{specie}{Name of specie medium to large terrestrial mammals.}
#' \item{date.time}{The date and time of each photographic event is also given.}
#'  }
#' @source 
#' The data are provided courtesy of Dr. Jeremy Cusack at the Universidad Mayor (Santiago, Chile)  
#' @references
#'  - Cusack J, Dickman A, Rowcliffe M, Carbone C, Macdonald D, Coulson T. 2016 . Random versus
#'   game trail-based camera trap placement strategy for monitoring terrestrial mammal communities. PLoS ONE 10(5): e0126373.
#' @examples
#' data(trailCameraTrap)    
#' head(trailCameraTrap) 
'trailCameraTrap'
#' Contains information of abundance of plant species in the central-southern Andes of Chile.
#' @description
#' Abundance of plant species [50 total] (at parcel scale [100 m2]) in burned Araucaria-Nothofagus 
#' forests with different levels of fire severity (ie, unburned = unburned, low_sev = low severity, 
#' mid_sev = medium severity , high_sev = high severity) in the China Muerta National Reserve, 
#' Andes of central-southern Chile.
#' @usage
#' data(sppAbundance)
#' @format Contains 6 variables, as follows:
#' \describe{
#'   \item{sp.name}{name of specie.}
#'   \item{sp.code.name}{code of specie}
#' \item{unburned}{Abundance of plants unburned.}
#' \item{low.sev}{Abundance of plants for low severity of burned.}
#' \item{mid.sev}{Abundance of plants for middle severity of burned.}
#' \item{high.sev}{Abundance of plants for high severity of burned.}
#'  }
#' @source 
#' The data are provided courtesy of Dr. Christian Salas at
#' the Universidad Mayor (Santiago, Chile) and Dr. Andres Fuentes at the Universidad 
#' of La Frontera (Temuco, Chile)   
#' @references
#'  - Fuentes A,Salas C,Gonzalez M, Urrutia J, Arroyo P, Santibanez
#'   P. 2020. Initial response of understorey vegetation and tree
#'   regeneration to a mixed-severity fire in old-growth Araucaria-Nothofagus forests.Applied 
#'   Vegan Science. 23:210-222.
#' @examples
#' data(sppAbundance)    
#' head(sppAbundance) 
'sppAbundance'
#' Contains tree-level variables for Pinus pinaster in the Baixo-Mino, Galicia, Spain. 
#'
#' @description
#' These are tree-level measurement data of sample trees in the Baixo-Mino region in Galicia, Spain.
#' @usage
#' data(pinaster)
#' @format Contains tree-level variables, as follows:
#' \describe{
#'   \item{stand}{stand number from the sample tree was selected.}
#' \item{si}{Site index of the stand.}
#' \item{tree.no}{tree number.}
#' \item{dbh}{Diameter at breast height, in cm.}
#' \item{htot}{Total height, in m.}
#'  \item{d4}{Upper-stem diameter at 4 m, in cm.}
#' \item{vol.wb}{Tree gross volume, in m^{3} with bark.}
#' \item{vol.wob}{Tree gross volume, in m^{3} without bark.}
#'  }
#' @source 
#' The data are provided courtesy of Dr. Christian Salas at
#' the Universidad Mayor (Santiago, Chile).  
#' @references
#'  - Salas C, Nieto L, Irisarri A. 2005. Modelos de volumen para Pinus pinaster Ait. en la comarca del Baixo Mino,
#'   Galicia, Espana. Quebracho 12: 11-22.
#' @examples
#' data(pinaster)    
#' head(pinaster) 
'pinaster'
#' Simulated yield of forestry plantations of exotic species in Chile. 
#'
#' @description
#' The yield tables of simulated plantations of Pinus radiata, Eucalyptus globulus, and Eucalyptus nitens
#'  are obtained from the Radiata simulator and EucaSim simulator built in Chile. Several stand-level variables 
#'  are part of the output.
#' @usage
#' data(simula)
#' @format Contains stand-level variables, as follows:
#' \describe{
#'   \item{species}{"P. radiata" is Pinus radiata, "E. globulus" is Eucalyptus globulus, and "E. nitens" is
#'   Eucalyptus nitens.}
#' \item{age}{plantation age, in years}
#'   \item{tph }{Tree density, in trees/ha}
#'  \item{gha }{Basal area, in m^{2}/ha}
#' \item{toph}{Dominant height, in m}
#'  \item{qmd}{quadratic mean diameter, in cm}
#' \item{totvol}{gross stand volume, in m^{3}/ha} 
#' \item{viu.10}{stand volume below an utilizacion index of 10 cm, in m^{3}/ha} 
#' \item{viu.15}{stand volume below an utilizacion index of 15 cm, in m^{3}/ha} 
#' \item{viu.20}{stand volume below an utilizacion index of 20 cm, in m^{3}/ha} 
#' \item{viu.25}{stand volume below an utilizacion index of 25 cm, in m^{3}/ha} 
#'  }
#' @source 
#'  The data were obtained as outputs for plantations without management in Chile. The academic
#'  version of the simulator was used. You can visit mnssimulacion.cl
#' @examples
#' data(simula)    
'simula'
#' Tree locations for a sample plot in the Llancahue experimental forest, near Valdivia, Chile. 
#'
#' @description
#' The Cartesian position, species, and diameter of trees within a plot were measured. The sample plot is  rectangular of 130 m by 70 m. Further details can be #' reviewed in the reference. 
#' @usage
#' data(pspLlancahue)
#' @format Contains tree-level variables, as follows:
#' \describe{
#'   \item{tree.code}{Tree identificator}
#' \item{spp.name}{species abreviation as follows: AP= Aextocicon puncatatum, EC=Eucryphia cordifolia, GA=Gevuina avellana, 
#'  LP= Laureliopsis philippiana, LS= Laurelia sempervirens, ND=Nothofagus dombeyi, Ot=Other, PS=Podocarpus saligna}
#' \item{dbh}{diameter at breast height, in cm}
#' \item{x.coord}{Cartesian position in the X-axis, in m}
#' \item{y.coord}{Cartesian position in the Y-axis, in m}
#'  }
#' @source 
#'  The data are provided courtesy of Prof. Daniel Soto at Universidad
#'  de Aysen (Coyhaique, Chile). 
#' @references
#' - Soto DP, Salas C, Donoso PJ, Uteau D. 2010. Heterogeneidad estructural y espacial de un bosque mixto dominado por
#' Nothofagus dombeyi despues de un disturbio parcial. Revista Chilena de Historia Natural 83(3): 335-347.
#' @examples
#' data(pspLlancahue)    
#' head(pspLlancahue) 
'pspLlancahue'
#' Leaf measurements for Eucalyptus nitens trees in Tasmania, Australia. 
#'
#' @description
#' The length, width, and area of Eucalyptus nitens leaves were measured. 
#' @usage
#' data(eucaleaf)
#' @format Contains leaf-level variables, as follows:
#' \describe{
#'   \item{time}{Early or Late}
#' \item{tree}{an identificator for a given sample tree}
#' \item{shoot}{shoot desxription}
#' \item{l}{length of the leaf, in mm}
#' \item{w}{width of the leaf, in mm}
#' \item{la}{leaf area, in cm^2}
#'  }
#' @source 
#' Although the original source of the measurements is the Dissertation of Dr. Candy (1999), 
#'  the data file used here was courtesy of Prof. Timothy Gregoire at
#'  Yale University (New Haven, CT, USA). Furthermore, these data were used by
#'  Gregoire and Salas (2008).
#' @references
#' - Candy SG. (1999). Predictive models for integrated pest management of the
#' leaf beetle Chrysophtharta bimaculata in Eucalyptus nitens in Tasmania. Doctoral dissertation,
#'  University of Tasmania, Hobart, Australia. 
#' @references
#' - Gregoire TG, and Salas C. 2009. Ratio estimation with measurement
#' error in the auxiliary variate. Biometrics 65(2):590-598
#' @examples
#' data(eucaleaf)    
#' head(eucaleaf) 
'eucaleaf'
#' Age and physical measurement data for wild bears. Dataframe same as "bears" but without missing values.
#'
#' @description
#' Wild bears were anesthetized, and their bodies were measured and weighed.
#' One goal of the study was to make a table (or perhaps a set of tables) for
#'  people interested in estimating the weight of a bear based on other measurements. 
#'  This would be used because in the forest it is easier to measure the length
#'   of a bear, for example, than it is to weigh it.
#' @usage
#' data(bears2)
#' @format Contains individual-level variables, as follows:
#' \describe{
#'   \item{id}{Bear identificator}
#' \item{age}{age in months}
#' \item{month}{Diameter at breast height, in cm}
#' \item{sex}{1 =male, 2 = female}
#' \item{headL}{length of head, in cm}
#' \item{headW}{width of head, in cm}
#' \item{neckG}{girth of neck, in cm}
#' \item{length}{body length, in cm}
#' \item{chestG}{girth of chest, in cm}
#' \item{weight}{body weight, in kg}
#' \item{obs}{observation number for bear}
#' \item{name}{name given to bear}
#'  }
#' @source 
#' Minitab, Inc. The data description is courtesy of Prof. Timothy Gregoire at
#'  Yale University (New Haven, CT, USA).
#' @references
#' According to Prof. Gregoire, This data set was supplied by Gary Alt. Entertaining 
#'  references are in Reader's Digest April, 1979, and Sports Afield September, 1981.
#' @examples
#' data(bears2)    
#' head(bears2) 
'bears2'
#' Age and physical measurement data for wild bears. 
#'
#' @description
#' Wild bears were anesthetized, and their bodies were measured and weighed.
#' One goal of the study was to make a table (or perhaps a set of tables) for
#'  people interested in estimating the weight of a bear based on other measurements. 
#'  This would be used because in the forest it is easier to measure the length
#'   of a bear, for example, than it is to weigh it.
#' Notice that there are missing values for some of the variables.
#' @usage
#' data(bears)
#' @format Contains individual-level variables, as follows:
#' \describe{
#'   \item{id}{Bear id}
#' \item{age}{age in months}
#' \item{month}{Diameter at breast height, in cm}
#' \item{sex}{1 =male, 2 = female}
#' \item{headL}{length of head, in cm}
#' \item{headW}{width of head, in cm}
#' \item{neckG}{girth of neck, in cm}
#' \item{length}{body length, in cm}
#' \item{chestG}{girth of chest, in cm}
#' \item{weight}{body weight, in kg}
#' \item{obs}{observation number for bear}
#' \item{name}{name given to bear}
#'  }
#' @source 
#' Minitab, Inc. The data description is courtesy of Prof. Timothy Gregoire at
#'  Yale University (USA).
#' @references
#' According to Prof. Gregoire, This data set was supplied by Gary Alt. Entertaining 
#'  references are in Reader's Digest April, 1979, and Sports Afield September, 1981.
#' @examples
#' data(bears)    
#' head(bears) 
'bears'
#' Contains tree-level variables for roble (Nothofagus obliqua) in the Rucamanque experimental forest, near Temuco, Chile. 
#'
#' @description
#' These are tree-level measurement data of sample trees in the Rucamanque experimental forest, 
#'  near Temuco, in the Araucania region in south-centralChile, measured in 1999.  The
#' data are the same as in the dataframe "treevolruca", but only having observations for the 
#' species roble (Nothofagus obliqua).
#' @usage
#' data(treevolroble)
#' @format Contains tree-level variables, as follows:
#' \describe{
#'   \item{tree.no}{Tree id}
#' \item{spp}{Species}
#' \item{dbh}{Diameter at breast height, in cm}
#' \item{htot}{Total height (m)}
#'  \item{d6}{Upper-stem diameter at 6 m, in cm}
#' \item{vtot}{Tree gross volume, in m^{3} with bark.}
#'  }
#' @source 
#' The data are provided courtesy of Dr. Christian Salas at
#' the Universidad Mayor (Santiago, Chile).  
#' @references
#' Salas C. 2002. Ajuste y validacion de ecuaciones de volumen para un relicto
#'  del bosque de Roble-Laurel-Lingue [Fitness and validation of volume equations for a relict forest of Roble-Laurel-Lingue].
#'   Bosque 23(2): 81-92.
#' @examples
#' data(treevolroble)    
#' head(treevolroble) 
'treevolroble'
#' Contains tree-level variables of several species in the Rucamanque experimental forest, near Temuco, Chile. 
#'
#' These are tree-level measurement data of sample trees in the Rucamanque experimental forest, 
#'  near Temuco, in the Araucania region in south-centralChile, measured in 1999.  The following
#'  species are part of the data: laurel (laurelia sempervirens), lingue (Persea lingue), olivillo (Aextocicon puncatum), 
#'  roble (Nothofagus obliqua), tepa (Laureliosis philippiana), y tineo (Weinmannia trichosperma).
#' @usage
#' data(treevolruca)
#' @format Contains tree-level variables, as follows:
#' \describe{
#'   \item{tree.no}{Tree id.}
#' \item{spp}{Species.}
#' \item{dbh}{Diameter at breast height, in cm.}
#' \item{htot}{Total height, in m.}
#'  \item{d6}{Upper-stem diameter at 6 m, in cm.}
#' \item{vtot}{Tree gross volume, in m^{3} with bark.}
#'  }
#' @source 
#' The data are provided courtesy of Dr. Christian Salas of
#' the Universidad Mayor (Santiago, Chile).  The data were used in the 
#' study of Salas (2002).
#' @references
#' Salas C. 2002. Ajuste y validacion de ecuaciones de volumen para un relicto
#'  del bosque de Roble-Laurel-Lingue [Fitness and validation of volume equations for a relict forest of Roble-Laurel-Lingue].
#'   Bosque 23(2): 81-92.
#' @examples
#' data(treevolruca)    
#' head(treevolruca) 
'treevolruca'
#' Contains plot-level variables in Araucaria araucana forests in southern Chile. 
#'
#'
#' @description
#' These are plot-level measurement data from the Araucaria araucana forests 
#'  in the Araucania region in southern Chile, measured in 2009.  The
#' data inventory was based on fixed-area plots of 1000 m^2.  They are two forest stands.
#' @usage
#' data(araucaria)
#' @format Contains plot-level variables as follows:
#' \describe{
#'   \item{stand}{Stand number}
#'   \item{plot.no}{Plot sample identificator number}
#'   \item{x.utm}{UTM  coordinate in X-axis, in km}
#'   \item{y.utm}{UTM  coordinate in Y-axis, in km}
#'     \item{slope}{Slope, in \%}
#' \item{aspect}{Aspect, in degrees}
#'     \item{eleva}{Elevation, in msnm}    
#'   \item{nha }{Tree density, in trees/ha}
#'  \item{gha }{Basal area, in m^{2}/ha}
#' \item{hdom}{Dominant height, in m}
#' \item{vha }{Gross stand volume, in m^{3}/ha} 
#'  \item{dg}{Diameter of the average basal area tree of the plot, in cm}
#'  }
#' @source  
#' The data are provided courtesy of Dr. Nelson Ojeda at
#' the Universidad de La Frontera (Temuco, Chile).  
#' @references
#' Salas C, Ene L, Ojeda N, Soto H. 2010. Metodos estadisticos parametricos y no parametricos
#'    para predecir variables de rodal basados en Landsat ETM+: una comparacion en un bosque
#'     de Araucaria araucana en Chile [Parametric and non-parametric statistical methods for 
#'     predicting plotwise variables based on Landsat ETM+: a comparison in an Araucaria araucana forest
#'      in Chile]. Bosque 31(3): 179-194. 
#' @examples
#' data(araucaria)    
#' head(araucaria) 
"araucaria"
#' Diameter, height and volume for Black Cherry Trees
#' 
#' @description
#' This data set provides measurements of the diameter, height and volume of timber in 31 felled black cherry trees.
#' This dataframe is a slight modification to the original dataframe "trees" from the datasets R package.
#' @usage
#' data(treevol)
#' @format A data frame with 31 observations on three variables
#' \describe{
#' \item{dbh}{diameter at breast height, in cm}
#' \item{htot}{total height, in m}
#' \item{volume}{volume of timber, in cubic meters}
#'  }
#' @source 
#' Ryan, T. A., Joiner, B. L. and Ryan, B. F. (1976) The Minitab Student Handbook. Duxbury Press.
#' @examples
#' #pairs(treevol, panel = panel.smooth, main = "treevol dataframe")
#' #plot(volume ~ dbh, data = treevol, log = "xy")
#' #coplot(log(volume) ~ log(dbh) | htot, data = treevol,
#' #       panel = panel.smooth)
#' #summary(m1 <- lm(log(volume) ~ log(dbh), data = treevol))
#' #summary(m2 <- update(m1, ~ . + log(htot), data = treevol))
#' #anova(m1,m2)
'treevol'
#' Diameter growth of orange trees
#' 
#' @description
#' The orange data frame has 35 rows and four columns of records of the growth of orange trees.
#' @usage
#' data(orange)
#' @format An object of class c("nfnGroupedData", "nfGroupedData", "groupedData", "data.frame") containing the following columns:
#' \describe{
#' \item{tree.id}{an ordered factor indicating the tree on which the measurement is made. The ordering is according to increasing maximum diameter.}
#' \item{time}{a numeric vector giving the numbers of days since 1968/12/31}
#' \item{girth}{a numeric vector of trunk perimeter (mm). This is probably a circumference at breast height, a standard measurement in forestry.}
#' \item{dbh}{a numeric vector of diameter at breast height (mm).}
#'  }
#' @source 
#' Draper NR and Smith H. (1998), Applied Regression Analysis (3rd ed), Wiley (exercise 24.N).
#' @examples
#' #data(orange)
#' 
#' #coplot(dbh ~ time | tree.id, data = orange, show.given = FALSE)
#' #m1 <- nls(dbh ~ SSlogis(age, Asym, xmid, scal),
#' #           data = orange, subset = tree.id == 3)
#' #plot(dbh ~ time, data = orange, subset = tree.id == 3,
#' #     xlab = "Time (number of days since 1968/12/31)",
#' #     ylab = "Tree diameter (mm)", las = 1,
#' #     main = "Diameter growth data of orange trees and fitted model (tree.id 3 only)")
#' #time <- seq(0, 1600, length.out = 101)
#' #lines(time, predict(m1, list(time = time)))
'orange'
#' Height growth of Pinus taeda (Loblolly pine) trees
#' 
#' @description
#' The Loblolly data frame has 84 rows and tree columns of records of the tree height growth of Loblolly pine trees. This dataframe
#'  is a slight modification to the original dataframe "Loblolly" from the datasets R package.
#' @usage
#' data(ptaeda)
#' @format An object of class c("nfnGroupedData", "nfGroupedData", "groupedData", "data.frame") containing the following columns:
#' \describe{
#' \item{seed.id}{an ordered factor indicating the seed source for the tree. The ordering is according to increasing maximum height.}
#' \item{age}{a numeric vector of tree ages, in yr.}
#' \item{height}{a numeric vector of tree heights, in m.}
#'  }
#' @source 
#' Pinheiro, J. C. and Bates, D. M. (2000) Mixed-effects Models in S and S-PLUS. Springer.
#' @examples
#' 
#' #data(ptaeda)
#' #plot(height ~ age, data = ptaeda, subset = seed.id == 329,
#' #     xlab = "Tree age (yr)", las = 1,
#' #     ylab = "Tree height (m)",
#' #     main = "Loblolly data and fitted curve (seed.id 329 only)")
#' #fm1 <- nls(height ~ SSasymp(age, Asym, R0, lrc),
#' #           data = ptaeda, subset = seed.id == 329)
#' #age <- seq(0, 30, length.out = 101)
#' #lines(age, predict(fm1, list(age = age)))
'ptaeda'
#' Contains tree-level biomass data for several species in Canada.
#'
#' @description
#' These are tree-level variables for several species in Canada.
#' 
#' @format 
#' \describe{
#'   \item{treenum}{tree number.}
#'   \item{spp}{species common name.}
#'   \item{dbh}{diameter at breast height, in cm.}
#'   \item{height}{total height, in m.}
#'   \item{totbiom}{total biomass, in kg.}
#'   \item{bolebiom}{stem biomass, in kg.}
#'   \item{branchbiom}{branches biomass, in kg.}
#'   \item{foliagebiom}{foliage biomass, in kg.}
#'  }
#' @source  
#' The data are provided courtesy of Prof. Timothy Gregoire at
#' the School of Forestry and Environmental Studies at Yale University (New Haven, CT, USA).
#' @examples
#' data(biomass)    
#' head(biomass) 
"biomass"
#' Tree locations for differents plots of the spruce Norway 
#'
#' @description
#' The Cartesian position, species, year, ID tree , and diameter of trees within a plot were measured. 
#' @usage
#' data(spatAustria)
#' @format Contains tree-level variables, as follows:
#' \describe{
#' \item{plot.code}{Plot identificator}
#'   \item{tree.code}{Tree identificator}
#' \item{spp.name}{species abreviation as follows: PCAB=Picea abies, FASY= Fagus sylvatica, QCPE=Quercus petraea , PNSY= Pinus Sylvestris, LADC=Larix decidua}
#' \item{x.coord}{Cartesian position in the X-axis, in m}
#' \item{y.coord}{Cartesian position in the Y-axis, in m}
#' \item{year}{Measurement year}
#' \item{dbh}{diameter at breast height, in cm}
#'  }
#' @references
#' - Kindermann G. Kristofel F, Neumann M, Rossler G, LedermannT & Schueler. 2018. 109 years of forest growth measurements from
#'  individual Norway spruce trees. Sci. Data 5:180077 DOI: 10.1038/sdata.2018.77.
#' @examples
#' # data(spatAustria)    
#' #head(spatAustria)
#' #graphics for tree by plots
#' #pos<-data(spatAustria)
#' #par(mar=c(4,4,0,0))
#' #bord<-data.frame(x=c(min(pos$x.coord),max(pos$x.coord),min(pos$x.coord),max(pos$x.coord)),
#' #               y=c(min(pos$y.coord),min(pos$y.coord]),max(pos$y.coord),min($y.coord)))
#' #plot(bord,type="n", xlab="x [m]", ylab="y [m]", asp=1, bty='n')
#' #points(pos$x.coord,pos$y.coord,col=pos$plot.code,cex=0.5) 
"spatAustria"
#' Contains information of functional traits of vegetative species in Chile.
#'
#' @description
#' Functional traits of vegetative species in Chile. Includes column with codified name (esp) 
#' @usage
#' data(traits)
#' @format 
#' \describe{
#'   \item{esp}{species codified name}
#'   \item{shadeTolerance}{indicates the species tolerance to shape. There are three main classes: shade-tolerant, shade-midtolerant and shade-intolerant}
#'   \item{spp.ci.name}{Scientific name.}
#'   \item{spp.ci.abb.}{.}
#'   \item{wd}{wood density in kg per cubic meters.}
#'  }
#' @source  
#' Some of the information on shade tolerance can be found in Soto et al 2010. Heterogeneidad estructural y
#' espacial de un bosque mixto dominado por Nothofagus dombeyi despues de un disturbio parcial.
#' Revista Chilena de Historia Natural 83: 335-347, 2010
"traits"
#' Names and other information of plant species (mainly trees)
#' 
#' @description
#' This data set provides names (taxonomy), of plant species. Includes codes and name abbreviations used by the Biometrics group at the Center for Ecosystem Modeling (CEM), Universidad Mayor, Santiago, Chile.
#' @usage
#' data(speciesList)
#' @format A data frame with 63 observations on 31 variables
#' \describe{
#' \item{nesp}{Unique correlative specie number}
#' \item{spp.ci.name}{Species scientific name}
#' \item{spp.ci.abb}{Species scientific name abbreviation}
#' \item{common.name}{Species common name. No blank spaces,  no special characters}
#' \item{common.nameBlank}{Species common name. With blank spaces,  no special characters}
#' \item{esp}{Species code: code given by CEM Biometrics to identify species for different processing routines}
#' \item{common.nameLatex}{Species common name formatted for Latex}
#' \item{nTaxon}{Unique number of the taxon (i.e., species)}
#' \item{kingdom}{Taxonomic rank Kingdom. In this datase, all species belong to the Kingdom Plantae}
#' \item{division}{Taxonomic rank division or phylum within the Kingdom}
#' \item{class}{Taxonomic rank Class within the Kingdom}
#' \item{order}{Taxonomic rank Order within the Class}
#' \item{family}{Taxonomic rank Family within the Order}
#' \item{spp.ci.full}{Full scientific name including author}
#' \item{genus}{Taxonomic rank Genus within the Family}
#' \item{epithet}{Specific epithet}
#' \item{sppAuthor}{Species author}
#' \item{subSpp}{Subespecies: one of two or more populations of a species varying from one another by morphological characteristics}
#' \item{subSppAuthor}{Subespecies author}
#' \item{varSpp}{Species variety or varietas}
#' \item{varSppAuthor}{Variety author}
#' \item{formSpp}{Form or forma}
#' \item{formSppAuthor}{Form author}
#' \item{commonNamesList}{List of common names per species, separated by commas}
#' \item{synonyms}{Synonyms of the scientific name by which the species has been or is known}
#' \item{borCountries}{Border countries given the species distribution range}
#' \item{habit}{Habit. The general appearance, growth form, or architecture e.g., tree, shrub, grass}
#' \item{lifeCycle}{Life cycle}
#' \item{statusOri}{Status according to the species origin: Native or Endemic}
#' \item{regDist}{Distribution range of the species, within Chile administrative regions}
#' \item{elevRange}{Distribution range of the species, in terms of elevation. Meters above sea level}
#' \item{notes}{Notes}
#' }
#' @source 
#' Data provided from \url{https://investigacion.conaf.cl/repositorio/documento/ficha-repositorio.php?redo_id=1080946}
#' @references
#' Proyecto 004/2016 Lista sistematica actualizada de la flora vascular nativa de Chile, origen y distribucion geografica. VII Concurso del Fondo de Investigacion del Bosque Nativo
'speciesList'
#' Contains regenaration microsito data in Robinson Crusoe Island forest
#'
#' @description
#' These are plot-level measurement data from the forests in the Robinson Crusoe Insland, located in the Pacific Ocean, 667 km from mainland Chile. Measurements 
#' correspond to transects of 100 to 240 meters
#'
#' @usage
#' data(invasivesRCI)
#'
#' @format Base de datos que contiene 14 columnas y 51 filas:
#' \describe{
#'   \item{plot.id}{Plot identification code}
#'   \item{Gap.type}{Canopy gap classified as invaded=Inv, non invaded= Nat or treated =Treat(considering the estimated cover of invasive plant species)}
#'   \item{Forest.zone}{Location of the plot (gap, border or forest)}
#'   \item{Ferns}{Estimated cover of fern species (in 2x2 plots)}
#'   \item{Moss.liverw}{Estimated cover of mosses and liverworts ( in 2x2 plots)}
#'   \item{Cwd}{Estimated cover of coarse woody debris > 3 cm diameter ( in 2x2 plots)}
#'   \item{Litter}{Estimated cover of litter (in 2x2 plots)}
#'   \item{Ms}{Estimated cover of mineral soil ( in 2x2 plots)}
#'   \item{Rock}{Estimated cover of rocks (in 2x2 plots)}
#'   \item{Est.age}{Age category for the canopy gap associated to each plot}
#'     }
#' @source  
#'  The data are provided courtesy of Prof. Rodrigo Vargas-Gaete at Universidad
#'  de La Frontera (Temuco, Chile).
#' @references
#'  Vargas R, Salas C, Gartner SM, Vidal OJ, Bannister JR,
#'  Pauchard A. (2018). Invasive plant species thresholds in the forests of Robinson
#'  Crusoe Island, Chile. Plant Ecology & Diversity. 11(2): 205-215.
"invasivesRCI"
#' Contains plot level data Lleuque forest
#'
#' @description
#' -----
#' 
#' @format Base de datos que contiene 15 columnas y 26 filas:
#' \describe{
#'   \item{stand}{---}
#'   \item{plot.num}{---}
#'   \item{elevation}{---}
#'   \item{aspect}{---}
#'   \item{slope}{---}
#'   \item{stump}{---}
#'   \item{cattle.faeces}{---}
#'   \item{dist.to.river}{---}
#'   \item{fruits.ha}{---}
#'   \item{browse}{---}
#'  }
#' @source  
#' The data are provided courtesy of Prof. Rodrigo Vargas-Gaete at Universidad
#'  de La Frontera (Temuco, Chile).
#' @references
#' Vargas R, Salas C, Penneckamp D, Neira Z, Diez C, Vargas R. Estructura y regeneracion de 
#' bosques de Prumnopitys andina en los Andes del sur de Chile (in Press). Gayana botanica
"plotLleuque"
#' Contains specie composition data Lleuque forest
#'
#' @description
#' -----
#' 
#' @format Base de datos que contiene 72 columnas y 26 filas:
#' \describe{
#'   \item{stand}{---}
#'   \item{plot.num}{---}
#'   \item{Aus.chi}{---}
#'   \item{May.dis}{---}
#'   \item{Not.obl}{---}
#'   \item{Pru.and}{---}
#'  }
#' @source  
#' The data are provided courtesy of Prof. Rodrigo Vargas-Gaete at Universidad
#'  de La Frontera (Temuco, Chile).
#' @references
#' Vargas R, Salas C, Penneckamp D, Neira Z, Diez C,
#'  Vargas R. 2020. Estructura y regeneracion de 
#' bosques de Prumnopitys andina en los Andes del sur de Chile. Gayana botanica (to appear)
"lleuque"
#' Data with information on the National System of State Protected Wild Areas (SNASPE)
#'
#' @description
#' 
#' Dataset contains the protected wild areas of Chile that are part of the National System of State Protected Wild Areas (SNASPE).
#' @usage
#' data(snaspeChile)
#' @format Contains of variables, as follows:
#' \describe{
#' \item{g.id}{Id.}
#' \item{unit}{Name of the protected area.}
#' \item{category}{Category of the unit. It can be either a National Park, a National Reserve or a Natural Monument.}
#' \item{commune}{Name of the commune (the smallest Chilean territorial division) where the unit is located.}
#' \item{province}{Province where the comunne is located (one territorial division level above the commune).}
#'  \item{region}{Region where the province is located (one territorial division level above the province and the biggest Chilean territorial division).}
#' \item{perim.km}{Perimeter of the unit in kilometers.}
#' \item{area.ha}{Area of the unit in hectares.}
#' \item{area.m2}{Area of the unit in square meters.}
#'  }
#' @source
#' These data is freely available at
#' \url{http://ide.minagri.gob.cl/geoweb/2019/11/21/medio-ambiente/}
#'   
#' @references
#' The SNASPE has been created and is currently managed by the National Forest Corporation (CONAF).
#' More information and documentation can be found at
#' \url{https://www.conaf.cl/parques-nacionales/parques-de-chile/} 
#'  
#' @examples
#' data(snaspeChile)    
#' head(snaspeChile) 
"snaspeChile"
#' Data with information radios crown for different directions on site rucamanque
#'
#' @description
#' 
#' Dataset contains information for species Roble, Coigue y Olivillo about radios of crown for different directions, coordinates and diameter crown. 
#' @usage
#' data(radiosCopa)
#' @format Contains of variables, as follows:
#' \describe{
#' \item{specie}{Code of specie. ro is Roble, co is Coigue and ol is Olivillo.}
#' \item{dap}{Diameter at breast height.}
#' \item{htot}{Total height in meters.}
#' \item{north}{Radio of crown in direction north in meters.}
#' \item{east}{Radio of crown in direction east in meters.}
#'  \item{south}{Radio of crown in direction south in meters.}
#' \item{west}{Radio of crown in direction west in meters.}
#' \item{x}{Coordinate x.}
#' \item{y}{Coordinate y.}
#' \item{crown}{Diameter of crown in meters.}
#'  }
#' @source
#' not yet
#' 
#'   
#' @references
#' not yer
#'  
#' @examples
#' data(radiosCopa)    
#' head(radiosCopa) 
"radiosCopa"