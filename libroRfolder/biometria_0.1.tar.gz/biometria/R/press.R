#' This function computes the PRESS statistics for a simple linear regression model
#'
#' Be carefull for using it
#' 
#' @title Computes the PRESS statistics
#' @param y is the response variable
#' @param x is the predictor variable
#'
#' @return This function returns the PRESS statistics. 
#' @author Christian Salas-Eljatib.
#' @examples
#'
#' set.seed(1234)
#' x <- rnorm(10, 550)
#' y <- rnorm(10, 45)
#' #using the function
#' press(x,y)
#' @rdname geomean
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
press <- function(x,y){
  ei <- stats::lsfit(x,y)$residuals
  hi <- stats::hat(x)
  sum( (ei/(1-hi))^2 )
}