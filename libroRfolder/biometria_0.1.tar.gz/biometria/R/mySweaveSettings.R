stangleOrga <- function(fileName,extension='Rnw',command='pdflatex',silent=FALSE,preview=FALSE)
{

#if this function is being used, then the following settings are needed, therefore,
# being loaded as well  
#  source ("/home/christian/myPCdefStuff/Rstuff/mySweaveSettingsb.R")

        if (command=='latex') command='simpdftex latex --maxpfb'
        extension<-paste('.',extension,sep='')
        path=options('latexcmd')[[1]]
        path=substr(path,start=1,stop=nchar(path)-5)

  
##1. generate the .R file from Sweave from R...
#  fn = unlist(strsplit(filename, "\\."))[1]  
  cat('\nRunning Stangle()...\n')  
#
#  cur.dir = getwd()
## where is the main .Rnw file?   
#  sw.dir = paste(getwd(), '/SweaveLaTeXBib/', sep='')
 # Sweave(file.path(sw.dir, fileName))
#        Sweave(file.path(sw.dir, paste(fileName,extension,sep='') ))
 Stangle(file.path(sw.dir, paste(fileName,extension,sep='') ))

cat('\nMoving the .R file to the /Rwork/SweaveTexBib folder \n')
#      fPathtex = file.path( getwd(), paste(fn, '.R', sep='') )
      fPathtex = file.path( cur.dir, paste(fileName, '.R', sep='') )            
      system(paste('mv ', fPathtex, file.path( sw.dir ) ) )

cat('~~~~~ ')      
cat('The process is done!, you have an .R file')
cat('~~~~~ \n')    
## clean up...
#
  setwd(cur.dir) #come back to the original working folder
#  return(invisible(j))
}