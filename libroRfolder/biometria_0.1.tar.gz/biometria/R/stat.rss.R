#' Statistics for a Stratified Random Sample without replacement
#' 
#'   
#' 
#' @title Statistics for a Stratified Random Sample without replacement
#' @param n is the sample size
#' @param y vector with the target variable
#' @param conf  is the confidence level in percentagee for building the confidence intervals
#' @return  Statistics for a Stratified Random Sample without replacement
#' @author Christian Salas-Eljatib
#' @examples
#' #not yet implemented
#' 
#' @rdname stat.rss
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
stat.rss <- function(n,y,conf){
#       {if(total==0) df=n-L else df=n-1}
      df=n-1 #total*(n-L)+(n-1)
      mean.y=mean(y)
      sd.y <- stats::sd(y)
      se.y <- sd.y/sqrt(n)
      alpha=1-(conf/100)
      p=1-(alpha/2)
      ttab<- stats::qt(p, df)
      sam.error <- ttab*se.y
      sam.error.p <- 100*(sam.error/mean.y)
      low.mu.y <- mean.y - sam.error
      upp.mu.y <- mean.y + sam.error
#       CI <- c(low.mu.y,upp.mu.y)
#       names(CI) <- c("Lower value", "Upper value")
       output <- c(mean.y,sam.error,sam.error.p,low.mu.y,upp.mu.y)
       names(output) <- c("Mean","Samp.Error","Samp.E%","Lower value", "Upper value")
       output
}