siRoRaco<-function(data=data,hab=hab,slo.porcentaje=slo.porcentaje,asp=asp,dem=dem){
  
  db<-data  
  db$slo.porcentaje<-db[,slo.porcentaje]
  db$asp<-db[,asp]
  db$dem<-db[,dem]  
  db$hab<-db[,hab]    

  db$p.48[db$hab=="48"]<-1; db$p.48[db$hab!="48"]<-0
  db$p.54[db$hab=="54"]<-1; db$p.54[db$hab!="54"]<-0
  db$p.56[db$hab=="56"]<-1; db$p.56[db$hab!="56"]<-0
  db$p.57[db$hab=="57"]<-1; db$p.57[db$hab!="57"]<-0    
  db$p.58[db$hab=="58"]<-1; db$p.58[db$hab!="58"]<-0
  db$p.59[db$hab=="59"]<-1; db$p.59[db$hab!="59"]<-0
  db$p.61[db$hab=="61"]<-1; db$p.61[db$hab!="61"]<-0
  db$p.62[db$hab=="62"]<-1; db$p.62[db$hab!="62"]<-0
  db$p.74[db$hab=="74"]<-1; db$p.74[db$hab!="74"]<-0

# calculo de b.hat.i
db$b.hat.i <- -0.102212+
  -0.000295*db$w15.pp.season+
  -0.000127*db$w18.pp.warm.quart+
  0.001661* sqrt (db$w18.pp.warm.quart)+
  0.024749*db$w01.an.mean.t+
  -0.001241*(db$w01.an.mean.t) ^ 2

# calculo de b.hat.2
db$b.hat.2 <- db$b.hat.i + 0.026761



# calculo de a.hat.i
db$a.hat.i <- -8.89*(10^0)+
  3.04*(10^1)*db$b.hat.i+
  5.71*(10^0)*db$p.74+
  1.89*(10^-1)*db$p.59+
  -2.76*(10^0)*db$p.57+
  8.27*(10^-1)*db$p.58+
  -2.12*(10^0)*db$slo.porcentaje+
  -2.35*(10^0)*db$slo.porcentaje* cos(db$asp)+
  -1.55*(10^0)*db$slo.porcentaje* sin(db$asp)+
  3.37*(10^-1)*db$slo.porcentaje* log(db$dem+1)+
  4.20*(10^-1)*db$slo.porcentaje* log(db$dem+1)* cos(db$asp)+
  2.85*(10^-1)*db$slo.porcentaje* log(db$dem+1)* sin(db$asp)+
  -2.78*(10^-7)*db$slo.porcentaje*(db$dem)^2+
  -8.36*(10^-7)*db$slo.porcentaje*(db$dem)^2*cos(db$asp)+
  -6.08*(10^-7)*db$slo.porcentaje*(db$dem)^2*sin(db$asp)+
  3.04*(10^-2)*db$dem+
  -2.17*(10^-5)*(db$dem)^2

# calclulo de a.hat.2

db$a.hat.2 <- db$a.hat.i+ 33.695935

# calculo de site index

db$si <- db$a.hat.2*(1-(1-(1.3/db$a.hat.2)^0.624810)*2.7183^(-db$b.hat.2*(50-0.5)))*(1/ 0.624810)
}

