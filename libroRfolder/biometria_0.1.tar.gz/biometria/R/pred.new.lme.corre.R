pred.new.lme.corre<- function(ori.data, mix.mod.obj, myverbose,what.variable){                  
output=c();  
  for(i in 1:nrow(ori.data))    
    {
if(myverbose==1){      
cat('Starting cross-validation for mixed-effects models, observation No.',i,sep='','\n')} else {
  nada=1}      
# 1. selecting the data, taking out an observation
dbnew=ori.data[-i,]

##obtaining the best correlation structure, and the best model
lme.new.corre= comparCorreFunc(mix.mod.obj,dbnew,1)

## the beta.hat vector
Betas.fix.lme=lme4::fixef(lme.new.corre)

##mean prediction of the LME model for this new observation
mean.pred=stats::predict(lme.new.corre , level=0, newdata=ori.data[i,])
#fitted(lme.new, level=0,data=ori.data[i,])

pred.i.out=mean.pred #+reff.pred

pred.i.out0=cbind(pred.i.out)
#      output=c(output,pred.i.out)
   output=rbind(output,pred.i.out0)     
#output=c(dagre,rmse)
#   names(output)=c('pred.value')
   output
}
}