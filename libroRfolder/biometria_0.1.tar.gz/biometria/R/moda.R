#' This function computes the mode of a vector
#'
#' @title Computes the mode
#' @param v is a numeric vector
#'
#' @return This function returns the mode, a numeric scalar. 
#' @author Christian Salas-Eljatib.
#' @examples
#'
#' set.seed(1234)
#' y <- rnorm(10, 45)
#' #using the function
#' moda(y)
#' @rdname moda
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
moda <- function(v) {
  uniqv <- unique(v)
  uniqv[which.max(tabulate(match(v, uniqv)))]
}