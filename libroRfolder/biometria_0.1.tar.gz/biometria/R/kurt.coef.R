#' Computes the estimator of Pearson's measure kurtosis
#' 
#'   
#' 
#' @title Computes the estimator of Pearson's measure kurtosis
#' @param x vector of numbers
#' @param na.rm if whant to remove NA values
#' 
#' @return  the value of the estimator of Pearson's measure kurtosis
#'  
#' @author Christian Salas-Eljatib and Joaquin Riquelme-Alarcon
#' @examples
#'
#' kurt.coef(rnorm(100))
#'
#' @rdname kurt.coef
#' @export
#' 
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
kurt.coef <- function(x, na.rm=T) {  
m4 <- mean((x-mean(x, na.rm=na.rm))^4, na.rm=na.rm) 
kurt.coef <- m4/(stats::sd(x, na.rm=na.rm)^4)-3  
kurt.coef
}
