var.tau.pps <- function(N, n, var.y){
  f <- n/N
  tau.y.pps    <- 1/N
  var.tau.y <- N^2 * ( (1/n) - f ) * var.y
  return(var.tau.y)
}